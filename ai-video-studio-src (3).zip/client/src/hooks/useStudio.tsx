import React, { createContext, useContext, useState, useEffect } from 'react';
import { VideoProject, WorkflowPlan, FactoryScorecard, SelfEvalReport, PublishingChecklist } from '../types/studio';

export type StudioView =
  | 'dashboard'
  | 'factory'
  | 'editor'
  | 'output'
  | 'director_plan'
  | 'scorecard'
  | 'shots'
  | 'asset_bible'
  | 'fact_check'
  | 'trends'
  | 'shorts'
  | 'versions'
  | 'brands'
  | 'calendar_publish'
  | 'analytics_ideas'
  | 'collaboration'
  | 'admin_control'
  | 'providers'
  | 'projects'
  | 'templates'
  | 'voices'
  | 'music'
  | 'renders'
  | 'costs'
  | 'settings';

interface StudioContextType {
  currentView: StudioView;
  setCurrentView: (view: StudioView) => void;
  projects: VideoProject[];
  currentProject: VideoProject | null;
  setCurrentProject: (proj: VideoProject | null) => void;
  isLoading: boolean;
  emergencyStopped: boolean;
  activeModal: string | null;
  openModal: (name: string) => void;
  closeModal: () => void;
  fetchProjects: () => Promise<void>;
  createAutonomousProject: (params: any) => Promise<VideoProject>;
  triggerEmergencyStop: (projectId?: string) => Promise<void>;
  resetEmergencyStop: () => Promise<void>;
  repairProject: (projectId: string) => Promise<void>;
}

const StudioContext = createContext<StudioContextType | undefined>(undefined);

export const StudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<StudioView>('dashboard');
  const [projects, setProjects] = useState<VideoProject[]>([]);
  const [currentProject, setCurrentProject] = useState<VideoProject | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [emergencyStopped, setEmergencyStopped] = useState<boolean>(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const fetchProjects = async () => {
    try {
      const res = await fetch('/api/projects');
      if (res.ok) {
        const data = await res.json();
        setProjects(data.projects || []);
        if (data.projects?.length > 0 && !currentProject) {
          setCurrentProject(data.projects[0]);
        }
      }
    } catch (e) {
      console.warn('Failed to fetch projects', e);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const openModal = (name: string) => setActiveModal(name);
  const closeModal = () => setActiveModal(null);

  const createAutonomousProject = async (params: any): Promise<VideoProject> => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/factory/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      const data = await res.json();
      if (data.project) {
        setCurrentProject(data.project);
        fetchProjects();
        return data.project;
      }
      throw new Error(data.message || 'Production failed');
    } finally {
      setIsLoading(false);
    }
  };

  const triggerEmergencyStop = async (projectId?: string) => {
    await fetch('/api/factory/emergency-stop', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId })
    });
    setEmergencyStopped(true);
    fetchProjects();
  };

  const resetEmergencyStop = async () => {
    await fetch('/api/factory/reset-emergency-stop', { method: 'POST' });
    setEmergencyStopped(false);
  };

  const repairProject = async (projectId: string) => {
    await fetch(`/api/repair/${projectId}/auto-all`, { method: 'POST' });
    fetchProjects();
    if (currentProject?.id === projectId) {
      const updated = await fetch(`/api/projects/${projectId}`).then(r => r.json());
      if (updated.project) setCurrentProject(updated.project);
    }
  };

  return (
    <StudioContext.Provider
      value={{
        currentView,
        setCurrentView,
        projects,
        currentProject,
        setCurrentProject,
        isLoading,
        emergencyStopped,
        activeModal,
        openModal,
        closeModal,
        fetchProjects,
        createAutonomousProject,
        triggerEmergencyStop,
        resetEmergencyStop,
        repairProject
      }}
    >
      {children}
    </StudioContext.Provider>
  );
};

export const useStudio = () => {
  const context = useContext(StudioContext);
  if (!context) throw new Error('useStudio must be used within StudioProvider');
  return context;
};
