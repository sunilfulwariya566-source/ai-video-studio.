import React from 'react';
import { StudioProvider, useStudio } from './hooks/useStudio';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/views/DashboardView';
import { StudioEditorView } from './components/views/StudioEditorView';
import { ProjectsListView } from './components/views/ProjectsListView';
import { TemplatesView } from './components/views/TemplatesView';
import { VoiceLibraryView } from './components/views/VoiceLibraryView';
import { MusicLibraryView } from './components/views/MusicLibraryView';
import { RenderQueueView } from './components/views/RenderQueueView';
import { SettingsView } from './components/views/SettingsView';
import { FinalOutputView } from './components/views/FinalOutputView';
import { CostUsageDashboardView } from './components/views/CostUsageDashboardView';
import { ShotPlannerView } from './components/views/ShotPlannerView';
import { FactCheckInspectorView } from './components/views/FactCheckInspectorView';
import { TrendAnalyzerView } from './components/views/TrendAnalyzerView';
import { AssetBibleView } from './components/views/AssetBibleView';
import { ShortsStudioView } from './components/views/ShortsStudioView';
import { VersionManagerView } from './components/views/VersionManagerView';
import { BrandKitView } from './components/views/BrandKitView';
import { AdminProvidersView } from './components/views/AdminProvidersView';
import { DirectorPlanView } from './components/views/DirectorPlanView';
import { FactoryScorecardView } from './components/views/FactoryScorecardView';
import { ContentCalendarPublishingView } from './components/views/ContentCalendarPublishingView';
import { AnalyticsIdeasView } from './components/views/AnalyticsIdeasView';
import { CollaborationView } from './components/views/CollaborationView';
import { AdminControlCenterView } from './components/views/AdminControlCenterView';
import { LiveProductionMonitor } from './components/studio/LiveProductionMonitor';
import { NewProjectModal } from './components/studio/NewProjectModal';
import { FactoryModal } from './components/studio/FactoryModal';
import { ExportModal } from './components/studio/ExportModal';
import { QualityControlModal } from './components/studio/QualityControlModal';
import { CharacterEnvironmentModal } from './components/studio/CharacterEnvironmentModal';

const StudioMain: React.FC = () => {
  const { currentView } = useStudio();

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans antialiased">
      <Sidebar />

      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        {currentView === 'dashboard' && <DashboardView />}
        {currentView === 'factory' && <LiveProductionMonitor />}
        {currentView === 'director_plan' && <DirectorPlanView />}
        {currentView === 'scorecard' && <FactoryScorecardView />}
        {currentView === 'calendar_publish' && <ContentCalendarPublishingView />}
        {currentView === 'analytics_ideas' && <AnalyticsIdeasView />}
        {currentView === 'collaboration' && <CollaborationView />}
        {currentView === 'admin_control' && <AdminControlCenterView />}
        {currentView === 'output' && <FinalOutputView />}
        {currentView === 'editor' && <StudioEditorView />}
        {currentView === 'shots' && <ShotPlannerView />}
        {currentView === 'asset_bible' && <AssetBibleView />}
        {currentView === 'fact_check' && <FactCheckInspectorView />}
        {currentView === 'trends' && <TrendAnalyzerView />}
        {currentView === 'shorts' && <ShortsStudioView />}
        {currentView === 'versions' && <VersionManagerView />}
        {currentView === 'brands' && <BrandKitView />}
        {currentView === 'providers' && <AdminProvidersView />}
        {currentView === 'projects' && <ProjectsListView />}
        {currentView === 'templates' && <TemplatesView />}
        {currentView === 'voices' && <VoiceLibraryView />}
        {currentView === 'music' && <MusicLibraryView />}
        {currentView === 'renders' && <RenderQueueView />}
        {currentView === 'costs' && <CostUsageDashboardView />}
        {currentView === 'settings' && <SettingsView />}
      </main>

      {/* Global Modals */}
      <FactoryModal />
      <NewProjectModal />
      <ExportModal />
      <QualityControlModal />
      <CharacterEnvironmentModal />
    </div>
  );
};

export function App() {
  return (
    <StudioProvider>
      <StudioMain />
    </StudioProvider>
  );
}

export default App;
