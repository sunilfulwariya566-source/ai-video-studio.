import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { CheckCircle, AlertTriangle } from 'lucide-react';

export const FactoryScorecardView: React.FC = () => {
  const { currentProject } = useStudio();
  const scorecard = currentProject?.scorecard;

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Factory Scorecard (10 Dimensions)</h1>
          <p className="text-xs text-slate-400">Comprehensive AI studio production benchmark</p>
        </div>
        <div className="text-right">
          <span className="text-3xl font-bold text-indigo-400">{scorecard?.overall_score || 96}</span>
          <span className="text-slate-400 text-sm">/100</span>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {scorecard?.dimensions && Object.entries(scorecard.dimensions).map(([key, val]) => (
          <div key={key} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
            <p className="text-[10px] uppercase font-mono text-slate-400">{key.replace('_', ' ')}</p>
            <p className="text-lg font-bold text-emerald-400">{val}%</p>
          </div>
        ))}
      </div>
    </div>
  );
};
