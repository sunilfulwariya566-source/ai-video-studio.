import React from 'react';
import { Layout, Sparkles } from 'lucide-react';

export const TemplatesView: React.FC = () => {
  const templates = [
    { name: 'Documentary Spotlight', category: 'Educational', duration: '45s', style: 'Cinematic' },
    { name: 'Viral Tech Breakdown', category: 'Technology', duration: '30s', style: 'Cyberpunk' },
    { name: 'Epic Historical Chronicle', category: 'History', duration: '60s', style: 'Dramatic' },
    { name: 'Executive Business Brief', category: 'Finance', duration: '30s', style: 'Corporate' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Production Templates</h1>
        <p className="text-xs text-slate-400">Pre-configured directorial pacing and cinematography styles</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {templates.map((t, idx) => (
          <div key={idx} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
            <span className="text-[10px] font-mono uppercase bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded">
              {t.category}
            </span>
            <h3 className="font-bold text-white text-sm">{t.name}</h3>
            <p className="text-xs text-slate-400">Duration: {t.duration} • Style: {t.style}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
