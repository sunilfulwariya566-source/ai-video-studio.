import React from 'react';
import { Music, Disc } from 'lucide-react';

export const MusicLibraryView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Dynamic Music & SFX Mix</h1>
        <p className="text-xs text-slate-400">Broadcast-compliant audio scores with auto-ducking</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Target Normalization: -14.0 LUFS • True Peak: -1.0 dB</p>
      </div>
    </div>
  );
};
