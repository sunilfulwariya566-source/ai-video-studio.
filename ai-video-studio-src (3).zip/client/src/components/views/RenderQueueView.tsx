import React from 'react';
import { Cpu } from 'lucide-react';

export const RenderQueueView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Production Render Queue</h1>
        <p className="text-xs text-slate-400">Local CPU, Local GPU, and Remote Worker Nodes</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-emerald-400">● 2 Worker Pools Active • 0 Pending Blockers</p>
      </div>
    </div>
  );
};
