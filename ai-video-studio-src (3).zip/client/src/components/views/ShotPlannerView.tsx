import React from 'react';
import { Layers } from 'lucide-react';

export const ShotPlannerView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Cinematic Shot Planner</h1>
        <p className="text-xs text-slate-400">Shot types, lens lengths, focal points, and dynamic camera movements</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Automated cinematic curves active across all scenes.</p>
      </div>
    </div>
  );
};
