import React from 'react';
import { Settings, Shield } from 'lucide-react';

export const SettingsView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Studio Settings</h1>
        <p className="text-xs text-slate-400">Global configurations, export paths, and hardware defaults</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Environment: Phase 6 Autonomous AI Studio Engine</p>
      </div>
    </div>
  );
};
