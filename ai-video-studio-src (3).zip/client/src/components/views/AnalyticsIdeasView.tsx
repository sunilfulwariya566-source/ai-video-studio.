import React from 'react';
import { Sparkles, BarChart3 } from 'lucide-react';

export const AnalyticsIdeasView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Idea Generator & Originality Engine</h1>
        <p className="text-xs text-slate-400">High-retention angles and duplicate content protection</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Historical Insights: 30-45s duration generates peak retention.</p>
      </div>
    </div>
  );
};
