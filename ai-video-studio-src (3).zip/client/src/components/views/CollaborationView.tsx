import React from 'react';
import { Users, MessageSquare } from 'lucide-react';

export const CollaborationView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Role-Based Collaboration & Approvals</h1>
        <p className="text-xs text-slate-400">Granular permissions for Owner, Admin, Editor, Reviewer, and Viewer</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Active Role: Owner (Full Permissions)</p>
      </div>
    </div>
  );
};
