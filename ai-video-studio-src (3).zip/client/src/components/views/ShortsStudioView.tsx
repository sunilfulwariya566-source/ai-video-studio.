import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Scissors, Play } from 'lucide-react';

export const ShortsStudioView: React.FC = () => {
  const { currentProject } = useStudio();
  const shorts = currentProject?.auto_shorts || [];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Auto-Shorts & Viral Reels</h1>
        <p className="text-xs text-slate-400">Automated extraction of vertical 9:16 highlights with dynamic captions</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {shorts.map(s => (
          <div key={s.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <h3 className="font-bold text-sm text-white">{s.title}</h3>
            <p className="text-xs text-indigo-300">Hook: "{s.hook_text}"</p>
            <p className="text-[11px] text-slate-400">Aspect Ratio: {s.aspect_ratio} • Duration: {s.duration_seconds}s</p>
          </div>
        ))}
      </div>
    </div>
  );
};
