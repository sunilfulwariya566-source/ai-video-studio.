import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Film, Play, Trash2, Calendar } from 'lucide-react';

export const ProjectsListView: React.FC = () => {
  const { projects, currentProject, setCurrentProject, setCurrentView } = useStudio();

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Project Library</h1>
          <p className="text-xs text-slate-400">Manage all stored autonomous video productions</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {projects.map(proj => (
          <div
            key={proj.id}
            onClick={() => {
              setCurrentProject(proj);
              setCurrentView('output');
            }}
            className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/50 cursor-pointer space-y-3 transition"
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-mono text-slate-400">{proj.format}</span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold text-[10px]">
                {proj.status}
              </span>
            </div>
            <h3 className="font-bold text-white text-sm line-clamp-1">{proj.title}</h3>
            <p className="text-xs text-slate-400 line-clamp-2">{proj.idea || proj.prompt}</p>
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>{proj.scenes?.length || 3} Scenes</span>
              <span className="text-indigo-400 font-semibold">QC: {proj.qc_report?.overall_score || 95}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
