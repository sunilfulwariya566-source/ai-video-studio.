import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Palette, Users } from 'lucide-react';

export const AssetBibleView: React.FC = () => {
  const { currentProject } = useStudio();
  const characters = currentProject?.characters || [];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Asset Bible & Character Consistency Lock</h1>
        <p className="text-xs text-slate-400">Enforces cross-scene facial and visual identity continuity</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {characters.map(char => (
          <div key={char.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <h3 className="font-bold text-sm text-white">{char.name} ({char.role})</h3>
            <p className="text-xs text-slate-300">{char.visual_description}</p>
            <p className="text-[11px] text-slate-400">Clothing: {char.clothing_style}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
