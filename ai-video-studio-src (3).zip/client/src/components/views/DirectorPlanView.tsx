import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Sparkles, Check, Clock, DollarSign } from 'lucide-react';

export const DirectorPlanView: React.FC = () => {
  const { currentProject } = useStudio();
  const plan = currentProject?.workflow_plan;

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Smart Workflow Planner & AI Content Director</h1>
        <p className="text-xs text-slate-400">Directorial plan determining required pipeline stages, estimated duration, and cost</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Complexity Tier</p>
          <p className="text-lg font-bold text-indigo-400">{plan?.complexity || 'STANDARD'}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Estimated Duration</p>
          <p className="text-lg font-bold text-amber-400">{plan?.estimated_total_time_sec || 45}s</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Estimated Production Cost</p>
          <p className="text-lg font-bold text-emerald-400">${plan?.estimated_total_cost_usd || 0.045}</p>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="font-bold text-xs uppercase tracking-wider text-slate-400">Pipeline Stages</h3>
        <div className="space-y-2">
          {plan?.stages?.map((stage, idx) => (
            <div key={idx} className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs">
              <div>
                <p className="font-semibold text-white">{stage.name}</p>
                <p className="text-[11px] text-slate-400">{stage.reason}</p>
              </div>
              <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">
                ${stage.estimated_cost_usd} • {stage.estimated_duration_sec}s
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
