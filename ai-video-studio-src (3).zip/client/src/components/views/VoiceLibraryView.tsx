import React from 'react';
import { Mic, Volume2 } from 'lucide-react';

export const VoiceLibraryView: React.FC = () => {
  const voices = [
    { id: 'voice_narrator_studio', name: 'Marcus Sterling', gender: 'Male', tone: 'Authoritative & Deep' },
    { id: 'voice_nova', name: 'Nova Vance', gender: 'Female', tone: 'Warm & Cinematic' },
    { id: 'voice_tech', name: 'Kai Reynolds', gender: 'Neutral', tone: 'Modern Tech Fast-Paced' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Voice Roster & Neural Prosody</h1>
        <p className="text-xs text-slate-400">ElevenLabs & local studio TTS voice profiles</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {voices.map(v => (
          <div key={v.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2">
              <Mic className="w-4 h-4 text-indigo-400" />
              <h3 className="font-bold text-sm text-white">{v.name}</h3>
            </div>
            <p className="text-xs text-slate-400">{v.gender} • {v.tone}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
