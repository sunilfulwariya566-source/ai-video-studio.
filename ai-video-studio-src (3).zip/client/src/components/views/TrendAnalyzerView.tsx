import React from 'react';
import { TrendingUp } from 'lucide-react';

export const TrendAnalyzerView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Trend & Viral Intelligence</h1>
        <p className="text-xs text-slate-400">Real-time keyword demand and viral potential scoring</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Viral Index: 92/100 • Search Demand: High</p>
      </div>
    </div>
  );
};
