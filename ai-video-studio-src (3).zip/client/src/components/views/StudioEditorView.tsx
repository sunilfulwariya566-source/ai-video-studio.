import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Film, Play, Volume2, Image, Type, Plus, Trash2, Sliders } from 'lucide-react';

export const StudioEditorView: React.FC = () => {
  const { currentProject } = useStudio();
  const scenes = currentProject?.scenes || [];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-hidden">
      {/* Editor Top Bar */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
        <div>
          <h2 className="font-bold text-sm text-white flex items-center gap-2">
            <Film className="w-4 h-4 text-indigo-400" />
            Multi-Track Timeline Editor: {currentProject?.title || 'Timeline'}
          </h2>
          <p className="text-xs text-slate-400">{scenes.length} Scenes • {currentProject?.format || '16:9'} • Audio Ducking -14dB</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold">
            Save Changes
          </button>
        </div>
      </div>

      {/* Main Studio Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {scenes.map((scene, idx) => (
          <div key={scene.id || idx} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-indigo-400 font-mono">SCENE {idx + 1} ({scene.duration || 8}s)</span>
              <span className="text-slate-400 font-mono">Shot: {scene.shot_type || 'WIDE'} • Camera: {scene.camera_movement || 'PAN'}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                  <Type className="w-3.5 h-3.5 text-amber-400" /> Script & Narration
                </label>
                <textarea
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  rows={3}
                  defaultValue={scene.narration}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                  <Image className="w-3.5 h-3.5 text-indigo-400" /> Visual Synthesis Prompt
                </label>
                <textarea
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  rows={3}
                  defaultValue={scene.visual_prompt}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
