import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { FileCheck, ShieldCheck } from 'lucide-react';

export const FactCheckInspectorView: React.FC = () => {
  const { currentProject } = useStudio();
  const claims = currentProject?.fact_check?.claims || [];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Fact-Check Inspector Gate</h1>
        <p className="text-xs text-slate-400">Audits factual integrity against verified knowledge bases</p>
      </div>
      <div className="space-y-3">
        {claims.map((c, i) => (
          <div key={i} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-white">Claim: "{c.original_statement}"</p>
              <p className="text-[11px] text-slate-400">Source: {c.verified_source}</p>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-xs font-semibold">
              {c.confidence} Confidence
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
