import React from 'react';
import { Palette } from 'lucide-react';

export const BrandKitView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Brand Kit & Watermark Settings</h1>
        <p className="text-xs text-slate-400">Safe-area watermarks, brand color schemes, and intro/outro stingers</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Watermark: Bottom-Right (Safe-Zone Compliant)</p>
      </div>
    </div>
  );
};
