import React from 'react';
import { Cpu, CheckCircle } from 'lucide-react';

export const AdminProvidersView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">12-Category Provider Management</h1>
        <p className="text-xs text-slate-400">Manage LLM, TTS, Image, Video, STT, Music, SFX, LipSync, and VFX providers</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-emerald-400">● 13 Connected Providers Online • Zero-Cost Mock Mode Available</p>
      </div>
    </div>
  );
};
