import React, { useState } from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Play, Download, Share2, CheckCircle2, Copy, Sparkles, Smartphone, Monitor, Square, ShieldCheck } from 'lucide-react';

export const FinalOutputView: React.FC = () => {
  const { currentProject, openModal } = useStudio();
  const [activeFormat, setActiveFormat] = useState<'16:9' | '9:16' | '1:1' | '4:5'>('16:9');
  const [copied, setCopied] = useState(false);

  if (!currentProject) {
    return (
      <div className="p-8 text-center text-slate-400">
        No active project selected.
      </div>
    );
  }

  const formats = [
    { id: '16:9', label: '16:9 Widescreen (YouTube)', icon: Monitor, res: '1920x1080' },
    { id: '9:16', label: '9:16 Vertical (TikTok / Shorts)', icon: Smartphone, res: '1080x1920' },
    { id: '1:1', label: '1:1 Square (Instagram)', icon: Square, res: '1080x1080' },
    { id: '4:5', label: '4:5 Portrait (X / Social)', icon: Smartphone, res: '1080x1350' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white">{currentProject.title}</h1>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-xs font-semibold border border-emerald-500/30">
              Master Render Ready
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">Multi-aspect master renders, AI thumbnails, and auto-shorts clips</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => openModal('export')}
            className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-2 shadow transition"
          >
            <Download className="w-4 h-4" /> Export Assets
          </button>
          <button
            onClick={() => openModal('qc')}
            className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <ShieldCheck className="w-4 h-4 text-indigo-400" /> QC Report
          </button>
        </div>
      </div>

      {/* Video Master Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center group shadow-2xl">
            {/* Visual background simulation */}
            <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-indigo-950 to-slate-900 flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div className="w-16 h-16 rounded-full bg-indigo-600/30 border border-indigo-500/50 flex items-center justify-center text-white shadow-xl group-hover:scale-110 transition">
                <Play className="w-8 h-8 fill-current ml-1" />
              </div>
              <div className="space-y-1">
                <h3 className="font-bold text-base text-white">{currentProject.title}</h3>
                <p className="text-xs text-indigo-300">Format: {activeFormat} • Master Audio LUFS: -14.2dB • 4K Master</p>
              </div>
            </div>

            {/* Subtitle Overlay Simulation */}
            <div className="absolute bottom-6 inset-x-12 text-center pointer-events-none">
              <span className="px-3 py-1 rounded bg-black/80 text-amber-300 font-bold text-sm tracking-wide shadow-lg border border-amber-500/20">
                {currentProject.scenes?.[0]?.narration || 'Autonomous AI Video Studio Production Master'}
              </span>
            </div>
          </div>

          {/* Format Selector Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {formats.map(fmt => {
              const Icon = fmt.icon;
              const isSelected = activeFormat === fmt.id;
              return (
                <button
                  key={fmt.id}
                  onClick={() => setActiveFormat(fmt.id as any)}
                  className={`p-3 rounded-xl border text-left transition flex items-center gap-2.5 ${
                    isSelected
                      ? 'bg-indigo-600/20 border-indigo-500 text-white font-semibold'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <div>
                    <p className="text-xs">{fmt.id}</p>
                    <p className="text-[10px] text-slate-400">{fmt.res}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Thumbnails & Metadata Sidebar */}
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
            <h3 className="font-bold text-xs text-white uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              AI Thumbnails & High-CTR Variants
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {(currentProject.thumbnails || [
                { id: 't1', title: 'Curiosity Shock', headline_overlay: 'THE UNTOLD TRUTH', predicted_ctr_score: 11.8 },
                { id: 't2', title: 'Macro Focus', headline_overlay: 'SECRET REVEALED', predicted_ctr_score: 9.4 }
              ]).map(t => (
                <div key={t.id} className="relative rounded-lg overflow-hidden border border-slate-700 aspect-video bg-indigo-950/40 p-2 flex flex-col justify-between">
                  <span className="text-[9px] font-mono bg-black/60 text-emerald-400 px-1 py-0.5 rounded self-start">
                    CTR: {t.predicted_ctr_score}%
                  </span>
                  <span className="text-[10px] font-black text-amber-300 tracking-wider text-center uppercase bg-black/70 py-0.5 rounded">
                    {t.headline_overlay}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 text-xs">
            <h3 className="font-bold text-white">SEO & Publishing Metadata</h3>
            <p className="text-slate-300 font-medium">{currentProject.auto_metadata?.seo_title || currentProject.title}</p>
            <p className="text-slate-400 text-[11px] line-clamp-3">{currentProject.auto_metadata?.description || currentProject.idea}</p>
            <div className="flex flex-wrap gap-1 pt-1">
              {(currentProject.auto_metadata?.tags || ['AI', 'Future', 'Technology', 'Science']).map((tag: string, i: number) => (
                <span key={i} className="px-2 py-0.5 rounded-full bg-slate-800 text-[10px] text-slate-300">
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
