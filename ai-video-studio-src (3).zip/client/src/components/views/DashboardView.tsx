import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Sparkles, Play, Clapperboard, CheckCircle, ShieldCheck, Film, Zap, Layers, AlertCircle } from 'lucide-react';

export const DashboardView: React.FC = () => {
  const { projects, currentProject, setCurrentProject, setCurrentView, openModal, repairProject } = useStudio();

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-900 border border-indigo-500/20 p-6 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              Autonomous AI Video Factory Active
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              AI Automated Video Creation Studio
            </h1>
            <p className="text-sm text-slate-400">
              Transform ideas, research topics, and scripts into fully rendered 4K multi-format videos with automated cinematography, voice prosody, audio mixing, and QC gates.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => openModal('factory')}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition"
            >
              <Zap className="w-4 h-4 text-amber-300" />
              AI Director Mode
            </button>
            <button
              onClick={() => openModal('newProject')}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-sm border border-slate-700 transition"
            >
              Custom Timeline
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
          <p className="text-xs text-slate-400">Active Projects</p>
          <p className="text-2xl font-bold text-white">{projects.length}</p>
          <p className="text-[11px] text-emerald-400">● Real-time sync ready</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
          <p className="text-xs text-slate-400">Factory Quality Score</p>
          <p className="text-2xl font-bold text-indigo-400">{currentProject?.scorecard?.overall_score || currentProject?.qc_report?.overall_score || 96}/100</p>
          <p className="text-[11px] text-indigo-300">10-Dimension Audit Passed</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
          <p className="text-xs text-slate-400">Multi-Format Renders</p>
          <p className="text-2xl font-bold text-amber-400">4 Renders Ready</p>
          <p className="text-[11px] text-slate-400">16:9, 9:16, 1:1, 4:5</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
          <p className="text-xs text-slate-400">Infrastructure Health</p>
          <p className="text-2xl font-bold text-emerald-400">100% ONLINE</p>
          <p className="text-[11px] text-slate-400">13 Providers Active</p>
        </div>
      </div>

      {/* Current Active Project Spotlight */}
      {currentProject && (
        <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Film className="w-5 h-5 text-indigo-400" />
              <h2 className="font-bold text-lg text-white">{currentProject.title}</h2>
              <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {currentProject.status}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentView('output')}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition"
              >
                <Play className="w-3.5 h-3.5" /> Watch Final Master
              </button>
              <button
                onClick={() => setCurrentView('editor')}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
              >
                Open Studio Editor
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/80 space-y-1">
              <p className="font-medium text-slate-400">Objective & Director Decision</p>
              <p className="text-slate-200">{currentProject.director_decision?.objective_summary || currentProject.idea || 'Autonomous narrative workflow'}</p>
            </div>
            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/80 space-y-1">
              <p className="font-medium text-slate-400">Pre-Human Self-Evaluation</p>
              <div className="flex items-center justify-between">
                <span className="text-slate-200 font-semibold">{currentProject.self_eval_report?.overall_health || 'PASS'}</span>
                <span className="text-indigo-400">{currentProject.self_eval_report?.score || 95}/100</span>
              </div>
              <button
                onClick={() => repairProject(currentProject.id)}
                className="mt-1 text-[11px] text-amber-400 hover:underline"
              >
                Trigger Targeted Auto-Repair
              </button>
            </div>
            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/80 space-y-1">
              <p className="font-medium text-slate-400">Publishing Checklist Gate</p>
              <p className="text-slate-200">
                {currentProject.publishing_checklist?.is_ready_to_publish ? '✅ Ready for Social Publishing' : '⚠️ Verification Pending'}
              </p>
              <p className="text-[11px] text-slate-400">YouTube, TikTok, X connectors connected</p>
            </div>
          </div>
        </div>
      )}

      {/* Projects Grid */}
      <div className="space-y-3">
        <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-400" />
          Recent Factory Projects ({projects.length})
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {projects.map(proj => (
            <div
              key={proj.id}
              onClick={() => setCurrentProject(proj)}
              className={`p-4 rounded-xl border cursor-pointer transition flex flex-col justify-between space-y-3 ${
                currentProject?.id === proj.id
                  ? 'bg-indigo-950/30 border-indigo-500/50 shadow-lg shadow-indigo-950/50'
                  : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-[10px] text-slate-400 uppercase font-mono">{proj.format} • {proj.duration_target}</span>
                  <span className="text-[10px] text-emerald-400 font-semibold">{proj.status}</span>
                </div>
                <h4 className="font-bold text-sm text-white line-clamp-1">{proj.title}</h4>
                <p className="text-xs text-slate-400 line-clamp-2 mt-1">{proj.prompt || proj.idea}</p>
              </div>
              <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800">
                <span className="text-slate-400">{proj.scenes?.length || 3} Scenes</span>
                <span className="text-indigo-400 font-medium">QC: {proj.qc_report?.overall_score || 95}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
