import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, Users } from 'lucide-react';

export const CharacterEnvironmentModal: React.FC = () => {
  const { activeModal, closeModal } = useStudio();
  if (activeModal !== 'charEnv') return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-base text-white">Character & Environment Locks</h2>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
        <p className="text-xs text-slate-300">Asset Bible consistency active.</p>
      </div>
    </div>
  );
};
