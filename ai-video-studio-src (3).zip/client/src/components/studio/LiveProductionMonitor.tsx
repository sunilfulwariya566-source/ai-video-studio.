import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Zap, CheckCircle2, AlertOctagon } from 'lucide-react';

export const LiveProductionMonitor: React.FC = () => {
  const { currentProject, triggerEmergencyStop } = useStudio();

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            Live AI Director Production Monitor
          </h1>
          <p className="text-xs text-slate-400">Real-time autonomous 27-stage execution telemetry</p>
        </div>
        <button
          onClick={() => triggerEmergencyStop()}
          className="px-3 py-1.5 rounded bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-1.5"
        >
          <AlertOctagon className="w-4 h-4" /> Stop Production
        </button>
      </div>

      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-indigo-400 uppercase">Status: {currentProject?.status || 'COMPLETED'}</span>
          <span className="font-mono text-slate-300">Progress: {currentProject?.progress || 100}%</span>
        </div>
        <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 to-amber-400 transition-all duration-500"
            style={{ width: `${currentProject?.progress || 100}%` }}
          />
        </div>
      </div>
    </div>
  );
};
