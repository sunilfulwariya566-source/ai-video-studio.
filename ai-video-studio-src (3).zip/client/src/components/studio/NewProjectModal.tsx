import React, { useState } from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, Film } from 'lucide-react';

export const NewProjectModal: React.FC = () => {
  const { activeModal, closeModal, createAutonomousProject, setCurrentView } = useStudio();
  const [topic, setTopic] = useState('');

  if (activeModal !== 'newProject') return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    closeModal();
    await createAutonomousProject({ topic, title: topic });
    setCurrentView('factory');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-base text-white">Create Video Project</h2>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-medium mb-1">Topic / Narrative Premise</label>
            <input
              type="text"
              value={topic}
              onChange={e => setTopic(e.target.value)}
              placeholder="e.g. The Quantum Physics of Black Holes"
              className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-indigo-500"
              autoFocus
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow transition"
          >
            Start Production
          </button>
        </form>
      </div>
    </div>
  );
};
