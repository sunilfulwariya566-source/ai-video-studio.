import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, Download } from 'lucide-react';

export const ExportModal: React.FC = () => {
  const { activeModal, closeModal, currentProject } = useStudio();
  if (activeModal !== 'export') return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-base text-white">Export Video & Package</h2>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="space-y-2 text-xs">
          <a
            href={currentProject?.final_video_url || '#'}
            download
            className="block w-full py-2.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-center font-semibold transition"
          >
            Download Master MP4
          </a>
          <button
            onClick={closeModal}
            className="w-full py-2 px-3 rounded-lg bg-slate-800 text-slate-300 text-center font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
