import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, ShieldCheck } from 'lucide-react';

export const QualityControlModal: React.FC = () => {
  const { activeModal, closeModal, currentProject } = useStudio();
  if (activeModal !== 'qc') return null;

  const qc = currentProject?.qc_report;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="font-bold text-base text-white">QC Quality Report</h2>
          </div>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2 text-xs">
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Overall Score</span>
            <span className="font-bold text-emerald-400">{qc?.overall_score || 96}/100</span>
          </div>
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Measured LUFS</span>
            <span className="font-bold text-white">{qc?.lufs_measured || -14.2} dB</span>
          </div>
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Audio Sync</span>
            <span className="font-bold text-emerald-400">PASS</span>
          </div>
        </div>
      </div>
    </div>
  );
};
