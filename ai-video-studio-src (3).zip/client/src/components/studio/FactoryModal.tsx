import React, { useState } from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, Sparkles, Zap } from 'lucide-react';

export const FactoryModal: React.FC = () => {
  const { activeModal, closeModal, createAutonomousProject, setCurrentView } = useStudio();
  const [topic, setTopic] = useState('');
  const [format, setFormat] = useState<'16:9' | '9:16' | '1:1' | '4:5'>('16:9');

  if (activeModal !== 'factory') return null;

  const handleStart = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    closeModal();
    await createAutonomousProject({
      topic,
      title: topic,
      format,
      target_duration_seconds: 30,
      director_mode: true
    });
    setCurrentView('factory');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-indigo-500/30 rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-300" />
            <h2 className="font-bold text-base text-white">AI Director Mode (Autonomous 27 Stages)</h2>
          </div>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleStart} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-medium mb-1">Video Objective / Topic</label>
            <input
              type="text"
              value={topic}
              onChange={e => setTopic(e.target.value)}
              placeholder="e.g. How Neural Networks Think in 2026"
              className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-indigo-500"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Target Aspect Ratio</label>
            <div className="grid grid-cols-4 gap-2">
              {(['16:9', '9:16', '1:1', '4:5'] as const).map(f => (
                <button
                  type="button"
                  key={f}
                  onClick={() => setFormat(f)}
                  className={`p-2 rounded-lg border text-center font-mono font-bold ${
                    format === f ? 'bg-indigo-600/30 border-indigo-500 text-indigo-300' : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Launch Autonomous Production</span>
          </button>
        </form>
      </div>
    </div>
  );
};
