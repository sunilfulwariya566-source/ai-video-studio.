import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'path';

export default defineConfig({
  plugins: [
    react(),
    tailwindcss()
  ],
  root: path.resolve(process.cwd(), 'client'),
  publicDir: path.resolve(process.cwd(), 'client/public'),
  resolve: {
    extensions: ['.tsx', '.ts', '.jsx', '.js']
  },
  build: {
    outDir: path.resolve(process.cwd(), 'client/dist'),
    emptyOutDir: true
  }
});
