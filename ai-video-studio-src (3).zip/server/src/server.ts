import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import apiRouter from './routes/api.js';
import { sanitizeInput, rateLimiter, errorHandler } from './middleware/sanitizer.js';

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = '0.0.0.0';

// Ensure storage directories exist
const storageDirs = ['audio', 'music', 'sfx', 'visuals', 'renders', 'subtitles', 'uploads'];
for (const dir of storageDirs) {
  const dirPath = path.resolve(process.cwd(), 'storage', dir);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

// Global Middlewares
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(sanitizeInput);
app.use('/api', rateLimiter(300, 60000));

// Serve static storage assets directly
app.use('/storage', express.static(path.resolve(process.cwd(), 'storage')));

// Mount API routes
app.use('/api', apiRouter);

// Serve frontend client
const clientDistPath = path.resolve(process.cwd(), 'client/dist');
app.use(express.static(clientDistPath));

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/storage')) {
    return next();
  }
  const indexPath = path.join(clientDistPath, 'index.html');
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.send('AI Video Studio is running. Building frontend client...');
  }
});

// Error Handler
app.use(errorHandler);

export const server = app.listen(PORT, HOST, () => {
  console.log(`====================================================`);
  console.log(`🎬 AI Automated Video Creation Studio - Phase 1`);
  console.log(`🚀 Server running on http://${HOST}:${PORT}`);
  console.log(`⚡ Demo Mode Active: Real Local Speech, VFX, FFmpeg Engine`);
  console.log(`====================================================`);
});

export default app;
