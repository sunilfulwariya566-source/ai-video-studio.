import fs from 'fs';
import path from 'path';
import { VideoProject } from '../types/index.js';

export interface ProductionJobRecord {
  job_id: string;
  project_id: string;
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED';
  progress: number;
  current_stage: string;
  error?: string;
  created_at: string;
  updated_at: string;
}

class Database {
  private projects: Map<string, VideoProject> = new Map();
  private jobs: Map<string, ProductionJobRecord> = new Map();
  private renderJobs: Map<string, any> = new Map();
  private dbPath: string;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'storage');
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    this.dbPath = path.join(dataDir, 'studio_db.json');
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.dbPath)) {
        const data = JSON.parse(fs.readFileSync(this.dbPath, 'utf-8'));
        if (data.projects) for (const p of data.projects) this.projects.set(p.id, p);
        if (data.jobs) for (const j of data.jobs) this.jobs.set(j.job_id, j);
      }
    } catch (e) {
      console.warn('[DB] Load error:', e);
    }
  }

  private persist() {
    try {
      const data = {
        projects: Array.from(this.projects.values()),
        jobs: Array.from(this.jobs.values())
      };
      fs.writeFileSync(this.dbPath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('[DB] Persist error:', e);
    }
  }

  public getProject(id: string): VideoProject | undefined {
    return this.projects.get(id);
  }

  public getAllProjects(): VideoProject[] {
    return Array.from(this.projects.values());
  }

  public saveProject(p: VideoProject): VideoProject {
    p.updated_at = new Date().toISOString();
    this.projects.set(p.id, p);
    this.persist();
    return p;
  }

  public getProductionJob(jobId: string): ProductionJobRecord | undefined {
    return this.jobs.get(jobId);
  }

  public getRenderJob(id: string): any | undefined {
    return this.renderJobs.get(id);
  }

  public saveRenderJob(j: any): any {
    this.renderJobs.set(j.id, j);
    return j;
  }

  public saveProductionJob(j: ProductionJobRecord): ProductionJobRecord {
    j.updated_at = new Date().toISOString();
    this.jobs.set(j.job_id, j);
    this.persist();
    return j;
  }
}

export const db = new Database();
