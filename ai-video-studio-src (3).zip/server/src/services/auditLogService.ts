import { AuditLogEntry } from '../types/index.js';
import fs from 'fs';
import path from 'path';

export class AuditLogService {
  private logs: AuditLogEntry[] = [];
  private logFile: string;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'storage');
    this.logFile = path.join(dataDir, 'audit_log.json');
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.logFile)) {
        this.logs = JSON.parse(fs.readFileSync(this.logFile, 'utf-8'));
      }
    } catch (e) {
      console.warn('[AuditLog] Failed to load log file:', e);
    }
  }

  private persist() {
    try {
      fs.writeFileSync(this.logFile, JSON.stringify(this.logs, null, 2), 'utf-8');
    } catch (e) {
      console.error('[AuditLog] Failed to persist log file:', e);
    }
  }

  public logAction(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>): AuditLogEntry {
    let sanitizedDetails = entry.details;
    try {
      sanitizedDetails = sanitizedDetails
        .replace(/bearer\s+[a-zA-Z0-9_.-]+/gi, 'bearer [REDACTED]')
        .replace(/api_key=([a-zA-Z0-9_-]+)/gi, 'api_key=[REDACTED]');
    } catch (e) {}

    const record: AuditLogEntry = {
      ...entry,
      details: sanitizedDetails,
      id: 'aud_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString()
    };

    this.logs.unshift(record);
    if (this.logs.length > 500) this.logs.pop();
    this.persist();
    return record;
  }

  public getLogs(limit: number = 100): AuditLogEntry[] {
    return this.logs.slice(0, limit);
  }
}

export const auditLogService = new AuditLogService();
