export class BRollService {
  public generateBRollSegments(topic: string, sceneIndex: number) {
    return [
      {
        id: `broll_${sceneIndex + 1}_1`,
        keyword: 'Quantum Core',
        prompt: `Futuristic glowing reactor core spinning in zero gravity: ${topic}`,
        start_sec: 1.5,
        duration_sec: 3.5,
        video_url: '/storage/visuals/scene_2.png'
      }
    ];
  }
}

export const brollService = new BRollService();
