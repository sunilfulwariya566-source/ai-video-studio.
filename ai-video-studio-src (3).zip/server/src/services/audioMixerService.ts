export class AudioMixerService {
  public buildAudioMixGraph(project: any) {
    return {
      targetLufs: -14.0,
      peakLimitDb: -1.0,
      sampleRate: 48000,
      tracks: [
        { id: 'trk_voice', name: 'Voiceover', role: 'VOICE', volume: 1.0, duckingDb: 0 },
        { id: 'trk_music', name: 'Background Score', role: 'MUSIC', volume: 0.25, duckingDb: -14.0 },
        { id: 'trk_sfx', name: 'SFX & Stingers', role: 'SFX', volume: 0.6, duckingDb: -6.0 }
      ]
    };
  }
}

export const audioMixerService = new AudioMixerService();
