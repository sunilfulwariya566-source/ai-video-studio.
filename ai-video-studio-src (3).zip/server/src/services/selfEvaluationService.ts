import { SelfEvalReport, SelfEvalIssue, VideoProject } from '../types/index.js';

export class SelfEvaluationService {
  public evaluateProject(project: VideoProject): SelfEvalReport {
    const issues: SelfEvalIssue[] = [];

    if (!project.scenes || project.scenes.length < 2) {
      issues.push({
        id: `eval_script_${Date.now()}_1`,
        component: 'SCRIPT',
        severity: 'WARNING',
        problem: 'Project script has fewer than 2 scenes, which may limit dynamic visual pacing.',
        suggested_fix: 'Add an introductory hook or closing call-to-action scene.',
        auto_fix_available: true
      });
    }

    const scenesWithoutImages = project.scenes?.filter(s => !s.image_url && !s.video_url) || [];
    if (scenesWithoutImages.length > 0) {
      issues.push({
        id: `eval_vis_${Date.now()}_2`,
        component: 'VISUALS',
        severity: 'CRITICAL',
        scene_id: scenesWithoutImages[0].id,
        problem: `Scene ${scenesWithoutImages[0].id} is missing rendered visual media.`,
        suggested_fix: 'Trigger targeted visual re-synthesis for unrendered scenes.',
        auto_fix_available: true
      });
    }

    if (!project.voice_id) {
      issues.push({
        id: `eval_voice_${Date.now()}_3`,
        component: 'VOICE',
        severity: 'WARNING',
        problem: 'No specific voice profile locked in project settings.',
        suggested_fix: 'Assign standard studio narrator voice profile.',
        auto_fix_available: true
      });
    }

    if (!project.music_style) {
      issues.push({
        id: `eval_music_${Date.now()}_4`,
        component: 'MUSIC',
        severity: 'MINOR',
        problem: 'Background music profile is unspecified.',
        suggested_fix: 'Apply dynamic ambient background audio track with -18dB ducking.',
        auto_fix_available: true
      });
    }

    const missingSubs = project.scenes?.some(s => !s.subtitles || s.subtitles.length === 0);
    if (missingSubs) {
      issues.push({
        id: `eval_captions_${Date.now()}_5`,
        component: 'CAPTIONS',
        severity: 'WARNING',
        problem: 'One or more scenes lack synchronized subtitle caption words.',
        suggested_fix: 'Run automated phoneme timestamp extractor.',
        auto_fix_available: true
      });
    }

    if (project.characters && project.characters.length > 0 && !project.asset_bible) {
      issues.push({
        id: `eval_cont_${Date.now()}_6`,
        component: 'CONTINUITY',
        severity: 'MINOR',
        problem: 'Character entities defined without an active locked Asset Bible.',
        suggested_fix: 'Lock seed parameters and prompt modifiers to preserve character face consistency.',
        auto_fix_available: true
      });
    }

    if (!project.thumbnails || project.thumbnails.length === 0) {
      issues.push({
        id: `eval_thumb_${Date.now()}_8`,
        component: 'THUMBNAIL',
        severity: 'MINOR',
        problem: 'No high-CTR thumbnail candidate currently selected.',
        suggested_fix: 'Generate AI thumbnail variants with high-contrast headline overlays.',
        auto_fix_available: true
      });
    }

    const hasCritical = issues.some(i => i.severity === 'CRITICAL');
    const hasWarning = issues.some(i => i.severity === 'WARNING');

    let overallHealth: 'PASS' | 'NEEDS_REPAIR' | 'CRITICAL_BLOCK' = 'PASS';
    let baseScore = 95;

    if (hasCritical) {
      overallHealth = 'CRITICAL_BLOCK';
      baseScore = 65;
    } else if (hasWarning) {
      overallHealth = 'NEEDS_REPAIR';
      baseScore = 82;
    } else if (issues.length > 0) {
      baseScore = 90;
    }

    return {
      project_id: project.id,
      overall_health: overallHealth,
      score: baseScore,
      issues,
      auto_repaired_count: 0,
      evaluated_at: new Date().toISOString()
    };
  }
}

export const selfEvaluationService = new SelfEvaluationService();
