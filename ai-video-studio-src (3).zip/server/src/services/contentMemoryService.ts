import { ProjectMemoryRecord, CharacterEntity, VideoProject } from '../types/index.js';
import fs from 'fs';
import path from 'path';

export class ContentMemoryService {
  private memories: Map<string, ProjectMemoryRecord> = new Map();
  private memoryFile: string;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'storage');
    this.memoryFile = path.join(dataDir, 'content_memory.json');
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.memoryFile)) {
        const raw = fs.readFileSync(this.memoryFile, 'utf-8');
        const list: ProjectMemoryRecord[] = JSON.parse(raw);
        for (const item of list) {
          this.memories.set(item.id, item);
        }
      }
    } catch (e) {
      console.warn('[ContentMemory] Failed to load memory file:', e);
    }
  }

  private persist() {
    try {
      const list = Array.from(this.memories.values());
      fs.writeFileSync(this.memoryFile, JSON.stringify(list, null, 2), 'utf-8');
    } catch (e) {
      console.error('[ContentMemory] Failed to persist memory:', e);
    }
  }

  public recordProjectCompletion(project: VideoProject): ProjectMemoryRecord {
    const successfulPrompts: Array<{ category: string; prompt: string; rating: number }> = [];
    if (project.scenes) {
      for (const scene of project.scenes) {
        if (scene.visual_prompt) {
          successfulPrompts.push({ category: 'visual', prompt: scene.visual_prompt, rating: 0.9 });
        }
      }
    }

    const record: ProjectMemoryRecord = {
      id: `mem_${project.id}`,
      project_id: project.id,
      title: project.title,
      topic: project.topic,
      visual_style: project.style || 'cinematic',
      voice_id: project.voice_id || 'default_voice',
      characters: project.characters || [],
      successful_prompts: successfulPrompts,
      quality_score: project.qc_report?.overall_score || 90,
      created_at: new Date().toISOString()
    };

    this.memories.set(record.id, record);
    this.persist();
    return record;
  }

  public getAllMemories(): ProjectMemoryRecord[] {
    return Array.from(this.memories.values()).sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }

  public findMemoryByTopicOrStyle(query: string): ProjectMemoryRecord | undefined {
    const q = query.toLowerCase();
    for (const mem of this.memories.values()) {
      if (
        mem.topic.toLowerCase().includes(q) ||
        mem.title.toLowerCase().includes(q) ||
        mem.visual_style.toLowerCase().includes(q)
      ) {
        return mem;
      }
    }
    return undefined;
  }
}

export const contentMemoryService = new ContentMemoryService();
