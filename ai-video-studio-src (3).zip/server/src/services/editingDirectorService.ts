export class EditingDirectorService {
  public planTransitions(scenesCount: number) {
    return Array.from({ length: scenesCount }, (_, i) => ({
      scene_id: i + 1,
      transition_in: i === 0 ? 'FADE_IN' : 'WHIP_PAN',
      transition_out: i === scenesCount - 1 ? 'FADE_OUT' : 'CROSS_DISSOLVE',
      pacing_multiplier: 1.0
    }));
  }
}

export const editingDirectorService = new EditingDirectorService();
