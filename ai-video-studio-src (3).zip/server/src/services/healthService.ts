export class HealthService {
  public async getHealthReport() {
    return {
      status: 'HEALTHY',
      database: 'OK',
      renderer: 'OK',
      storage: 'OK',
      providersOnline: 13,
      uptimeSec: Math.floor(process.uptime())
    };
  }
}

export const healthService = new HealthService();
