export class MetadataService {
  public generateMetadata(topic: string, script: string) {
    return {
      seo_title: `${topic} (The Full Story Explained)`,
      description: `Dive deep into ${topic}. Everything you need to understand the science, implications, and future.`,
      tags: [topic, 'Science', 'Documentary', 'Technology', 'Future', '2026', 'AI'],
      category: 'Education',
      chapters: [
        { start_time: '00:00', title: 'The Enigma' },
        { start_time: '00:15', title: 'The Breakthrough' },
        { start_time: '00:45', title: 'The Impact' }
      ]
    };
  }
}

export const metadataService = new MetadataService();
