export class CostBudgetService {
  public calculateCost(project: any) {
    return {
      projectId: project.id,
      estimated_cost: 0.05,
      actual_cost: 0.042,
      currency: 'USD',
      breakdown: {
        llm_scriptwriting: 0.008,
        tts_synthesis: 0.012,
        visual_generation: 0.016,
        ffmpeg_rendering: 0.006
      }
    };
  }
}

export const costBudgetService = new CostBudgetService();
