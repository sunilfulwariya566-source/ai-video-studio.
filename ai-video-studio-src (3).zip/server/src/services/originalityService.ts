import { DuplicateDetectionResult, OriginalitySuggestion, VideoProject } from '../types/index.js';
import { projectStore } from '../database/projectStore.js';

export class OriginalityService {
  public checkDuplicateContent(topic: string, scriptText?: string): DuplicateDetectionResult {
    const existingProjects = projectStore.getAllProjects();
    const cleanTopic = topic.toLowerCase().trim();

    for (const proj of existingProjects) {
      const projTopic = (proj.topic || proj.title || '').toLowerCase().trim();
      if (!projTopic) continue;

      if (cleanTopic === projTopic || (cleanTopic.length > 5 && projTopic.includes(cleanTopic))) {
        return {
          is_duplicate: true,
          similarity_score: 0.94,
          matched_project_id: proj.id,
          matched_project_title: proj.title,
          warning_message: `High similarity detected with existing project: "${proj.title}". Consider using the Originality Assistant to develop a fresh narrative angle.`,
          similar_sections: ['Core premise', 'Primary introductory hook']
        };
      }
    }

    return {
      is_duplicate: false,
      similarity_score: 0.12,
      similar_sections: []
    };
  }

  public getOriginalitySuggestions(topic: string): OriginalitySuggestion {
    return {
      narrative_angle_alt: `Shift focus from generic overview of "${topic}" to a forensic breakdown of the unseen failure modes and hidden turning points.`,
      structure_recommendation: 'Invert traditional chronology: start with the climax or paradoxical consequence in Scene 1 before unveiling the foundational backstory in Scene 2.',
      fresh_examples: [
        `Contrast ${topic} against biological evolutionary systems for unique conceptual resonance.`,
        'Incorporate a real-world case study from an adjacent unrelated industry.'
      ],
      visual_metaphor: 'Use dynamic architectural blueprints dissolving into biological neural networks with anamorphic depth of field.',
      unique_hook_variations: [
        `"Why the smartest minds in ${topic} were completely wrong until now..."`,
        `"If you analyze the microscopic details of ${topic}, one anomaly changes everything."`
      ]
    };
  }
}

export const originalityService = new OriginalityService();
