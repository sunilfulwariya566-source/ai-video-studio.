export class ShortsService {
  public extractShorts(project: any) {
    return [
      {
        id: 'short_1',
        title: `${project.title} - The Hook`,
        aspect_ratio: '9:16',
        start_time_seconds: 0,
        duration_seconds: 15,
        hook_text: 'You wont believe this breakthrough...',
        captions_style: 'DYNAMIC_KARAOKE',
        video_url: `/storage/renders/${project.id}_9_16.mp4`,
        thumbnail_url: '/storage/visuals/scene_1.png'
      },
      {
        id: 'short_2',
        title: `${project.title} - The Reveal`,
        aspect_ratio: '9:16',
        start_time_seconds: 15,
        duration_seconds: 15,
        hook_text: 'Here is how it actually works...',
        captions_style: 'BOLD_CENTERED',
        video_url: `/storage/renders/${project.id}_9_16.mp4`,
        thumbnail_url: '/storage/visuals/scene_2.png'
      }
    ];
  }
}

export const shortsService = new ShortsService();
