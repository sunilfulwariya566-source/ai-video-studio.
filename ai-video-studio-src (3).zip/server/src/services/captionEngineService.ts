import { SubtitleEntry } from '../types/index.js';
import fs from 'fs';
import path from 'path';

export class CaptionEngineService {
  public generateSubtitleEntries(scenes: any[]): SubtitleEntry[] {
    const entries: SubtitleEntry[] = [];
    let currentTime = 0;

    for (let i = 0; i < scenes.length; i++) {
      const s = scenes[i];
      const dur = s.duration || 5;
      entries.push({
        id: i + 1,
        startTime: currentTime,
        endTime: currentTime + dur,
        text: s.narration || '',
        words: s.word_timings || [
          { word: 'Caption', start: currentTime, end: currentTime + dur }
        ]
      });
      currentTime += dur;
    }
    return entries;
  }

  public generateSRT(entries: SubtitleEntry[], projectId: string): { srtContent: string; filePath: string } {
    let srt = '';
    for (const e of entries) {
      const formatTime = (sec: number) => {
        const hrs = Math.floor(sec / 3600).toString().padStart(2, '0');
        const mins = Math.floor((sec % 3600) / 60).toString().padStart(2, '0');
        const secs = Math.floor(sec % 60).toString().padStart(2, '0');
        const ms = Math.floor((sec % 1) * 1000).toString().padStart(3, '0');
        return `${hrs}:${mins}:${secs},${ms}`;
      };
      srt += `${e.id}\n${formatTime(e.startTime)} --> ${formatTime(e.endTime)}\n${e.text}\n\n`;
    }

    const targetDir = path.resolve(process.cwd(), 'storage/subtitles');
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
    const filePath = path.join(targetDir, `${projectId}.srt`);
    fs.writeFileSync(filePath, srt, 'utf-8');

    return { srtContent: srt, filePath };
  }

  public generateVTT(entries: SubtitleEntry[], projectId: string): { vttContent: string; filePath: string } {
    let vtt = 'WEBVTT\n\n';
    for (const e of entries) {
      const formatTime = (sec: number) => {
        const hrs = Math.floor(sec / 3600).toString().padStart(2, '0');
        const mins = Math.floor((sec % 3600) / 60).toString().padStart(2, '0');
        const secs = Math.floor(sec % 60).toString().padStart(2, '0');
        const ms = Math.floor((sec % 1) * 1000).toString().padStart(3, '0');
        return `${hrs}:${mins}:${secs}.${ms}`;
      };
      vtt += `${e.id}\n${formatTime(e.startTime)} --> ${formatTime(e.endTime)}\n${e.text}\n\n`;
    }

    const targetDir = path.resolve(process.cwd(), 'storage/subtitles');
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
    const filePath = path.join(targetDir, `${projectId}.vtt`);
    fs.writeFileSync(filePath, vtt, 'utf-8');

    return { vttContent: vtt, filePath };
  }

  public getPresetConfig(preset: string) {
    return {
      fontName: 'Montserrat-Bold',
      fontSize: 24,
      primaryColor: '&H00FFFFFF',
      outlineColor: '&H00000000',
      alignment: 2,
      marginV: 60
    };
  }

  public generateASS(entries: SubtitleEntry[], style: any, projectId: string): { assContent: string; filePath: string } {
    let ass = `[Script Info]\nScriptType: v4.00+\n\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,${style.fontName},${style.fontSize},${style.primaryColor},&H000000FF,${style.outlineColor},&H80000000,1,0,0,0,100,100,0,0,1,2,0,${style.alignment},20,20,${style.marginV},1\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n`;

    for (const e of entries) {
      const formatTime = (sec: number) => {
        const hrs = Math.floor(sec / 3600).toString().padStart(1, '0');
        const mins = Math.floor((sec % 3600) / 60).toString().padStart(2, '0');
        const secs = Math.floor(sec % 60).toString().padStart(2, '0');
        const cs = Math.floor((sec % 1) * 100).toString().padStart(2, '0');
        return `${hrs}:${mins}:${secs}.${cs}`;
      };
      ass += `Dialogue: 0,${formatTime(e.startTime)},${formatTime(e.endTime)},Default,,0,0,0,,${e.text}\n`;
    }

    const targetDir = path.resolve(process.cwd(), 'storage/subtitles');
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
    const filePath = path.join(targetDir, `${projectId}.ass`);
    fs.writeFileSync(filePath, ass, 'utf-8');

    return { assContent: ass, filePath };
  }
}

export const captionEngineService = new CaptionEngineService();
