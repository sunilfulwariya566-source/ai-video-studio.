import crypto from 'crypto';

export class AssetCacheService {
  private cache: Map<string, any> = new Map();

  public generateFingerprint(params: Record<string, any>): string {
    const sorted = JSON.stringify(params, Object.keys(params).sort());
    return crypto.createHash('sha256').update(sorted).digest('hex');
  }

  public getCachedAsset(fingerprint: string, forceRegenerate: boolean = false): any | null {
    if (forceRegenerate) return null;
    return this.cache.get(fingerprint) || null;
  }

  public setCachedAsset(fingerprint: string, asset: any): void {
    this.cache.set(fingerprint, asset);
  }
}

export const assetCacheService = new AssetCacheService();
