import { PublishingChecklist, PublishingConnector, PublishRecord, VideoProject } from '../types/index.js';
import { projectStore } from '../database/projectStore.js';
import { auditLogService } from './auditLogService.js';
import fs from 'fs';
import path from 'path';

export interface ExtendedPublishingConnector extends PublishingConnector {
  api_key?: string;
  oauth_token?: string;
  client_id?: string;
  mode?: 'SIMULATED' | 'LIVE_OAUTH';
  last_tested_at?: string;
}

export class PublishingService {
  private connectors: Map<string, ExtendedPublishingConnector> = new Map();
  private publishRecords: Map<string, PublishRecord> = new Map();
  private storeFile: string;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'storage');
    this.storeFile = path.join(dataDir, 'connectors.json');
    this.load();

    if (this.connectors.size === 0) {
      this.connectors.set('YOUTUBE', {
        platform: 'YOUTUBE',
        connected: true,
        account_name: 'Studio Master Channel',
        channel_id: 'UC_ai_studio_official',
        mode: 'SIMULATED'
      });
      this.connectors.set('TIKTOK', {
        platform: 'TIKTOK',
        connected: true,
        account_name: '@studio_shorts_ai',
        channel_id: 'tiktok_shorts_hub',
        mode: 'SIMULATED'
      });
      this.connectors.set('TWITTER_X', {
        platform: 'TWITTER_X',
        connected: true,
        account_name: '@AIStudioEngine',
        mode: 'SIMULATED'
      });
      this.connectors.set('INSTAGRAM', {
        platform: 'INSTAGRAM',
        connected: false,
        account_name: 'Not Connected',
        mode: 'SIMULATED'
      });
      this.persist();
    }
  }

  private load() {
    try {
      if (fs.existsSync(this.storeFile)) {
        const list: ExtendedPublishingConnector[] = JSON.parse(fs.readFileSync(this.storeFile, 'utf-8'));
        for (const item of list) {
          this.connectors.set(item.platform, item);
        }
      }
    } catch (e) {
      console.warn('[PublishingService] Could not load connectors:', e);
    }
  }

  private persist() {
    try {
      const list = Array.from(this.connectors.values());
      fs.writeFileSync(this.storeFile, JSON.stringify(list, null, 2), 'utf-8');
    } catch (e) {
      console.error('[PublishingService] Failed to persist connectors:', e);
    }
  }

  public getConnectors(): ExtendedPublishingConnector[] {
    return Array.from(this.connectors.values()).map(c => {
      const copy = { ...c };
      if (copy.api_key) copy.api_key = copy.api_key.slice(0, 4) + '****';
      if (copy.oauth_token) copy.oauth_token = '****';
      return copy;
    });
  }

  public connectPlatform(options: {
    platform: 'YOUTUBE' | 'TIKTOK' | 'INSTAGRAM' | 'TWITTER_X';
    accountName?: string;
    channelId?: string;
    apiKey?: string;
    oauthToken?: string;
    mode?: 'SIMULATED' | 'LIVE_OAUTH';
  }): ExtendedPublishingConnector {
    const existing = this.connectors.get(options.platform) || { platform: options.platform, connected: false };
    const updated: ExtendedPublishingConnector = {
      ...existing,
      platform: options.platform,
      connected: true,
      account_name: options.accountName || (options.platform === 'YOUTUBE' ? 'My YouTube Channel' : '@my_channel'),
      channel_id: options.channelId || (options.platform === 'YOUTUBE' ? 'UC_' + Math.random().toString(36).substring(2, 10) : undefined),
      api_key: options.apiKey,
      oauth_token: options.oauthToken,
      mode: options.mode || 'SIMULATED',
      last_tested_at: new Date().toISOString()
    };

    this.connectors.set(options.platform, updated);
    this.persist();

    auditLogService.logAction({
      action: 'PUBLISHING_AUTHORIZED',
      user_id: 'user_admin',
      user_name: 'Studio Admin',
      details: 'Connected platform: ' + options.platform + ' (' + updated.account_name + ')'
    });

    return updated;
  }

  public disconnectPlatform(platform: 'YOUTUBE' | 'TIKTOK' | 'INSTAGRAM' | 'TWITTER_X'): boolean {
    const connector = this.connectors.get(platform);
    if (connector) {
      connector.connected = false;
      connector.api_key = undefined;
      connector.oauth_token = undefined;
      this.persist();
      return true;
    }
    return false;
  }

  public validatePublishingChecklist(project: VideoProject): PublishingChecklist {
    const hasVideo = !!(project.final_video_url || project.video_url);
    const qcPassed = !!(project.qc_report?.passed ?? true);
    const safetyPassed = !(project.safety_report?.flagged ?? false);
    const hasThumbnail = (project.thumbnails && project.thumbnails.length > 0) || (project.generated_thumbnails && project.generated_thumbnails.length > 0) || false;
    const hasTitle = !!(project.title && project.title.length >= 3);
    const hasDesc = !!(project.idea || project.topic);
    const hasMeta = !!(project.auto_metadata || project.topic);
    const formatOk = !!(project.format && ['16:9', '9:16', '1:1', '4:5'].includes(project.format));
    const userApproved = true;

    const blockingReasons: string[] = [];
    if (!hasVideo) blockingReasons.push('Final master video file has not been rendered.');
    if (!qcPassed) blockingReasons.push('Quality control gate flagged uncorrected anomalies.');
    if (!safetyPassed) blockingReasons.push('Safety moderation gate flagged sensitive terms.');
    if (!hasThumbnail) blockingReasons.push('High-CTR thumbnail candidate must be selected.');
    if (!hasTitle) blockingReasons.push('Video project title is missing or incomplete.');

    const isReady = blockingReasons.length === 0;

    const checklist: PublishingChecklist = {
      final_video_exists: hasVideo,
      render_qc_passed: qcPassed,
      safety_check_passed: safetyPassed,
      thumbnail_selected: hasThumbnail,
      title_selected: hasTitle,
      description_ready: hasDesc,
      metadata_ready: hasMeta,
      format_validated: formatOk,
      user_approval_completed: userApproved,
      is_ready_to_publish: isReady,
      blocking_reasons: blockingReasons
    };

    project.publishing_checklist = checklist;
    projectStore.saveProject(project);

    return checklist;
  }

  public async publishToPlatform(options: {
    projectId: string;
    platform: 'YOUTUBE' | 'TIKTOK' | 'INSTAGRAM' | 'TWITTER_X';
    authorizedBy: string;
  }): Promise<PublishRecord> {
    const project = projectStore.getProject(options.projectId);
    if (!project) throw new Error('Project ' + options.projectId + ' not found.');

    const checklist = this.validatePublishingChecklist(project);
    if (!checklist.is_ready_to_publish) {
      throw new Error('Cannot publish: Checklist blocked by: ' + checklist.blocking_reasons.join(', '));
    }

    const connector = this.connectors.get(options.platform);
    if (!connector || !connector.connected) {
      throw new Error('Publishing connector for ' + options.platform + ' is not connected. Please click "Connect Account" in the publishing panel.');
    }

    let publishedUrl = '';
    if (options.platform === 'YOUTUBE') {
      publishedUrl = 'https://youtube.com/watch?v=ai_studio_' + Date.now().toString(36);
    } else if (options.platform === 'TIKTOK') {
      publishedUrl = 'https://tiktok.com/@' + (connector.account_name ? connector.account_name.replace('@','') : 'studio') + '/video/' + Date.now();
    } else if (options.platform === 'TWITTER_X') {
      publishedUrl = 'https://x.com/status/' + Date.now();
    } else {
      publishedUrl = 'https://instagram.com/reel/mock_' + Date.now();
    }

    const record: PublishRecord = {
      id: 'pub_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      project_id: options.projectId,
      platform: options.platform,
      published_url: publishedUrl,
      status: 'PUBLISHED',
      published_at: new Date().toISOString(),
      authorized_by: options.authorizedBy
    };

    this.publishRecords.set(record.id, record);

    auditLogService.logAction({
      action: 'PUBLISHING_AUTHORIZED',
      user_id: options.authorizedBy,
      user_name: options.authorizedBy,
      project_id: options.projectId,
      details: 'Published to ' + options.platform + ' via channel "' + (connector.account_name || 'Studio Channel') + '"'
    });

    return record;
  }

  public getPublishHistory(projectId?: string): PublishRecord[] {
    let list = Array.from(this.publishRecords.values());
    if (projectId) list = list.filter(r => r.project_id === projectId);
    return list.sort((a, b) => new Date(b.published_at || 0).getTime() - new Date(a.published_at || 0).getTime());
  }
}

export const publishingService = new PublishingService();
