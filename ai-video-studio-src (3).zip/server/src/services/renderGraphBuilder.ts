export class RenderGraphBuilder {
  public buildRenderGraph(project: any, format: string = '16:9', isDraft: boolean = false) {
    const isVertical = format === '9:16';
    const width = isVertical ? 1080 : 1920;
    const height = isVertical ? 1920 : 1080;

    return {
      nodes: project.scenes?.map((s: any, idx: number) => ({
        id: `node_${idx + 1}`,
        type: 'TRANSFORM',
        params: { shot_type: s.shot_type || 'WIDE', camera: s.camera_movement || 'PAN' },
        inputs: []
      })) || [{ id: 'node_1', type: 'TRANSFORM', params: {}, inputs: [] }],
      formatProfile: {
        width,
        height,
        fps: 30,
        aspectRatio: format,
        safeAreaMargins: { topPercent: 5, bottomPercent: isVertical ? 18 : 5, leftPercent: 5, rightPercent: 5 }
      },
      durationSeconds: project.target_duration_seconds || 30
    };
  }
}

export const renderGraphBuilder = new RenderGraphBuilder();
