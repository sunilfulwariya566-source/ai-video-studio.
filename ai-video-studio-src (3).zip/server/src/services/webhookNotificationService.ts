import { WebhookSubscription, NotificationItem } from '../types/index.js';

export class WebhookNotificationService {
  private webhooks: Map<string, WebhookSubscription> = new Map();
  private notifications: NotificationItem[] = [];

  constructor() {
    this.notifications.push({
      id: 'notif_init_1',
      type: 'SUCCESS',
      title: 'AI Video Factory Initialized',
      message: 'Autonomous Phase 6 multi-agent engine ready with zero-cost mock operation.',
      timestamp: new Date().toISOString(),
      read: false
    });
  }

  public registerWebhook(targetUrl: string, events: string[]): WebhookSubscription {
    const sub: WebhookSubscription = {
      id: 'wh_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      target_url: targetUrl,
      secret_token: 'whsec_' + Math.random().toString(36).substring(2, 10),
      subscribed_events: events,
      enabled: true,
      failure_count: 0
    };
    this.webhooks.set(sub.id, sub);
    return sub;
  }

  public getWebhooks(): WebhookSubscription[] {
    return Array.from(this.webhooks.values());
  }

  public dispatchEvent(eventName: string, payload: any): void {
    for (const sub of this.webhooks.values()) {
      if (sub.enabled && (sub.subscribed_events.includes(eventName) || sub.subscribed_events.includes('*'))) {
        sub.last_dispatched_at = new Date().toISOString();
        // In real environment, would make signed HTTP POST
      }
    }
  }

  public addNotification(notification: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>): NotificationItem {
    const item: NotificationItem = {
      ...notification,
      id: 'notif_' + Date.now(),
      timestamp: new Date().toISOString(),
      read: false
    };
    this.notifications.unshift(item);
    if (this.notifications.length > 50) this.notifications.pop();
    return item;
  }

  public getNotifications(): NotificationItem[] {
    return this.notifications;
  }

  public markAsRead(id: string): void {
    const n = this.notifications.find(item => item.id === id);
    if (n) n.read = true;
  }
}

export const webhookNotificationService = new WebhookNotificationService();
