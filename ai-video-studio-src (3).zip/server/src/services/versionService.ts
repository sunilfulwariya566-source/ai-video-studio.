export class VersionService {
  public createSnapshot(project: any, notes: string = 'Autosave') {
    return {
      version_id: 'ver_' + Date.now(),
      version_number: '1.0.0',
      notes,
      created_at: new Date().toISOString(),
      snapshot_data: JSON.parse(JSON.stringify(project))
    };
  }
}

export const versionService = new VersionService();
