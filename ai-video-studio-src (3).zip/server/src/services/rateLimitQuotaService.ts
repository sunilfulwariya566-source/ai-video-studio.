export class RateLimitQuotaService {
  private limits: Map<string, { requestsPerMin: number; currentCount: number; cooldownUntil: number }> = new Map();

  constructor() {
    this.limits.set('openai', { requestsPerMin: 60, currentCount: 0, cooldownUntil: 0 });
    this.limits.set('elevenlabs', { requestsPerMin: 30, currentCount: 0, cooldownUntil: 0 });
    this.limits.set('flux', { requestsPerMin: 40, currentCount: 0, cooldownUntil: 0 });
  }

  public checkQuota(providerId: string): { allowed: boolean; cooldownRemainingMs: number } {
    const limit = this.limits.get(providerId);
    if (!limit) return { allowed: true, cooldownRemainingMs: 0 };

    const now = Date.now();
    if (now < limit.cooldownUntil) {
      return { allowed: false, cooldownRemainingMs: limit.cooldownUntil - now };
    }

    return { allowed: true, cooldownRemainingMs: 0 };
  }

  public recordRequest(providerId: string): void {
    const limit = this.limits.get(providerId);
    if (limit) {
      limit.currentCount++;
      if (limit.currentCount >= limit.requestsPerMin) {
        limit.cooldownUntil = Date.now() + 60000;
        limit.currentCount = 0;
      }
    }
  }
}

export const rateLimitQuotaService = new RateLimitQuotaService();
