import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export class AssetStorageService {
  public async storeAsset(options: {
    projectId: string;
    type: 'IMAGE' | 'AUDIO' | 'VIDEO' | 'SUBTITLE' | 'JSON';
    provider: string;
    prompt: string;
    bufferOrSourcePath: Buffer | string;
    extension: string;
  }): Promise<{ id: string; hashSha256: string; filePath: string }> {
    const content = Buffer.isBuffer(options.bufferOrSourcePath)
      ? options.bufferOrSourcePath
      : Buffer.from(options.bufferOrSourcePath);

    const hash = crypto.createHash('sha256').update(content).digest('hex');
    const filename = `${options.projectId}_${hash.slice(0, 12)}.${options.extension}`;
    const targetDir = path.resolve(process.cwd(), 'storage', options.type.toLowerCase() + 's');
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });

    const filePath = path.join(targetDir, filename);
    fs.writeFileSync(filePath, content);

    return {
      id: `ast_${hash.slice(0, 10)}`,
      hashSha256: hash,
      filePath
    };
  }
}

export const assetStorageService = new AssetStorageService();
