import { ExperimentTest, ExperimentVariant } from '../types/index.js';

export class ExperimentService {
  private tests: Map<string, ExperimentTest> = new Map();

  public createTest(projectId: string, testName: string, variants: Array<{ name: string; type: ExperimentVariant['type']; content: string }>): ExperimentTest {
    const experimentVariants: ExperimentVariant[] = variants.map((v, i) => ({
      id: 'var_' + (i + 1),
      name: v.name,
      type: v.type,
      content: v.content,
      views: 0,
      ctr: 0,
      retention_score: 0
    }));

    const test: ExperimentTest = {
      id: 'exp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      project_id: projectId,
      test_name: testName,
      variants: experimentVariants,
      is_statistically_significant: false,
      status: 'RUNNING',
      created_at: new Date().toISOString()
    };

    this.tests.set(test.id, test);
    return test;
  }

  public recordImpression(testId: string, variantId: string, clicked: boolean): void {
    const test = this.tests.get(testId);
    if (!test) return;

    const variant = test.variants.find(v => v.id === variantId);
    if (variant) {
      variant.views++;
      const currentClicks = Math.round((variant.ctr / 100) * (variant.views - 1)) + (clicked ? 1 : 0);
      variant.ctr = parseFloat(((currentClicks / variant.views) * 100).toFixed(2));
    }

    if (test.variants.every(v => v.views > 20)) {
      test.is_statistically_significant = true;
      const sorted = [...test.variants].sort((a, b) => b.ctr - a.ctr);
      test.winning_variant_id = sorted[0].id;
    }
  }

  public getTestsForProject(projectId: string): ExperimentTest[] {
    return Array.from(this.tests.values()).filter(t => t.project_id === projectId);
  }
}

export const experimentService = new ExperimentService();
