import { VideoProject } from '../types/index.js';
import { projectStore } from '../database/projectStore.js';

export interface ProjectPackage {
  manifest_version: string;
  exported_at: string;
  project: VideoProject;
  asset_inventory: Array<{ id: string; type: string; path: string }>;
}

export class ProjectPackageService {
  public exportPackage(projectId: string): ProjectPackage {
    const project = projectStore.getProject(projectId);
    if (!project) throw new Error(`Project ${projectId} not found.`);

    const assets = projectStore.getAssetsByProject(projectId);

    return {
      manifest_version: '1.0.0',
      exported_at: new Date().toISOString(),
      project,
      asset_inventory: assets.map(a => ({
        id: a.id,
        type: a.assetType,
        path: a.filePath
      }))
    };
  }

  public importPackage(pkg: ProjectPackage): VideoProject {
    const newProjectId = 'proj_imp_' + Date.now();
    const importedProject: VideoProject = {
      ...pkg.project,
      id: newProjectId,
      title: `${pkg.project.title} (Imported)`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    projectStore.saveProject(importedProject);
    return importedProject;
  }
}

export const projectPackageService = new ProjectPackageService();
