import { ProductionQueueJob, JobState } from '../types/index.js';

export class JobQueueService {
  private jobs: Map<string, ProductionQueueJob> = new Map();

  public enqueueJob(options: { jobId: string; projectId: string; priority?: 'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW' }): ProductionQueueJob {
    const job: ProductionQueueJob = {
      jobId: options.jobId,
      projectId: options.projectId,
      priority: options.priority || 'NORMAL',
      state: 'QUEUED',
      progress: 0,
      currentStage: 'INIT',
      retryCount: 0,
      maxRetries: 3,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      checkpointData: { completedStages: [], persistedAssetIds: [] }
    };
    this.jobs.set(job.jobId, job);
    return job;
  }

  public updateJobState(jobId: string, state: JobState, progress?: number, stage?: string): ProductionQueueJob | undefined {
    const job = this.jobs.get(jobId);
    if (job) {
      job.state = state;
      if (progress !== undefined) job.progress = progress;
      if (stage) job.currentStage = stage;
      job.updatedAt = new Date().toISOString();
    }
    return job;
  }

  public recordStageCheckpoint(jobId: string, stage: string, assetId?: string): void {
    const job = this.jobs.get(jobId);
    if (job && job.checkpointData) {
      if (!job.checkpointData.completedStages.includes(stage)) {
        job.checkpointData.completedStages.push(stage);
      }
      if (assetId && !job.checkpointData.persistedAssetIds.includes(assetId)) {
        job.checkpointData.persistedAssetIds.push(assetId);
      }
    }
  }

  public getJob(jobId: string): ProductionQueueJob | undefined {
    return this.jobs.get(jobId);
  }
}

export const jobQueueService = new JobQueueService();
