import { FeatureFlagConfig } from '../types/index.js';

export class FeatureFlagService {
  private flags: FeatureFlagConfig = {
    ENABLE_LIP_SYNC: true,
    ENABLE_AUTO_SHORTS: true,
    ENABLE_AI_REPAIR: true,
    ENABLE_ANALYTICS: true,
    ENABLE_PUBLISHING: true,
    ENABLE_ADVANCED_VFX: true,
    ENABLE_COLLABORATION: true,
    ENABLE_MULTI_LANGUAGE: true
  };

  public getFlags(): FeatureFlagConfig {
    return { ...this.flags };
  }

  public setFlag(key: keyof FeatureFlagConfig, value: boolean): FeatureFlagConfig {
    this.flags[key] = value;
    return { ...this.flags };
  }
}

export const featureFlagService = new FeatureFlagService();
