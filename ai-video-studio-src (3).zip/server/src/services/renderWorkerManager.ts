import { RenderWorkerNode } from '../types/index.js';

export class RenderWorkerManager {
  private nodes: Map<string, RenderWorkerNode> = new Map();

  constructor() {
    this.nodes.set('node_cpu_local', {
      id: 'node_cpu_local',
      name: 'Primary CPU Worker Pool (FFmpeg Multi-Threaded)',
      type: 'LOCAL_CPU',
      status: 'IDLE',
      active_jobs: 0,
      max_concurrency: 4,
      hardware_info: '8 Cores @ 3.6GHz AVX-512'
    });

    this.nodes.set('node_gpu_local', {
      id: 'node_gpu_local',
      name: 'Hardware Accelerated NVENC / Metal Node',
      type: 'LOCAL_GPU',
      status: 'IDLE',
      active_jobs: 0,
      max_concurrency: 2,
      hardware_info: 'NVIDIA RTX 4090 24GB VRAM'
    });
  }

  public getNodes(): RenderWorkerNode[] {
    return Array.from(this.nodes.values());
  }

  public registerNode(node: RenderWorkerNode): RenderWorkerNode {
    this.nodes.set(node.id, node);
    return node;
  }

  public assignJob(): RenderWorkerNode {
    for (const node of this.nodes.values()) {
      if (node.status === 'IDLE' && node.active_jobs < node.max_concurrency) {
        node.active_jobs++;
        return node;
      }
    }
    // Fallback to CPU worker
    const fallback = this.nodes.get('node_cpu_local')!;
    fallback.active_jobs++;
    return fallback;
  }

  public releaseJob(nodeId: string): void {
    const node = this.nodes.get(nodeId);
    if (node && node.active_jobs > 0) {
      node.active_jobs--;
      if (node.active_jobs === 0) node.status = 'IDLE';
    }
  }
}

export const renderWorkerManager = new RenderWorkerManager();
