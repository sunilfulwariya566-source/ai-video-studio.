import { WatermarkConfig, AssetRecord } from '../types/index.js';
import { projectStore } from '../database/projectStore.js';

export class MediaRightsWatermarkService {
  private watermarkConfig: WatermarkConfig = {
    enabled: true,
    brand_text: 'AI VIDEO FACTORY',
    position: 'BOTTOM_RIGHT',
    opacity: 0.75,
    scale_percent: 15,
    safe_area_compliant: true
  };

  public getWatermarkConfig(): WatermarkConfig {
    return this.watermarkConfig;
  }

  public updateWatermarkConfig(config: Partial<WatermarkConfig>): WatermarkConfig {
    this.watermarkConfig = { ...this.watermarkConfig, ...config };
    return this.watermarkConfig;
  }

  public tagAssetRights(assetId: string, rights: 'GENERATED' | 'USER_OWNED' | 'LICENSED' | 'PUBLIC_DOMAIN' | 'UNKNOWN'): AssetRecord | undefined {
    const assets = projectStore.getAllAssets();
    const asset = assets.find(a => a.id === assetId);
    if (asset) {
      asset.rightsStatus = rights;
      projectStore.saveAsset(asset);
    }
    return asset;
  }

  public getRightsAuditForProject(projectId: string): {
    totalAssets: number;
    generated: number;
    userOwned: number;
    licensed: number;
    publicDomain: number;
    unknown: number;
    complianceScore: number;
  } {
    const assets = projectStore.getAssetsByProject(projectId);
    let gen = 0, user = 0, lic = 0, pub = 0, unk = 0;

    for (const a of assets) {
      const status = a.rightsStatus || 'GENERATED';
      if (status === 'GENERATED') gen++;
      else if (status === 'USER_OWNED') user++;
      else if (status === 'LICENSED') lic++;
      else if (status === 'PUBLIC_DOMAIN') pub++;
      else unk++;
    }

    const total = assets.length || 1;
    const compliance = parseFloat((((total - unk) / total) * 100).toFixed(1));

    return {
      totalAssets: assets.length,
      generated: gen,
      userOwned: user,
      licensed: lic,
      publicDomain: pub,
      unknown: unk,
      complianceScore: compliance
    };
  }
}

export const mediaRightsWatermarkService = new MediaRightsWatermarkService();
