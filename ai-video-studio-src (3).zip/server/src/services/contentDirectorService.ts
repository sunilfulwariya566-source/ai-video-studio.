import { DirectorDecision, WorkflowPlan } from '../types/index.js';
import { workflowPlannerService } from './workflowPlannerService.js';

export interface DirectorAnalyzeOptions {
  projectId: string;
  topic: string;
  prompt?: string;
  targetAudience?: string;
  format?: '16:9' | '9:16' | '1:1' | '4:5';
  targetDurationSeconds?: number;
  qualityTier?: 'FAST_DRAFT' | 'STUDIO_HD' | 'ULTRA_CINEMATIC';
}

export class ContentDirectorService {
  public analyzeAndDirect(options: DirectorAnalyzeOptions): {
    decision: DirectorDecision;
    workflowPlan: WorkflowPlan;
  } {
    const topicLower = (options.topic + ' ' + (options.prompt || '')).toLowerCase();
    const duration = options.targetDurationSeconds || 30;
    const format = options.format || '16:9';
    const qualityTier = options.qualityTier || 'STUDIO_HD';

    let complexity: 'SIMPLE' | 'STANDARD' | 'CINEMATIC_COMPLEX' = 'STANDARD';
    if (duration > 60 || qualityTier === 'ULTRA_CINEMATIC') {
      complexity = 'CINEMATIC_COMPLEX';
    } else if (duration <= 15 && qualityTier === 'FAST_DRAFT') {
      complexity = 'SIMPLE';
    }

    let visualStyle = 'cinematic_photorealistic';
    let voiceStyle = 'authoritative_narrator';
    let template = 'documentary_spotlight';
    let pacing = 'dynamic_balanced';

    if (topicLower.includes('tech') || topicLower.includes('ai') || topicLower.includes('future')) {
      visualStyle = 'cyberpunk_neon_tech';
      voiceStyle = 'modern_tech_enthusiast';
      template = 'tech_breakdown';
      pacing = 'high_energy_fast';
    }

    const requiresBRoll = duration >= 25;
    const requiresVfx = qualityTier !== 'FAST_DRAFT';
    const requiresLipsync = topicLower.includes('interview') || topicLower.includes('character');
    const requiresShorts = format === '16:9' || duration >= 30;

    const aspectRatios: Array<'16:9' | '9:16' | '1:1' | '4:5'> = [format];
    if (format === '16:9') aspectRatios.push('9:16');

    const decision: DirectorDecision = {
      objective_summary: `Directing an impactful ${complexity.toLowerCase()} video about "${options.topic}" optimized for ${options.targetAudience || 'broad digital audience'}.`,
      creative_angle: 'Engaging visual hook transitioning into clear structured narrative with strong call-to-action.',
      pacing_curve: pacing,
      quality_tier: qualityTier,
      tone_instructions: `Maintain ${voiceStyle.replace(/_/g, ' ')} audio delivery complemented by high-fidelity ${visualStyle.replace(/_/g, ' ')} visuals.`,
      aspect_ratios_to_generate: aspectRatios
    };

    const workflowPlan = workflowPlannerService.generatePlan({
      projectId: options.projectId,
      topic: options.topic,
      targetAudience: options.targetAudience || 'General Audience',
      complexity,
      templateRecommended: template,
      visualStyleRecommended: visualStyle,
      voiceStyleRecommended: voiceStyle,
      requiresBRoll,
      requiresVfx,
      requiresLipsync,
      requiresShorts
    });

    return { decision, workflowPlan };
  }
}

export const contentDirectorService = new ContentDirectorService();
