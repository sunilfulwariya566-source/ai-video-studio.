import { WorkflowPlan, WorkflowStagePlan } from '../types/index.js';

export interface PlanGenerationOptions {
  projectId: string;
  topic: string;
  targetAudience: string;
  complexity: 'SIMPLE' | 'STANDARD' | 'CINEMATIC_COMPLEX';
  templateRecommended: string;
  visualStyleRecommended: string;
  voiceStyleRecommended: string;
  requiresBRoll: boolean;
  requiresVfx: boolean;
  requiresLipsync: boolean;
  requiresShorts: boolean;
}

export class WorkflowPlannerService {
  private plans: Map<string, WorkflowPlan> = new Map();

  public generatePlan(options: PlanGenerationOptions): WorkflowPlan {
    const isCinematic = options.complexity === 'CINEMATIC_COMPLEX';
    const isSimple = options.complexity === 'SIMPLE';

    const stageDefinitions = [
      { stage: 'RESEARCH', name: 'Topic Research & Fact-Finding', required: true, durationSec: 4, costUsd: 0.02, reason: 'Gather facts, statistics, and domain context' },
      { stage: 'SCRIPT_WRITING', name: 'Narrative & Scriptwriting', required: true, durationSec: 5, costUsd: 0.03, reason: 'Generate high-retention scene breakdown' },
      { stage: 'FACT_CHECK', name: 'Automated Fact-Checking Gate', required: !isSimple, durationSec: 3, costUsd: 0.01, reason: 'Verify claims against verified knowledge bases' },
      { stage: 'ASSET_BIBLE', name: 'Asset Bible & Character Locks', required: isCinematic, durationSec: 3, costUsd: 0.02, reason: 'Ensure cross-scene visual and facial continuity' },
      { stage: 'VOICE_GENERATION', name: 'Voiceover Synthesis & Prosody', required: true, durationSec: 6, costUsd: 0.04, reason: 'Generate expressive narration per scene' },
      { stage: 'SUBTITLE_SYNC', name: 'Word-Level Subtitle Syncing', required: true, durationSec: 2, costUsd: 0.005, reason: 'Extract phoneme/word timings for captions' },
      { stage: 'VISUAL_GENERATION', name: 'High-Fidelity Visual Generation', required: true, durationSec: 10, costUsd: 0.08, reason: 'Synthesize visual frames matching prompts' },
      { stage: 'B_ROLL_INTEGRATION', name: 'Supplemental B-Roll Generation', required: options.requiresBRoll, durationSec: 5, costUsd: 0.03, reason: 'Generate contextual overlay footage' },
      { stage: 'LIP_SYNC', name: 'Neural Lip-Sync Processing', required: options.requiresLipsync, durationSec: 8, costUsd: 0.05, reason: 'Synchronize character mouth movements to voice' },
      { stage: 'VFX_ANIMATION', name: 'VFX & Motion Graphics', required: options.requiresVfx, durationSec: 4, costUsd: 0.02, reason: 'Apply Ken Burns, particle and camera movements' },
      { stage: 'MUSIC_SFX', name: 'Dynamic Music & SFX Mix', required: true, durationSec: 3, costUsd: 0.015, reason: 'Compose background track with auto-ducking' },
      { stage: 'VIDEO_ASSEMBLY', name: 'Timeline Assembly & Multi-Track Render', required: true, durationSec: 12, costUsd: 0.05, reason: 'Encode high-definition master timeline' },
      { stage: 'MULTI_FORMAT_EXPORT', name: 'Multi-Aspect Ratio Transcoding', required: true, durationSec: 8, costUsd: 0.03, reason: 'Export 16:9, 9:16 vertical, and square feeds' },
      { stage: 'THUMBNAIL_GENERATION', name: 'AI Thumbnail & Title Optimization', required: true, durationSec: 3, costUsd: 0.01, reason: 'Synthesize high-CTR headline thumbnails' },
      { stage: 'AUTO_SHORTS', name: 'Auto-Shorts & Reel Clipping', required: options.requiresShorts, durationSec: 5, costUsd: 0.02, reason: 'Extract viral highlights with vertical captions' },
      { stage: 'QUALITY_CONTROL', name: 'Automated QC & Self-Evaluation Gate', required: true, durationSec: 4, costUsd: 0.01, reason: 'Verify audio clipping, black frames, and continuity' },
      { stage: 'PUBLISHING_CHECKLIST', name: 'Pre-Flight Publishing Verification', required: true, durationSec: 2, costUsd: 0.005, reason: 'Validate readiness for social publishing channels' }
    ];

    const stages: WorkflowStagePlan[] = stageDefinitions.map(def => ({
      stage: def.stage,
      name: def.name,
      required: def.required,
      estimated_duration_sec: def.durationSec,
      estimated_cost_usd: def.costUsd,
      reason: def.reason,
      status: 'PENDING'
    }));

    const totalCost = stages.filter(s => s.required).reduce((sum, s) => sum + s.estimated_cost_usd, 0);
    const totalTime = stages.filter(s => s.required).reduce((sum, s) => sum + s.estimated_duration_sec, 0);

    const plan: WorkflowPlan = {
      plan_id: `plan_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      project_id: options.projectId,
      topic: options.topic,
      target_audience: options.targetAudience,
      complexity: options.complexity,
      template_recommended: options.templateRecommended,
      visual_style_recommended: options.visualStyleRecommended,
      voice_style_recommended: options.voiceStyleRecommended,
      requires_broll: options.requiresBRoll,
      requires_vfx: options.requiresVfx,
      requires_lipsync: options.requiresLipsync,
      requires_shorts: options.requiresShorts,
      stages,
      estimated_total_cost_usd: parseFloat(totalCost.toFixed(3)),
      estimated_total_time_sec: totalTime,
      approved_by_user: false,
      created_at: new Date().toISOString()
    };

    this.plans.set(options.projectId, plan);
    return plan;
  }

  public getPlan(projectId: string): WorkflowPlan | undefined {
    return this.plans.get(projectId);
  }

  public editPlan(projectId: string, updatedStages: Partial<WorkflowStagePlan>[]): WorkflowPlan {
    let plan = this.plans.get(projectId);
    if (!plan) {
      plan = this.generatePlan({
        projectId,
        topic: 'Custom Project',
        targetAudience: 'General',
        complexity: 'STANDARD',
        templateRecommended: 'default',
        visualStyleRecommended: 'cinematic',
        voiceStyleRecommended: 'narrator',
        requiresBRoll: true,
        requiresVfx: true,
        requiresLipsync: false,
        requiresShorts: true
      });
    }

    for (const update of updatedStages) {
      const match = plan.stages.find(s => s.stage === update.stage);
      if (match) {
        if (typeof update.required === 'boolean') match.required = update.required;
        if (update.status) match.status = update.status;
      }
    }

    const activeStages = plan.stages.filter(s => s.required && s.status !== 'SKIPPED');
    plan.estimated_total_cost_usd = parseFloat(
      activeStages.reduce((sum, s) => sum + s.estimated_cost_usd, 0).toFixed(3)
    );
    plan.estimated_total_time_sec = activeStages.reduce((sum, s) => sum + s.estimated_duration_sec, 0);

    this.plans.set(projectId, plan);
    return plan;
  }

  public approvePlan(projectId: string): WorkflowPlan {
    let plan = this.plans.get(projectId);
    if (!plan) {
      plan = this.generatePlan({
        projectId,
        topic: 'Custom Project',
        targetAudience: 'General',
        complexity: 'STANDARD',
        templateRecommended: 'default',
        visualStyleRecommended: 'cinematic',
        voiceStyleRecommended: 'narrator',
        requiresBRoll: true,
        requiresVfx: true,
        requiresLipsync: false,
        requiresShorts: true
      });
    }
    plan.approved_by_user = true;
    for (const s of plan.stages) {
      if (s.required && s.status === 'PENDING') {
        s.status = 'APPROVED';
      }
    }
    this.plans.set(projectId, plan);
    return plan;
  }
}

export const workflowPlannerService = new WorkflowPlannerService();
