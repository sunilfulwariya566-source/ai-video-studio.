import { MultiLanguagePackage, VideoProject, SceneData } from '../types/index.js';

export class LocalizationService {
  public translateAndLocalize(project: VideoProject, targetLanguages: string[] = ['es', 'fr', 'de', 'ja']): MultiLanguagePackage {
    const translatedScripts: Record<string, SceneData[]> = {};
    const localizedAudio: Record<string, string[]> = {};
    const localizedSubtitles: Record<string, { srt: string; vtt: string }> = {};
    const localizedRenders: Record<string, string> = {};

    const languageNames: Record<string, string> = {
      es: 'Spanish (Español)',
      fr: 'French (Français)',
      de: 'German (Deutsch)',
      ja: 'Japanese (日本語)',
      zh: 'Chinese (中文)'
    };

    for (const lang of targetLanguages) {
      const translatedScenes: SceneData[] = (project.scenes || []).map(s => ({
        ...s,
        narration: `[${lang.toUpperCase()}] ${s.narration}`,
        dialogue: s.dialogue ? `[${lang.toUpperCase()}] ${s.dialogue}` : undefined
      }));

      translatedScripts[lang] = translatedScenes;
      localizedAudio[lang] = translatedScenes.map((_, i) => `/storage/audio/scene_${i + 1}_${lang}.mp3`);
      localizedSubtitles[lang] = {
        srt: `1\n00:00:00,000 --> 00:00:05,000\n[${lang.toUpperCase()}] ${project.title || 'Video Title'}\n\n`,
        vtt: `WEBVTT\n\n1\n00:00:00.000 --> 00:00:05.000\n[${lang.toUpperCase()}] ${project.title || 'Video Title'}\n\n`
      };
      localizedRenders[lang] = `/storage/renders/${project.id}_${lang}_master.mp4`;
    }

    const pkg: MultiLanguagePackage = {
      source_language: project.language || 'en',
      target_languages: targetLanguages,
      translated_scripts: translatedScripts,
      localized_audio_urls: localizedAudio,
      localized_subtitles: localizedSubtitles,
      localized_renders: localizedRenders
    };

    project.multi_language_package = pkg;
    return pkg;
  }
}

export const localizationService = new LocalizationService();
