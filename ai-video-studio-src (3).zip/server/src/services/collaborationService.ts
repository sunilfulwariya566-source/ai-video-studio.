import { StudioUser, ProjectComment, ApprovalRecord, HumanFeedback } from '../types/index.js';
import { projectStore } from '../database/projectStore.js';
import { qualityLearningService } from './qualityLearningService.js';

export class CollaborationService {
  private users: Map<string, StudioUser> = new Map();
  private comments: Map<string, ProjectComment[]> = new Map();
  private approvals: Map<string, ApprovalRecord[]> = new Map();
  private feedbackHistory: Map<string, HumanFeedback[]> = new Map();

  constructor() {
    this.seedDefaultUsers();
  }

  private seedDefaultUsers() {
    const defaultUsers: StudioUser[] = [
      {
        id: 'usr_owner_1',
        name: 'Alex Director (Owner)',
        email: 'owner@aistudio.internal',
        role: 'OWNER',
        permissions: {
          can_create_project: true,
          can_edit_project: true,
          can_generate_assets: true,
          can_approve_content: true,
          can_render: true,
          can_export: true,
          can_manage_providers: true,
          can_manage_billing: true
        }
      },
      {
        id: 'usr_admin_1',
        name: 'Sarah Producer (Admin)',
        email: 'admin@aistudio.internal',
        role: 'ADMIN',
        permissions: {
          can_create_project: true,
          can_edit_project: true,
          can_generate_assets: true,
          can_approve_content: true,
          can_render: true,
          can_export: true,
          can_manage_providers: true,
          can_manage_billing: false
        }
      },
      {
        id: 'usr_editor_1',
        name: 'Marcus Video Editor',
        email: 'editor@aistudio.internal',
        role: 'EDITOR',
        permissions: {
          can_create_project: true,
          can_edit_project: true,
          can_generate_assets: true,
          can_approve_content: false,
          can_render: true,
          can_export: true,
          can_manage_providers: false,
          can_manage_billing: false
        }
      },
      {
        id: 'usr_reviewer_1',
        name: 'Elena Quality Reviewer',
        email: 'reviewer@aistudio.internal',
        role: 'REVIEWER',
        permissions: {
          can_create_project: false,
          can_edit_project: false,
          can_generate_assets: false,
          can_approve_content: true,
          can_render: false,
          can_export: true,
          can_manage_providers: false,
          can_manage_billing: false
        }
      },
      {
        id: 'usr_viewer_1',
        name: 'Jordan Client (Viewer)',
        email: 'viewer@aistudio.internal',
        role: 'VIEWER',
        permissions: {
          can_create_project: false,
          can_edit_project: false,
          can_generate_assets: false,
          can_approve_content: false,
          can_render: false,
          can_export: false,
          can_manage_providers: false,
          can_manage_billing: false
        }
      }
    ];

    for (const u of defaultUsers) {
      this.users.set(u.id, u);
    }
  }

  public getUsers(): StudioUser[] {
    return Array.from(this.users.values());
  }

  public getUser(id: string): StudioUser | undefined {
    return this.users.get(id);
  }

  public checkPermission(userId: string, permission: keyof StudioUser['permissions']): boolean {
    const user = this.users.get(userId);
    if (!user) return false;
    return !!user.permissions[permission];
  }

  public addComment(comment: any): ProjectComment {
    const list = this.comments.get(comment.project_id) || [];
    const newComment: ProjectComment = {
      ...comment,
      id: `cmt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      status: 'OPEN',
      replies: [],
      created_at: new Date().toISOString()
    };

    list.push(newComment);
    this.comments.set(comment.project_id, list);

    const project = projectStore.getProject(comment.project_id);
    if (project) {
      project.comments = list;
      projectStore.saveProject(project);
    }

    return newComment;
  }

  public replyToComment(projectId: string, commentId: string, authorName: string, text: string) {
    const list = this.comments.get(projectId) || [];
    const target = list.find(c => c.id === commentId);
    if (!target) return undefined;

    if (!target.replies) target.replies = [];
    target.replies.push({
      id: `rep_${Date.now()}`,
      author_name: authorName,
      comment_text: text,
      created_at: new Date().toISOString()
    });

    const project = projectStore.getProject(projectId);
    if (project) {
      project.comments = list;
      projectStore.saveProject(project);
    }

    return target;
  }

  public updateCommentStatus(projectId: string, commentId: string, status: 'OPEN' | 'RESOLVED') {
    const list = this.comments.get(projectId) || [];
    const target = list.find(c => c.id === commentId);
    if (!target) return undefined;

    target.status = status;
    const project = projectStore.getProject(projectId);
    if (project) {
      project.comments = list;
      projectStore.saveProject(project);
    }

    return target;
  }

  public getComments(projectId: string): ProjectComment[] {
    return this.comments.get(projectId) || [];
  }

  public grantApproval(options: any): ApprovalRecord {
    const list = this.approvals.get(options.projectId) || [];
    const record: ApprovalRecord = {
      id: `appr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      project_id: options.projectId,
      version_number: options.versionNumber,
      approved_by_user_id: options.userId,
      approved_by_name: options.userName,
      approval_scope: options.scope,
      timestamp: new Date().toISOString(),
      comments: options.comments,
      is_valid: true
    };

    list.push(record);
    this.approvals.set(options.projectId, list);

    const project = projectStore.getProject(options.projectId);
    if (project) {
      project.approval_history = list;
      projectStore.saveProject(project);
    }

    return record;
  }

  public invalidateApprovalsOnEdit(projectId: string): void {
    const list = this.approvals.get(projectId);
    if (list) {
      for (const a of list) {
        a.is_valid = false;
      }
    }
  }

  public getApprovals(projectId: string): ApprovalRecord[] {
    return this.approvals.get(projectId) || [];
  }

  public recordFeedback(feedback: any): HumanFeedback {
    const list = this.feedbackHistory.get(feedback.project_id) || [];
    const record: HumanFeedback = {
      ...feedback,
      id: `fb_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      created_at: new Date().toISOString()
    };

    list.push(record);
    this.feedbackHistory.set(feedback.project_id, list);

    const project = projectStore.getProject(feedback.project_id);
    if (project) {
      qualityLearningService.recordProjectMetrics(
        project,
        feedback.feedback_type === 'APPROVE' ? 'APPROVED' : feedback.feedback_type === 'REGENERATE' ? 'REGENERATED' : 'REJECTED'
      );
    }

    return record;
  }
}

export const collaborationService = new CollaborationService();
