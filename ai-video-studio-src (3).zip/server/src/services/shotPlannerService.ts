import { SceneShot } from '../types/index.js';

export class ShotPlannerService {
  public planShot(sceneIndex: number, narrative: string): SceneShot {
    const shotTypes: SceneShot['shot_type'][] = ['ESTABLISHING', 'WIDE', 'CLOSE_UP', 'MEDIUM'];
    const movements: SceneShot['camera_movement'][] = ['SLOW_PAN_RIGHT', 'ZOOM_IN', 'ORBIT', 'STATIC'];

    return {
      shot_id: `shot_${sceneIndex + 1}`,
      shot_type: shotTypes[sceneIndex % shotTypes.length],
      camera_movement: movements[sceneIndex % movements.length],
      lens_focal_length_mm: 35,
      depth_of_field: 'SHALLOW'
    };
  }
}

export const shotPlannerService = new ShotPlannerService();
