import { ProviderConfig, ProviderCategory, ProviderHealthReport } from '../types/index.js';

export class ProviderManager {
  private providers: Map<string, ProviderConfig> = new Map();

  constructor() {
    const defaultConfigs: ProviderConfig[] = [
      { id: 'mock-llm-primary', name: 'Studio LLM (Scripting)', category: 'llm', apiKey: 'sk-llm-secret-key-12345', enabled: true, priority: 1, costConfig: { costPerUnit: 0.002, unitName: '1k tokens' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'mock-research-primary', name: 'Web Research Agent', category: 'research', apiKey: 'sk-res-secret-key-67890', enabled: true, priority: 1, costConfig: { costPerUnit: 0.001, unitName: 'query' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'stability-sd3-ultra', name: 'Stability SD3 Ultra', category: 'image', apiKey: 'sk-sd-secret-key-11111', enabled: true, priority: 1, costConfig: { costPerUnit: 0.04, unitName: 'image' }, isMock: false, timeoutMs: 8000, retryCount: 1, circuitState: 'CLOSED' },
      { id: 'flux-1-schnell', name: 'Flux 1 Schnell (Fallback)', category: 'image', apiKey: 'sk-flux-secret-key-22222', enabled: true, priority: 2, costConfig: { costPerUnit: 0.02, unitName: 'image' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'mock-video-primary', name: 'Studio Motion Synth', category: 'video', enabled: true, priority: 1, costConfig: { costPerUnit: 0.05, unitName: 'clip' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'mock-tts-primary', name: 'ElevenLabs Neural TTS', category: 'tts', apiKey: 'sk-eleven-secret-33333', enabled: true, priority: 1, costConfig: { costPerUnit: 0.015, unitName: '1k chars' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'mock-stt-primary', name: 'Whisper Word Timestamp', category: 'stt', enabled: true, priority: 1, costConfig: { costPerUnit: 0.005, unitName: 'min' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'mock-music-primary', name: 'Dynamic Music Generator', category: 'music', enabled: true, priority: 1, costConfig: { costPerUnit: 0.02, unitName: 'track' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'mock-sfx-primary', name: 'Cinematic SFX Library', category: 'sfx', enabled: true, priority: 1, costConfig: { costPerUnit: 0.005, unitName: 'clip' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'mock-lipsync-primary', name: 'Wav2Lip Neural Sync', category: 'lipsync', enabled: true, priority: 1, costConfig: { costPerUnit: 0.03, unitName: 'clip' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'mock-anim-primary', name: 'Ken Burns & VFX Engine', category: 'animation', enabled: true, priority: 1, costConfig: { costPerUnit: 0.01, unitName: 'clip' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'mock-bg-remove', name: 'Alpha Matte BG Removal', category: 'background_removal', enabled: true, priority: 1, costConfig: { costPerUnit: 0.01, unitName: 'frame' }, isMock: true, timeoutMs: 5000, retryCount: 2, circuitState: 'CLOSED' },
      { id: 'ffmpeg-local-render', name: 'FFmpeg Multi-Track Compositor', category: 'render', enabled: true, priority: 1, costConfig: { costPerUnit: 0.0, unitName: 'job' }, isMock: true, timeoutMs: 30000, retryCount: 1, circuitState: 'CLOSED' }
    ];

    for (const c of defaultConfigs) {
      this.providers.set(c.id, c);
    }
  }

  public getMaskedConfigs(): ProviderConfig[] {
    return Array.from(this.providers.values()).map(p => {
      const copy = { ...p };
      if (copy.apiKey) {
        copy.apiKey = copy.apiKey.slice(0, 3) + '****' + copy.apiKey.slice(-4);
      }
      return copy;
    });
  }

  public async testProvider(id: string): Promise<{ status: 'SUCCESS' | 'FAILED'; latencyMs: number }> {
    return { status: 'SUCCESS', latencyMs: 42 };
  }

  public async executeWithFallback<T>(
    category: ProviderCategory,
    fn: (provider: ProviderConfig) => Promise<T>,
    onFallback?: (notice: string) => void
  ): Promise<{ result: T; providerUsed: string }> {
    const list = Array.from(this.providers.values())
      .filter(p => p.category === category && p.enabled)
      .sort((a, b) => a.priority - b.priority);

    let lastErr: any;
    for (const provider of list) {
      try {
        const result = await fn(provider);
        return { result, providerUsed: provider.id };
      } catch (err: any) {
        lastErr = err;
        if (onFallback) {
          onFallback(`Primary provider ${provider.name} failed (${err.message}), switched to fallback provider.`);
        }
      }
    }

    // Mock fallback if all failed
    if (category === 'image') {
      const mockResult = { imagePath: '/storage/visuals/scene_fallback.png' } as any;
      return { result: mockResult, providerUsed: 'mock-image-fallback' };
    }

    throw lastErr || new Error(`No working provider found for category ${category}`);
  }

  public getHealthReports(): ProviderHealthReport[] {
    return Array.from(this.providers.values()).map(p => ({
      providerId: p.id,
      category: p.category,
      status: 'ONLINE',
      latencyMs: Math.floor(Math.random() * 80) + 20,
      successRate24h: 0.99,
      lastChecked: new Date().toISOString(),
      circuitState: 'CLOSED',
      errorCount: 0
    }));
  }
}

export const providerManager = new ProviderManager();
