export class TimelineService {
  public buildTimelineFromScenes(project: any) {
    let currentTime = 0;
    const videoClips: any[] = [];
    const voiceClips: any[] = [];
    const musicClips: any[] = [];
    const sfxClips: any[] = [];
    const textClips: any[] = [];
    const vfxClips: any[] = [];

    const scenes = project.scenes || [];
    for (let i = 0; i < scenes.length; i++) {
      const s = scenes[i];
      const dur = s.audio_duration || s.duration || 5;

      videoClips.push({
        id: `clip_vid_${i + 1}`,
        name: `Scene ${i + 1} Visual`,
        start_time: currentTime,
        duration: dur,
        media_url: s.image_path || s.image_url || '/storage/visuals/scene_1.png'
      });

      voiceClips.push({
        id: `clip_vox_${i + 1}`,
        name: `Scene ${i + 1} Voice`,
        start_time: currentTime,
        duration: dur,
        audio_url: s.audio_path || '/storage/audio/speech.wav'
      });

      musicClips.push({
        id: `clip_mus_${i + 1}`,
        name: `Music Theme ${i + 1}`,
        start_time: currentTime,
        duration: dur,
        volume: 0.25
      });

      sfxClips.push({
        id: `clip_sfx_${i + 1}`,
        name: s.sound_effect === 'hit' ? 'Hit SFX' : 'Whoosh SFX',
        start_time: currentTime,
        duration: 1.5
      });

      textClips.push({
        id: `clip_txt_${i + 1}`,
        name: `Captions ${i + 1}`,
        start_time: currentTime,
        duration: dur
      });

      vfxClips.push({
        id: `clip_vfx_${i + 1}`,
        name: s.vfx || 'Color Grade',
        start_time: currentTime,
        duration: dur
      });

      currentTime += dur;
    }

    return {
      total_duration: currentTime,
      tracks: [
        { id: 'trk_vid', name: 'VIDEO', clips: videoClips },
        { id: 'trk_vox', name: 'VOICE', clips: voiceClips },
        { id: 'trk_mus', name: 'MUSIC', clips: musicClips },
        { id: 'trk_sfx', name: 'SFX', clips: sfxClips },
        { id: 'trk_txt', name: 'TEXT', clips: textClips },
        { id: 'trk_vfx', name: 'VFX', clips: vfxClips }
      ]
    };
  }

  public moveClip(timeline: any, clipId: string, newStartTime: number) {
    const copy = JSON.parse(JSON.stringify(timeline));
    for (const track of copy.tracks) {
      const clip = track.clips.find((c: any) => c.id === clipId);
      if (clip) clip.start_time = newStartTime;
    }
    return copy;
  }

  public trimClip(timeline: any, clipId: string, newDuration: number) {
    const copy = JSON.parse(JSON.stringify(timeline));
    for (const track of copy.tracks) {
      const clip = track.clips.find((c: any) => c.id === clipId);
      if (clip) clip.duration = newDuration;
    }
    return copy;
  }

  public splitClip(timeline: any, clipId: string, splitTime: number) {
    const copy = JSON.parse(JSON.stringify(timeline));
    for (const track of copy.tracks) {
      const idx = track.clips.findIndex((c: any) => c.id === clipId);
      if (idx !== -1) {
        const orig = track.clips[idx];
        const newClip = {
          ...orig,
          id: `${orig.id}_split`,
          start_time: splitTime,
          duration: Math.max(1, orig.duration - splitTime)
        };
        track.clips.splice(idx + 1, 0, newClip);
      }
    }
    return copy;
  }

  public duplicateClip(timeline: any, clipId: string) {
    const copy = JSON.parse(JSON.stringify(timeline));
    for (const track of copy.tracks) {
      const orig = track.clips.find((c: any) => c.id === clipId);
      if (orig) {
        track.clips.push({
          ...orig,
          id: `${orig.id}_dup_${Date.now()}`,
          start_time: orig.start_time + orig.duration
        });
      }
    }
    return copy;
  }

  public deleteClip(timeline: any, clipId: string) {
    const copy = JSON.parse(JSON.stringify(timeline));
    for (const track of copy.tracks) {
      track.clips = track.clips.filter((c: any) => c.id !== clipId);
    }
    return copy;
  }
}

export const timelineService = new TimelineService();
