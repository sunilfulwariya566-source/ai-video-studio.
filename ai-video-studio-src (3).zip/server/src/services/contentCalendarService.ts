import { CalendarEvent } from '../types/index.js';
import { projectStore } from '../database/projectStore.js';

export interface CalendarFilterOptions {
  platform?: 'YOUTUBE' | 'TIKTOK' | 'INSTAGRAM' | 'TWITTER_X' | 'LINKEDIN';
  projectId?: string;
  status?: 'DRAFT' | 'RESEARCH' | 'PRODUCTION' | 'REVIEW' | 'SCHEDULED' | 'PUBLISHED' | 'FAILED';
  startDate?: string;
  endDate?: string;
}

export class ContentCalendarService {
  private events: Map<string, CalendarEvent> = new Map();

  constructor() {
    this.seedInitialEvents();
  }

  private seedInitialEvents() {
    const defaultEvents: CalendarEvent[] = [
      {
        id: 'cal_1',
        project_id: 'proj_demo_1',
        title: 'Deep Sea Mysteries: The Abyss',
        platform: 'YOUTUBE',
        status: 'PUBLISHED',
        date: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
        format: '16:9',
        thumbnail_url: '/storage/visuals/scene_1.png'
      },
      {
        id: 'cal_2',
        project_id: 'proj_demo_2',
        title: 'AI Revolution in 60 Seconds',
        platform: 'TIKTOK',
        status: 'SCHEDULED',
        date: new Date(Date.now() + 86400000 * 1).toISOString().split('T')[0],
        format: '9:16',
        thumbnail_url: '/storage/visuals/scene_1.png'
      },
      {
        id: 'cal_3',
        project_id: 'proj_demo_3',
        title: 'Quantum Computing Breakdown',
        platform: 'TWITTER_X',
        status: 'PRODUCTION',
        date: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
        format: '1:1'
      }
    ];
    for (const ev of defaultEvents) {
      this.events.set(ev.id, ev);
    }
  }

  public addEvent(event: Omit<CalendarEvent, 'id'>): CalendarEvent {
    const id = 'cal_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const newEvent: CalendarEvent = { ...event, id };
    this.events.set(id, newEvent);
    return newEvent;
  }

  public getEvents(filter?: CalendarFilterOptions): CalendarEvent[] {
    let result = Array.from(this.events.values());
    if (filter) {
      if (filter.platform) result = result.filter(e => e.platform === filter.platform);
      if (filter.projectId) result = result.filter(e => e.project_id === filter.projectId);
      if (filter.status) result = result.filter(e => e.status === filter.status);
      if (filter.startDate) result = result.filter(e => e.date >= filter.startDate!);
      if (filter.endDate) result = result.filter(e => e.date <= filter.endDate!);
    }
    return result.sort((a, b) => a.date.localeCompare(b.date));
  }
}

export const contentCalendarService = new ContentCalendarService();
