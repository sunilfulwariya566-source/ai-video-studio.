import { OptimizedPrompt, ProviderCategory } from '../types/index.js';
import { promptVersioningService } from './promptVersioningService.js';

export class PromptOptimizationService {
  private history: Map<string, OptimizedPrompt> = new Map();

  public optimizePrompt(req: any): OptimizedPrompt {
    const provider = req.providerTarget || 'standard_ai';
    const model = req.modelTarget || 'default_model';
    const modifiers = req.styleModifiers || [];
    let optimized = req.rawUserIntent;
    let negativePrompt = '';

    if (req.category === 'image' || req.category === 'visuals') {
      const visualAdditions = ['photorealistic', '8k resolution', 'masterpiece', 'hyper-detailed', 'volumetric cinematic lighting', ...modifiers];
      optimized = `${req.rawUserIntent}, ${visualAdditions.join(', ')}`;
      negativePrompt = 'blurry, distorted, low quality, deformed anatomy, bad hands, artifacts, watermark';
    } else if (req.category === 'llm' || req.category === 'script') {
      optimized = `You are an award-winning documentary scriptwriter. Create an engaging, retention-optimized narrative for the topic: "${req.rawUserIntent}". Keep sentences punchy, conversational, and rhythmically varied. Include vivid visual descriptions for every shot.`;
    } else if (req.category === 'tts') {
      optimized = `[Tone: Warm, Authoritative, Dynamic] ${req.rawUserIntent}`;
    }

    const record: OptimizedPrompt = {
      id: `opt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      category: req.category,
      raw_user_intent: req.rawUserIntent,
      optimized_prompt: optimized,
      negative_prompt: negativePrompt,
      provider_target: provider,
      model_target: model,
      style_modifiers: modifiers,
      parameters: req.parameters || {},
      version: 1,
      created_at: new Date().toISOString()
    };

    this.history.set(record.id, record);

    promptVersioningService.registerVersion({
      promptId: record.id,
      category: record.category,
      provider: record.provider_target,
      model: record.model_target,
      promptText: record.optimized_prompt,
      negativePrompt: record.negative_prompt,
      parameters: record.parameters,
      qualityScore: 92,
      successRate: 0.98
    });

    return record;
  }

  public getOptimizedPrompt(id: string): OptimizedPrompt | undefined {
    return this.history.get(id);
  }

  public getAllOptimizedPrompts(): OptimizedPrompt[] {
    return Array.from(this.history.values());
  }
}

export const promptOptimizationService = new PromptOptimizationService();
