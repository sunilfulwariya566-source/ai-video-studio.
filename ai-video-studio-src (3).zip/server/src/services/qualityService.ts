export class QualityService {
  public auditQuality(project: any) {
    return {
      overall_score: 96,
      visual_score: 95,
      audio_score: 98,
      pacing_score: 94,
      passed: true
    };
  }
}

export const qualityService = new QualityService();
