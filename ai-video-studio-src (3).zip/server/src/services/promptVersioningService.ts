import { PromptVersion, ProviderCategory } from '../types/index.js';

export class PromptVersioningService {
  private versions: Map<string, PromptVersion[]> = new Map();

  public registerVersion(options: any): PromptVersion {
    const existing = this.versions.get(options.promptId) || [];
    const nextVersionNum = existing.length + 1;

    const versionRecord: PromptVersion = {
      version_id: `ver_${options.promptId}_v${nextVersionNum}`,
      prompt_id: options.promptId,
      category: options.category,
      version_number: nextVersionNum,
      provider: options.provider,
      model: options.model,
      prompt_text: options.promptText,
      negative_prompt: options.negativePrompt,
      parameters: options.parameters,
      quality_score: options.qualityScore || 90,
      success_rate: options.successRate || 1.0,
      created_at: new Date().toISOString()
    };

    existing.push(versionRecord);
    this.versions.set(options.promptId, existing);
    return versionRecord;
  }

  public getVersionsForPrompt(promptId: string): PromptVersion[] {
    return this.versions.get(promptId) || [];
  }

  public getAllVersions(): PromptVersion[] {
    const all: PromptVersion[] = [];
    for (const list of this.versions.values()) {
      all.push(...list);
    }
    return all.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  public compareVersions(v1Id: string, v2Id: string) {
    const all = this.getAllVersions();
    const v1 = all.find(v => v.version_id === v1Id);
    const v2 = all.find(v => v.version_id === v2Id);

    const diff = {
      promptDiff: { v1: v1?.prompt_text, v2: v2?.prompt_text },
      qualityScoreDelta: (v2?.quality_score || 0) - (v1?.quality_score || 0),
      successRateDelta: (v2?.success_rate || 0) - (v1?.success_rate || 0),
      modelChange: v1?.model !== v2?.model ? { from: v1?.model, to: v2?.model } : null
    };

    return { v1, v2, diff };
  }
}

export const promptVersioningService = new PromptVersioningService();
