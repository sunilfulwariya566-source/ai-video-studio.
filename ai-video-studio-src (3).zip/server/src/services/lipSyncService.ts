export class LipSyncService {
  public async generateVisemes(audioDuration: number) {
    const visemes: Array<{ time: number; shape: string }> = [];
    const shapes = ['A', 'E', 'I', 'O', 'U', 'M', 'F', 'L'];
    for (let t = 0; t < audioDuration; t += 0.2) {
      visemes.push({ time: parseFloat(t.toFixed(2)), shape: shapes[Math.floor(Math.random() * shapes.length)] });
    }
    return { visemes };
  }
}

export const lipSyncService = new LipSyncService();
