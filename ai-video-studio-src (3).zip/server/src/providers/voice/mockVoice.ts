import fs from 'fs';
import path from 'path';
import { VoiceGenerationParams } from '../interfaces.js';

export class MockVoiceProvider {
  public async generateSpeech(params: VoiceGenerationParams) {
    const targetDir = path.dirname(params.outputFilePath);
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });

    // Write mock audio header bytes
    fs.writeFileSync(params.outputFilePath, Buffer.from('RIFF_MOCK_WAV_AUDIO_PAYLOAD'));

    const wordsList = params.text.split(/\s+/).filter(Boolean);
    const duration = Math.max(3.5, parseFloat((wordsList.length * 0.45).toFixed(2)));

    const words = wordsList.map((w, idx) => ({
      word: w,
      start: parseFloat((idx * 0.4).toFixed(2)),
      end: parseFloat(((idx + 1) * 0.4).toFixed(2))
    }));

    return {
      filePath: params.outputFilePath,
      duration,
      words
    };
  }
}
