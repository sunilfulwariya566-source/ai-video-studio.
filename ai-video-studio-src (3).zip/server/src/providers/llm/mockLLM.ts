import { ScriptGenerationParams } from '../interfaces.js';

export class MockLLMProvider {
  public async generateScript(params: ScriptGenerationParams) {
    const isHindi = params.language === 'Hindi';
    const isHinglish = params.language === 'Hinglish';

    const hook = isHindi
      ? `समय यात्रा के वो 3 रहस्य जो विज्ञान ने अब तक दुनिया से छिपाए हैं...`
      : isHinglish
      ? `AI startup create karna aaj ke time me sabse smart decision hai...`
      : `What if everything you knew about ${params.idea} was completely revolutionized in 2026?`;

    const scenes = [
      {
        scene_id: 1,
        duration: 6,
        narration: hook,
        visual_description: `High impact visual illustrating ${params.idea}`,
        camera: 'Zoom In',
        animation: 'Text Reveal',
        vfx: 'Cinematic Grade',
        music: 'Cinematic Beat',
        sound_effect: 'whoosh',
        transition: 'Crossfade',
        image_path: '/storage/visuals/scene_1.png'
      },
      {
        scene_id: 2,
        duration: 8,
        narration: isHindi ? 'पहला बड़ा रहस्य है क्वांटम फील्ड का समय प्रभाव।' : 'First, fundamental computational breakthroughs alter every benchmark.',
        visual_description: 'Futuristic technical blueprint and glowing nodes',
        camera: 'Pan Right',
        animation: 'Float',
        vfx: 'Glow',
        music: 'Cinematic Beat',
        sound_effect: 'hit',
        transition: 'Cut',
        image_path: '/storage/visuals/scene_2.png'
      },
      {
        scene_id: 3,
        duration: 8,
        narration: isHindi ? 'दूसरा रहस्य है स्पेस-टाइम का कर्वेचर जिसे हम मोड़ सकते हैं।' : 'Second, recursive real-time models eliminate historical bottlenecks.',
        visual_description: 'Anamorphic lens capture of glowing quantum core',
        camera: 'Orbit',
        animation: 'Zoom',
        vfx: 'Flare',
        music: 'Cinematic Beat',
        sound_effect: 'riser',
        transition: 'Whip Pan',
        image_path: '/storage/visuals/scene_3.png'
      },
      {
        scene_id: 4,
        duration: 8,
        narration: isHindi ? 'और तीसरा सबसे महत्वपूर्ण तथ्य: यह तकनीक अब लैब से बाहर आ चुकी है।' : 'Finally, autonomous orchestration merges creative intent with instant execution.',
        visual_description: 'Vibrant panoramic view of connected intelligence network',
        camera: 'Static',
        animation: 'Fade',
        vfx: 'Color Pulse',
        music: 'Cinematic Beat',
        sound_effect: 'impact',
        transition: 'Crossfade',
        image_path: '/storage/visuals/scene_1.png'
      }
    ];

    if (isHinglish || params.duration === '60s') {
      scenes.push({
        scene_id: 5,
        duration: 10,
        narration: 'Conclusion and call to action for subscribers.',
        visual_description: 'Call to action card with subscribe button',
        camera: 'Static',
        animation: 'Pop',
        vfx: 'Clean',
        music: 'Outro',
        sound_effect: 'bell',
        transition: 'Fade',
        image_path: '/storage/visuals/scene_2.png'
      });
    }

    const script = {
      hook,
      introduction: 'Welcome to this deep-dive exploration.',
      main_content: [
        { point: 'Breakthrough 1: Core Architecture' },
        { point: 'Breakthrough 2: Real-time Synthesis' }
      ],
      ending: 'The future is arriving faster than predicted.',
      call_to_action: 'Follow and subscribe for daily AI breakdowns.',
      scenes
    };

    const director = {
      visual_style: params.style || 'Cinematic Photorealistic',
      aspect_ratio: params.format || '9:16',
      pacing: 'Dynamic High-Retention'
    };

    return { script, director };
  }

  public async regenerateScene(originalScene: any, context: any) {
    return {
      ...originalScene,
      narration: `Regenerated deep dive exploring ${context.topic} with enhanced fidelity.`,
      visual_description: `Enhanced 8K photorealistic scene depicting ${context.topic} with anamorphic flares.`
    };
  }
}
