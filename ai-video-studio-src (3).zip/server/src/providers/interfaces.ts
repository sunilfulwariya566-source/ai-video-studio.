export interface ScriptGenerationParams {
  idea: string;
  language: string;
  duration: string;
  format: string;
  style: string;
  voice_gender: string;
  voice_tone: string;
}

export interface VoiceGenerationParams {
  text: string;
  gender: string;
  language: string;
  tone: string;
  outputFilePath: string;
}
