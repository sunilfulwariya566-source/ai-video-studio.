export interface Project {
  id: string;
  title: string;
  idea: string;
  language: string;
  duration_target: string;
  format: '16:9' | '9:16' | '1:1' | '4:5';
  style: string;
  voice_gender: string;
  voice_tone: string;
  status: string;
  progress: number;
  current_step_label: string;
  created_at: string;
  updated_at: string;
  script?: any;
  scenes?: any[];
  timeline?: any;
  render_job_id?: string;
  video_url?: string;
}
