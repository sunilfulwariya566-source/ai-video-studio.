import { describe, it, expect } from 'vitest';
import { TimelineService } from '../src/services/timelineService.js';
import { Project } from '../src/models/types.js';

describe('Automatic Multi-Track Timeline', () => {
  const timelineService = new TimelineService();

  const mockProject: Project = {
    id: 'test_proj_1',
    title: 'Test Video',
    idea: 'Testing timeline mechanics',
    language: 'English',
    duration_target: '30s',
    format: '9:16',
    style: 'Cinematic',
    voice_gender: 'Male',
    voice_tone: 'Normal',
    status: 'QUEUED',
    progress: 0,
    current_step_label: '',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    scenes: [
      {
        scene_id: 1,
        duration: 5,
        audio_duration: 5.2,
        narration: 'First scene hook line',
        visual_description: 'Intro visual',
        camera: 'Zoom In',
        animation: 'Text Reveal',
        vfx: 'Warm Grade',
        music: 'Cinematic',
        sound_effect: 'hit',
        transition: 'Crossfade',
        captions: [
          { word: 'First', start: 0.1, end: 0.6 },
          { word: 'scene', start: 0.7, end: 1.2 },
          { word: 'hook', start: 1.3, end: 1.8 },
          { word: 'line', start: 1.9, end: 2.5 }
        ]
      },
      {
        scene_id: 2,
        duration: 6,
        audio_duration: 5.8,
        narration: 'Second scene core message',
        visual_description: 'Breakdown visual',
        camera: 'Pan Right',
        animation: 'Float',
        vfx: 'Glow',
        music: 'Cinematic',
        sound_effect: 'whoosh',
        transition: 'Cut'
      }
    ]
  };

  it('should auto-place scenes sequentially across VIDEO, VOICE, MUSIC, SFX, TEXT, VFX tracks', () => {
    const timeline = timelineService.buildTimelineFromScenes(mockProject);

    expect(timeline.tracks.length).toBe(6);
    expect(timeline.tracks.map(t => t.name)).toEqual(['VIDEO', 'VOICE', 'MUSIC', 'SFX', 'TEXT', 'VFX']);

    const videoTrack = timeline.tracks.find(t => t.name === 'VIDEO')!;
    expect(videoTrack.clips.length).toBe(2);
    expect(videoTrack.clips[0].start_time).toBe(0);
    expect(videoTrack.clips[0].duration).toBe(5.2);
    expect(videoTrack.clips[1].start_time).toBe(5.2);

    const sfxTrack = timeline.tracks.find(t => t.name === 'SFX')!;
    expect(sfxTrack.clips.length).toBe(2);
    expect(sfxTrack.clips[0].name).toContain('Hit');
    expect(sfxTrack.clips[1].start_time).toBe(5.2);
  });

  it('should perform timeline clip operations: move, trim, split, delete, duplicate', () => {
    const timeline = timelineService.buildTimelineFromScenes(mockProject);
    const firstClip = timeline.tracks[0].clips[0];

    // 1. Move
    const moved = timelineService.moveClip(timeline, firstClip.id, 2.5);
    expect(moved.tracks[0].clips[0].start_time).toBe(2.5);

    // 2. Trim
    const trimmed = timelineService.trimClip(moved, firstClip.id, 8.0);
    expect(trimmed.tracks[0].clips[0].duration).toBe(8.0);

    // 3. Split
    const splitted = timelineService.splitClip(trimmed, firstClip.id, 5.0);
    expect(splitted.tracks[0].clips.length).toBe(3);

    // 4. Duplicate
    const duplicated = timelineService.duplicateClip(splitted, firstClip.id);
    expect(duplicated.tracks[0].clips.length).toBe(4);

    // 5. Delete
    const deleted = timelineService.deleteClip(duplicated, firstClip.id);
    expect(deleted.tracks[0].clips.length).toBe(3);
  });
});
