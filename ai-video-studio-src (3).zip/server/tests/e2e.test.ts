import { describe, it, expect } from 'vitest';
import { projectService } from '../src/services/projectService.js';
import { db } from '../src/db/database.js';
import fs from 'fs';

describe('End-to-End Pipeline: Idea -> Script -> Scenes -> Voice -> Timeline -> Render', () => {
  it('should run the complete automated creation pipeline and produce a working MP4 video', async () => {
    // 1. Create Project
    const project = projectService.createProject({
      title: 'Automated E2E Test Reel',
      idea: '3 Revolutionary AI Advancements in 2026',
      language: 'English',
      duration_target: '30s',
      format: '9:16',
      style: 'Cinematic',
      voice_gender: 'Male',
      voice_tone: 'Energetic'
    });

    expect(project.id).toBeDefined();
    expect(project.status).toBe('QUEUED');

    // 2. Generate Script & Director Decisions
    const scriptedProject = await projectService.generateScript(project.id);
    expect(scriptedProject.script).toBeDefined();
    expect(scriptedProject.scenes.length).toBeGreaterThanOrEqual(4);
    expect(scriptedProject.scenes[0].image_path).toBeDefined();

    // 3. Generate Voiceover & Duration Sync
    const voicedProject = await projectService.generateVoice(project.id);
    expect(voicedProject.scenes[0].audio_path).toBeDefined();
    expect(voicedProject.scenes[0].audio_duration).toBeGreaterThan(0);
    expect(voicedProject.timeline).toBeDefined();

    // 4. Build Multi-Track Timeline
    const timelineProject = await projectService.buildTimeline(project.id);
    expect(timelineProject.timeline?.tracks.length).toBe(6);

    // 5. Test Full Pipeline Execution and Video Rendering
    const finalProject = await projectService.runFullPipeline(project.id);
    expect(finalProject.render_job_id).toBeDefined();

    const renderJob = db.getRenderJob(finalProject.render_job_id!);
    expect(renderJob).toBeDefined();

    // Wait for render execution
    let attempts = 0;
    while (attempts < 60) {
      const currentJob = db.getRenderJob(finalProject.render_job_id!);
      if (currentJob?.status === 'completed' || currentJob?.status === 'failed') break;
      await new Promise(r => setTimeout(r, 500));
      attempts++;
    }

    const completedJob = db.getRenderJob(finalProject.render_job_id!);
    expect(completedJob?.status).toBe('completed');
    expect(completedJob?.output_path).toBeDefined();
    expect(fs.existsSync(completedJob!.output_path!)).toBe(true);

    const fileSize = fs.statSync(completedJob!.output_path!).size;
    expect(fileSize).toBeGreaterThan(10000); // Verify valid MP4 bytes
  }, 60000); // 60s timeout for complete ffmpeg render pipeline
});
