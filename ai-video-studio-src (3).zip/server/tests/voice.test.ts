import { describe, it, expect } from 'vitest';
import { MockVoiceProvider } from '../src/providers/voice/mockVoice.js';
import path from 'path';
import fs from 'fs';

describe('Voiceover System & Audio Synthesis', () => {
  const voiceProvider = new MockVoiceProvider();
  const testOutputDir = path.resolve(process.cwd(), 'storage/audio');

  it('should generate speech audio file, measure duration and return word timestamps for English', async () => {
    const testFile = path.join(testOutputDir, `test_speech_en_${Date.now()}.wav`);
    const result = await voiceProvider.generateSpeech({
      text: 'Welcome to the AI Automated Video Creation Studio. The future of creative automation is here.',
      gender: 'Male',
      language: 'English',
      tone: 'Energetic',
      outputFilePath: testFile
    });

    expect(fs.existsSync(result.filePath)).toBe(true);
    expect(result.duration).toBeGreaterThan(1);
    expect(result.words.length).toBeGreaterThan(5);
    expect(result.words[0]).toHaveProperty('word');
    expect(result.words[0]).toHaveProperty('start');
    expect(result.words[0]).toHaveProperty('end');

    if (fs.existsSync(testFile)) fs.unlinkSync(testFile);
  });

  it('should generate speech for Hindi narration', async () => {
    const testFile = path.join(testOutputDir, `test_speech_hi_${Date.now()}.wav`);
    const result = await voiceProvider.generateSpeech({
      text: 'नमस्ते दोस्तों, आपका इस वीडियो में स्वागत है।',
      gender: 'Female',
      language: 'Hindi',
      tone: 'Normal',
      outputFilePath: testFile
    });

    expect(fs.existsSync(result.filePath)).toBe(true);
    expect(result.duration).toBeGreaterThan(1);
    expect(result.words.length).toBeGreaterThan(3);

    if (fs.existsSync(testFile)) fs.unlinkSync(testFile);
  });
});
