import { providerManager } from '../src/services/providerManager.js';
import { assetStorageService } from '../src/services/assetStorageService.js';
import { assetCacheService } from '../src/services/assetCacheService.js';
import { captionEngineService } from '../src/services/captionEngineService.js';
import { audioMixerService } from '../src/services/audioMixerService.js';
import { renderGraphBuilder } from '../src/services/renderGraphBuilder.js';
import { renderEngineService } from '../src/services/renderEngineService.js';
import { thumbnailExtractorService } from '../src/services/thumbnailExtractorService.js';
import { jobQueueService } from '../src/services/jobQueueService.js';
import { healthService } from '../src/services/healthService.js';
import { researchService } from '../src/services/researchService.js';
import { factCheckService } from '../src/services/factCheckService.js';
import { trendService } from '../src/services/trendService.js';
import { shotPlannerService } from '../src/services/shotPlannerService.js';
import { assetBibleService } from '../src/services/assetBibleService.js';
import { voiceEmotionService } from '../src/services/voiceEmotionService.js';
import { lipSyncService } from '../src/services/lipSyncService.js';
import { brollService } from '../src/services/brollService.js';
import { continuityService } from '../src/services/continuityService.js';
import { safetyService } from '../src/services/safetyService.js';
import { editingDirectorService } from '../src/services/editingDirectorService.js';
import { soundDesignService } from '../src/services/soundDesignService.js';
import { metadataService } from '../src/services/metadataService.js';
import { shortsService } from '../src/services/shortsService.js';
import { versionService } from '../src/services/versionService.js';
import { qualityService } from '../src/services/qualityService.js';
import { costBudgetService } from '../src/services/costBudgetService.js';
import { orchestrator, videoProductionOrchestrator } from '../src/orchestrator/videoProductionOrchestrator.js';
import { db } from '../src/db/database.js';
import { projectStore } from '../src/database/projectStore.js';

// Phase 6 Services
import { contentDirectorService } from '../src/services/contentDirectorService.js';
import { workflowPlannerService } from '../src/services/workflowPlannerService.js';
import { contentMemoryService } from '../src/services/contentMemoryService.js';
import { promptOptimizationService } from '../src/services/promptOptimizationService.js';
import { promptVersioningService } from '../src/services/promptVersioningService.js';
import { qualityLearningService } from '../src/services/qualityLearningService.js';
import { selfEvaluationService } from '../src/services/selfEvaluationService.js';
import { repairAgentService } from '../src/services/repairAgentService.js';
import { collaborationService } from '../src/services/collaborationService.js';
import { schedulingBatchService } from '../src/services/schedulingBatchService.js';
import { contentCalendarService } from '../src/services/contentCalendarService.js';
import { publishingService } from '../src/services/publishingService.js';
import { analyticsPerformanceService } from '../src/services/analyticsPerformanceService.js';
import { originalityService } from '../src/services/originalityService.js';
import { mediaRightsWatermarkService } from '../src/services/mediaRightsWatermarkService.js';
import { backupRecoveryService } from '../src/services/backupRecoveryService.js';
import { storageLifecycleService } from '../src/services/storageLifecycleService.js';
import { systemResourceManager } from '../src/services/systemResourceManager.js';
import { renderWorkerManager } from '../src/services/renderWorkerManager.js';
import { securityAuditService } from '../src/services/securityAuditService.js';
import { auditLogService } from '../src/services/auditLogService.js';
import { featureFlagService } from '../src/services/featureFlagService.js';
import { experimentService } from '../src/services/experimentService.js';
import { localizationService } from '../src/services/localizationService.js';
import { projectPackageService } from '../src/services/projectPackageService.js';
import { webhookNotificationService } from '../src/services/webhookNotificationService.js';
import { factoryScorecardService } from '../src/services/factoryScorecardService.js';

import fs from 'fs';
import path from 'path';

let passed = 0;
let failed = 0;

function assert(condition: boolean, message: string) {
  if (condition) {
    console.log(`  ✅ PASS: ${message}`);
    passed++;
  } else {
    console.error(`  ❌ FAIL: ${message}`);
    failed++;
  }
}

async function runComprehensiveStudioTestSuite() {
  console.log('\n==================================================================');
  console.log('🎬 RUNNING AI VIDEO FACTORY PHASE 1 - PHASE 6 COMPREHENSIVE TEST SUITE');
  console.log('==================================================================\n');

  // TEST 1: Unified Provider Architecture & Categories
  console.log('▶ [1/20] UNIFIED PROVIDER ARCHITECTURE & CATEGORIES');
  const configs = providerManager.getMaskedConfigs();
  assert(configs.length >= 12, `Registers providers across all 12 categories (found ${configs.length})`);
  assert(configs.every(c => !c.apiKey || c.apiKey.includes('****')), 'API Keys are securely masked for client exposure');

  const testRes = await providerManager.testProvider('mock-llm-primary');
  assert(testRes.status === 'SUCCESS', 'Provider connection test returns SUCCESS');

  // TEST 2: Intelligent Provider Fallback
  console.log('\n▶ [2/20] INTELLIGENT PROVIDER FALLBACK & CIRCUIT BREAKING');
  let fallbackNoticed = false;
  const { result: fallbackResult } = await providerManager.executeWithFallback<any>(
    'image',
    async (provider) => {
      if (provider.id === 'stability-sd3-ultra') {
        throw new Error('Simulated external API 429 rate-limit');
      }
      return { imagePath: '/storage/visuals/scene_test.png' };
    },
    (notice) => {
      fallbackNoticed = true;
      assert(notice.includes('switched to fallback'), `Emits structured fallback notice: "${notice.slice(0, 50)}..."`);
    }
  );
  assert(fallbackNoticed, 'Triggered fallback mechanism seamlessly');
  assert(fallbackResult.imagePath !== undefined, 'Fallback provider completed generation');

  // TEST 3: Asset Storage & SHA-256 Fingerprint Cache
  console.log('\n▶ [3/20] ASSET STORAGE & DETERMINISTIC CACHING');
  const stored = await assetStorageService.storeAsset({
    projectId: 'test-proj-storage',
    type: 'IMAGE',
    provider: 'test-provider',
    prompt: 'Nebula core reactor',
    bufferOrSourcePath: Buffer.from('PNG_MOCK_IMAGE_DATA'),
    extension: 'png'
  });
  assert(stored.hashSha256.length === 64, 'Calculates valid SHA-256 asset hash');
  assert(fs.existsSync(stored.filePath), 'Persists asset to deterministic storage path');

  const fp = assetCacheService.generateFingerprint({
    category: 'image',
    prompt: 'Nebula core reactor',
    provider: 'test-provider'
  });
  assetCacheService.setCachedAsset(fp, stored);
  const cached = assetCacheService.getCachedAsset(fp);
  assert(cached !== null && cached.id === stored.id, 'Cache hits on identical request fingerprint');
  const forced = assetCacheService.getCachedAsset(fp, true);
  assert(forced === null, 'Force regenerate bypasses cache');

  // TEST 4: Caption Engine (SRT, VTT, ASS Styled Subtitles)
  console.log('\n▶ [4/20] CAPTION & SUBTITLE ENGINE (SRT / VTT / ASS)');
  const sampleScenes: any[] = [
    {
      scene_id: 1,
      duration: 5,
      narration: 'Warp propulsion bridges distant galaxies in seconds.',
      word_timings: [
        { word: 'Warp', start: 0.1, end: 0.8 },
        { word: 'propulsion', start: 0.9, end: 1.6 },
        { word: 'bridges', start: 1.7, end: 2.3 },
        { word: 'galaxies.', start: 2.4, end: 3.5 }
      ]
    }
  ];
  const subEntries = captionEngineService.generateSubtitleEntries(sampleScenes);
  assert(subEntries.length >= 1, 'Generates timed subtitle entries');

  const srt = captionEngineService.generateSRT(subEntries, 'test-caption');
  assert(srt.srtContent.includes('-->'), 'Generates valid standard SRT syntax');

  const vtt = captionEngineService.generateVTT(subEntries, 'test-caption');
  assert(vtt.vttContent.startsWith('WEBVTT'), 'Generates valid WebVTT syntax');

  const style = captionEngineService.getPresetConfig('Shorts');
  const ass = captionEngineService.generateASS(subEntries, style, 'test-caption');
  assert(ass.assContent.includes('[V4+ Styles]') && ass.assContent.includes('Dialogue:'), 'Generates valid ASS styled subtitle stream with safe-zone margin');

  // TEST 5: Audio Mixing Graph & Voiceover Ducking (-14dB)
  console.log('\n▶ [5/20] AUDIO MIXING GRAPH & BROADCAST NORMALIZATION (-14 LUFS)');
  const audioGraph = audioMixerService.buildAudioMixGraph({
    id: 'test-audio-proj',
    scenes: sampleScenes
  } as any);
  assert(audioGraph.targetLufs === -14.0, 'Targets standard -14.0 LUFS loudness normalization');
  assert(audioGraph.peakLimitDb === -1.0, 'Sets -1.0 dBFS true peak limiter against clipping');
  assert(audioGraph.tracks.some(t => t.duckingDb === -14.0), 'Configures dynamic background music ducking (-14dB)');

  // TEST 6: FFmpeg Render Graph Builder & Quality Validation
  console.log('\n▶ [6/20] FFMPEG RENDER GRAPH BUILDER & RENDER ENGINE');
  const renderGraph = renderGraphBuilder.buildRenderGraph({
    id: 'test-rg-proj',
    title: 'Quantum Drive',
    scenes: sampleScenes,
    format: '9:16'
  } as any, '9:16', false);
  assert(renderGraph.nodes.length === 1, 'Constructs render graph nodes from scenes');
  assert(renderGraph.formatProfile.width === 1080 && renderGraph.formatProfile.height === 1920, 'Configures vertical 1080x1920 9:16 format profile');

  const renderResult = await renderEngineService.renderGraph(renderGraph);
  assert(fs.existsSync(renderResult.outputFilePath), 'Renders output MP4 video file safely');

  const qcVal = renderEngineService.validateRender(renderResult.outputFilePath, renderResult.durationSec, '9:16');
  assert(qcVal.passed === true, 'Validates rendered video file existence and stream headers');

  // TEST 7: AI Content Director & Smart Workflow Planner
  console.log('\n▶ [7/20] AI CONTENT DIRECTOR & SMART WORKFLOW PLANNER');
  const directorRes = contentDirectorService.analyzeAndDirect({
    projectId: 'test_p6_proj',
    topic: 'Next Generation AI Agents',
    format: '16:9',
    targetDurationSeconds: 45
  });
  assert(directorRes.decision.creative_angle.length > 5, 'AI Director determines creative angle and pacing');
  assert(directorRes.workflowPlan.stages.length >= 10, `Smart Planner establishes ${directorRes.workflowPlan.stages.length} workflow stages`);
  assert(directorRes.workflowPlan.estimated_total_cost_usd > 0, 'Estimates production cost accurately');

  const approvedPlan = workflowPlannerService.approvePlan('test_p6_proj');
  assert(approvedPlan.approved_by_user === true, 'Workflow plan user approval updates stage states');

  // TEST 8: Long-Term Content Memory & Prompt Versioning
  console.log('\n▶ [8/20] LONG-TERM CONTENT MEMORY & PROMPT VERSIONING');
  const optPrompt = promptOptimizationService.optimizePrompt({
    category: 'image',
    rawUserIntent: 'Deep space observatory telescope orbiting Jupiter',
    styleModifiers: ['anamorphic lens', '8k photorealistic']
  });
  assert(optPrompt.optimized_prompt.includes('photorealistic'), 'Optimizes user prompt with domain guidance');

  const versions = promptVersioningService.getVersionsForPrompt(optPrompt.id);
  assert(versions.length >= 1, 'Registers prompt version with parameters and quality score');

  const memory = contentMemoryService.recordProjectCompletion({
    id: 'mem_test_proj',
    title: 'Deep Space Mission',
    topic: 'Space Exploration',
    style: 'cinematic_photorealistic',
    voice_id: 'voice_narrator_studio',
    characters: [],
    environments: [],
    scenes: [{ id: 1, duration: 5, narration: 'Narrative', visual_prompt: optPrompt.optimized_prompt }],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    format: '16:9',
    idea: 'Idea',
    prompt: 'Prompt',
    language: 'en',
    duration_target: '30s',
    target_duration_seconds: 30,
    voice_gender: 'neutral',
    voice_tone: 'authoritative',
    music_id: 'music_ambient',
    music_style: 'cinematic',
    beat_sync: true,
    bpm: 120,
    budget_tier: 'standard',
    status: 'COMPLETED',
    progress: 100
  });
  assert(memory.id.includes('mem_test_proj'), 'Persists project memory for cross-project reuse');

  const foundMemory = contentMemoryService.findMemoryByTopicOrStyle('Space Exploration');
  assert(foundMemory !== undefined && foundMemory.title === 'Deep Space Mission', 'Retrieves stored memory by topic query');

  // TEST 9: Quality Learning System & Post-Production Recommendations
  console.log('\n▶ [9/20] QUALITY LEARNING SYSTEM & HISTORICAL RECOMMENDATIONS');
  const learnings = qualityLearningService.getLearningsSummary();
  assert(learnings.averageQcScore >= 80, `Aggregates historical QC scores (${learnings.averageQcScore}%)`);
  assert(learnings.recommendations.length >= 1, 'Generates explainable, reversible optimization recommendations');

  // TEST 10: Pre-Human AI Self-Evaluation (10 Dimensions)
  console.log('\n▶ [10/20] PRE-HUMAN AI SELF-EVALUATION (10 DIMENSIONS)');
  const dummyProject: any = {
    id: 'test_eval_proj',
    title: 'Self Eval Test',
    topic: 'Quantum Computing',
    format: '16:9',
    final_video_url: '/storage/renders/test_eval_master.mp4',
    thumbnails: [{ id: 't1', title: 'Thumb 1', headline_overlay: 'TEST', predicted_ctr_score: 10 }],
    scenes: [
      { id: 1, narration: 'Scene 1', duration: 5, image_url: '/storage/visuals/scene_1.png', subtitles: [{ id: 1, startTime: 0, endTime: 5, text: 'Scene 1' }] },
      { id: 2, narration: 'Scene 2', duration: 5, image_url: '/storage/visuals/scene_2.png', subtitles: [{ id: 1, startTime: 0, endTime: 5, text: 'Scene 2' }] }
    ],
    voice_id: 'voice_narrator_studio',
    music_style: 'electronic',
    qc_report: { passed: true, overall_score: 95 }
  };
  const evalReport = selfEvaluationService.evaluateProject(dummyProject);
  assert(evalReport.score >= 80, `Evaluates 10-dimension health score (${evalReport.score}/100)`);
  assert(evalReport.overall_health === 'PASS' || evalReport.overall_health === 'NEEDS_REPAIR', 'Assigns valid health state');

  // TEST 11: Targeted Auto-Repair Agent
  console.log('\n▶ [11/20] TARGETED AUTO-REPAIR AGENT');
  const projectNeedingFix: any = {
    id: 'test_repair_proj',
    title: 'Repair Test Project',
    topic: 'Robotics',
    scenes: [{ id: 1, narration: 'Robotics scene', duration: 5 }] // Missing image and subtitles
  };
  const repairResult = repairAgentService.autoRepairAll(projectNeedingFix);
  assert(repairResult.repairedCount >= 1, `Auto-repair agent resolved ${repairResult.repairedCount} flagged issues`);
  assert(projectNeedingFix.self_eval_report?.score >= 85, 'Health score improved following targeted repairs');

  // TEST 12: RBAC Collaboration, Comments & Approvals
  console.log('\n▶ [12/20] RBAC COLLABORATION, COMMENTS & APPROVAL TRAIL');
  const users = collaborationService.getUsers();
  assert(users.length === 5, 'Configures 5 standard studio roles (Owner, Admin, Editor, Reviewer, Viewer)');
  assert(collaborationService.checkPermission('usr_owner_1', 'can_manage_billing') === true, 'Owner has billing permissions');
  assert(collaborationService.checkPermission('usr_editor_1', 'can_manage_billing') === false, 'Editor restricted from billing');

  const comment = collaborationService.addComment({
    project_id: 'test_eval_proj',
    target_type: 'SCENE',
    target_id: 'scene_1',
    scene_id: 1,
    author_name: 'Elena Reviewer',
    author_id: 'usr_reviewer_1',
    comment_text: 'The color grade on scene 1 needs slightly higher contrast.'
  });
  assert(comment.status === 'OPEN', 'Records new scene-level comment');

  const reply = collaborationService.replyToComment('test_eval_proj', comment.id, 'Marcus Editor', 'Adjusted LUT profile.');
  assert(reply?.replies?.length === 1, 'Records comment reply thread');

  const approval = collaborationService.grantApproval({
    projectId: 'test_eval_proj',
    versionNumber: '1.0.0',
    userId: 'usr_reviewer_1',
    userName: 'Elena Reviewer',
    scope: 'FINAL_MASTER'
  });
  assert(approval.is_valid === true && approval.approval_scope === 'FINAL_MASTER', 'Grants version-tied master approval');

  // TEST 13: Scheduling & Isolated Batch Production
  console.log('\n▶ [13/20] PRODUCTION SCHEDULING & ISOLATED BATCH MULTI-PROJECTS');
  const schedJob = schedulingBatchService.scheduleJob({
    topic: 'Daily Tech Recap',
    recurringPattern: 'DAILY',
    priority: 'HIGH'
  });
  assert(schedJob.status === 'SCHEDULED' && schedJob.recurring_pattern === 'DAILY', 'Schedules recurring production job');

  const batchJob = await schedulingBatchService.createAndRunBatch({
    name: 'Science Series Batch',
    topics: ['Black Holes Explained', 'Fusion Energy Horizon'],
    sharedStyle: 'cinematic_photorealistic'
  });
  assert(batchJob.topics.length === 2 && batchJob.status === 'PROCESSING', 'Spawns isolated multi-topic batch job');

  // TEST 14: Content Calendar & Publishing Gate Checklist
  console.log('\n▶ [14/20] CONTENT CALENDAR & PUBLISHING PRE-FLIGHT GATE');
  const calEvents = contentCalendarService.getEvents();
  assert(calEvents.length >= 3, `Aggregates content calendar events (${calEvents.length} found)`);

  const connectors = publishingService.getConnectors();
  assert(connectors.some(c => c.platform === 'YOUTUBE' && c.connected), 'YouTube publishing connector verified');

  const checklist = publishingService.validatePublishingChecklist(dummyProject);
  assert(checklist.format_validated === true, 'Pre-flight publishing checklist evaluates all gates');

  // TEST 15: Analytics, Performance Analyzer & Idea Generator
  console.log('\n▶ [15/20] ANALYTICS, PERFORMANCE ANALYZER & IDEA GENERATOR');
  const analytics = analyticsPerformanceService.getAnalytics('proj_demo_1');
  assert(analytics.views > 0 && analytics.click_through_rate > 0, 'Ingests platform engagement analytics');

  const patterns = analyticsPerformanceService.analyzeHistoricalPatterns();
  assert(patterns.summary_insights.some(s => s.includes('Based on available historical data')), 'Performance analyzer uses cautious data-grounded phrasing');

  const ideas = analyticsPerformanceService.generateContentIdeas({ niche: 'Quantum AI' });
  assert(ideas.length === 4, 'Generates 4 high-retention content ideas with hooks and complexity tiers');

  // TEST 16: Duplicate Content Detector & Originality Assistant
  console.log('\n▶ [16/20] DUPLICATE CONTENT DETECTOR & ORIGINALITY ASSISTANT');
  const origSuggestions = originalityService.getOriginalitySuggestions('Quantum AI');
  assert(origSuggestions.unique_hook_variations.length >= 2, 'Originality assistant provides fresh narrative angles and visual metaphors');

  // TEST 17: Media Rights Tracking & Safe-Area Watermarking
  console.log('\n▶ [17/20] MEDIA RIGHTS TRACKING & SAFE-AREA WATERMARKING');
  const wmConfig = mediaRightsWatermarkService.getWatermarkConfig();
  assert(wmConfig.safe_area_compliant === true && wmConfig.enabled === true, 'Safe-area watermark configuration validated');

  // TEST 18: Automated Backups, Disaster Recovery & Storage Lifecycle
  console.log('\n▶ [18/20] BACKUPS, DISASTER RECOVERY & STORAGE LIFECYCLE');
  const backup = backupRecoveryService.createBackup('MANUAL');
  assert(backup.status === 'SUCCESS' && backup.secrets_excluded === true, 'Generates clean backup excluding sensitive secrets');

  const storageReport = storageLifecycleService.getUsageReport();
  assert(storageReport.total_storage_bytes > 0 && storageReport.free_disk_space_bytes > 0, 'Audits categorized storage usage');

  // TEST 19: System Resources, Worker Nodes & Security Audit
  console.log('\n▶ [19/20] SYSTEM RESOURCES, WORKER POOLS & SECURITY AUDIT');
  const resReport = systemResourceManager.getReport();
  assert(resReport.memory_total_mb > 0 && resReport.throttled === false, 'Monitors CPU, RAM, Disk and Throttling state');

  const workers = renderWorkerManager.getNodes();
  assert(workers.length >= 2, 'Manages Local CPU and Local GPU render worker nodes');

  const secReport = securityAuditService.runAudit();
  assert(secReport.status === 'SECURE' && secReport.exposed_secrets_found === false, 'Security audit verifies zero exposed secrets and secure permissions');

  const auditLogs = auditLogService.getLogs();
  assert(auditLogs.length >= 1, 'Maintains structured audit event trail');

  // Feature flags
  const flags = featureFlagService.getFlags();
  assert(flags.ENABLE_AI_REPAIR === true && flags.ENABLE_AUTO_SHORTS === true, 'Dynamic feature flags operational');

  // Localization
  const locPkg = localizationService.translateAndLocalize(dummyProject, ['es', 'fr']);
  assert(locPkg.target_languages.includes('es') && locPkg.localized_renders['es'] !== undefined, 'Multi-language localization packages scripts, audio, and subtitles');

  // Standalone Project Package Export / Import
  const exportedPkg = projectPackageService.exportPackage(dummyProject.id);
  assert(exportedPkg.manifest_version === '1.0.0', 'Exports standalone project manifest package');

  const importedProj = projectPackageService.importPackage(exportedPkg);
  assert(importedProj.title.includes('(Imported)'), 'Imports standalone project package successfully');

  // Scorecard
  const scorecard = factoryScorecardService.generateScorecard(dummyProject);
  assert(scorecard.overall_score >= 85 && Object.keys(scorecard.dimensions).length === 10, 'Generates 10-dimension AI Factory Scorecard');

  // TEST 20: Full 60-Second Autonomous Production Factory Run (27 Stages) & Emergency Stop
  console.log('\n▶ [20/20] FULL 60-SECOND AUTONOMOUS PRODUCTION RUN & EMERGENCY STOP');
  console.log('  -> Executing: "The Evolution of Autonomous AI Video Factories in 2026"...');

  const { job, project } = await orchestrator.startProduction({
    topic: 'The Evolution of Autonomous AI Video Factories in 2026',
    prompt: 'How multi-agent recursive pipelines orchestrate broadcast-grade video creation in 2026',
    duration: 60,
    language: 'en',
    format: '9:16',
    style: 'Cinematic',
    mode: 'AUTO',
    budget_tier: 'MOCK'
  });

  await new Promise<void>((resolve, reject) => {
    const timer = setInterval(() => {
      const currentJob = db.getProductionJob(job.job_id);
      if (!currentJob) {
        clearInterval(timer);
        return reject(new Error('Job not found in database'));
      }
      if (currentJob.status === 'COMPLETED') {
        clearInterval(timer);
        return resolve();
      }
      if (currentJob.status === 'FAILED') {
        clearInterval(timer);
        return reject(new Error(currentJob.error || 'Pipeline execution failed'));
      }
    }, 500);
  });

  const finalProject = db.getProject(project.id)!;
  const finalJob = db.getProductionJob(job.job_id)!;

  assert(finalJob.status === 'COMPLETED', '27-stage production pipeline completed with 100% progress');
  assert(finalProject.scenes.length >= 5, 'Generated 60s narrative with multiple cinematic beats');
  assert(finalProject.video_url !== undefined && fs.existsSync(path.resolve(process.cwd(), finalProject.video_url.slice(1))), 'Rendered Master MP4 video file');
  assert(finalProject.multi_formats !== undefined && finalProject.multi_formats.length === 4, 'Exported multi-format packages (16:9, 9:16, 1:1, 4:5)');
  assert(finalProject.thumbnails !== undefined && finalProject.thumbnails.length >= 4, 'Generated AI thumbnails and candidate video frames');
  assert(finalProject.auto_metadata !== undefined, 'Generated SEO metadata, tags, and chapters');
  assert(finalProject.auto_shorts !== undefined && finalProject.auto_shorts.length >= 2, 'Generated 9:16 auto-shorts clips');
  assert(finalProject.scorecard?.overall_score! >= 90, 'Achieved >=90/100 10-dimension AI Factory Scorecard score');

  // Emergency Stop Verification
  const stopRes = videoProductionOrchestrator.triggerEmergencyStop();
  assert(stopRes.success === true, 'Global emergency stop halts production instantly while preserving state');
  videoProductionOrchestrator.resetEmergencyStop();

  console.log('\n==================================================================');
  console.log(`🏁 TEST RESULTS: ${passed} PASSED | ${failed} FAILED (Total: ${passed + failed})`);
  console.log('==================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runComprehensiveStudioTestSuite().catch(err => {
  console.error('Test Suite Exception:', err);
  process.exit(1);
});
