import { describe, it, expect } from 'vitest';
import { MockLLMProvider } from '../src/providers/llm/mockLLM.js';
import { ScriptGenerationParams } from '../src/providers/interfaces.js';

describe('AI Script Generator & AI Director', () => {
  const llm = new MockLLMProvider();

  it('should generate structured script with hook, intro, main points, ending, cta in English', async () => {
    const params: ScriptGenerationParams = {
      idea: '5 AI Breakthroughs in 2026',
      language: 'English',
      duration: '30s',
      format: '9:16',
      style: 'Cinematic',
      voice_gender: 'Male',
      voice_tone: 'Energetic'
    };

    const { script, director } = await llm.generateScript(params);

    expect(script).toBeDefined();
    expect(script.hook).toBeTruthy();
    expect(script.introduction).toBeTruthy();
    expect(script.main_content.length).toBeGreaterThanOrEqual(2);
    expect(script.ending).toBeTruthy();
    expect(script.call_to_action).toBeTruthy();

    expect(script.scenes.length).toBeGreaterThanOrEqual(4);
    const scene1 = script.scenes[0];
    expect(scene1).toHaveProperty('scene_id');
    expect(scene1).toHaveProperty('duration');
    expect(scene1).toHaveProperty('narration');
    expect(scene1).toHaveProperty('visual_description');
    expect(scene1).toHaveProperty('camera');
    expect(scene1).toHaveProperty('animation');
    expect(scene1).toHaveProperty('vfx');
    expect(scene1).toHaveProperty('music');
    expect(scene1).toHaveProperty('sound_effect');
    expect(scene1).toHaveProperty('transition');

    expect(director.visual_style).toContain('Cinematic');
    expect(director.aspect_ratio).toBe('9:16');
  });

  it('should generate authentic Hindi script and scenes', async () => {
    const params: ScriptGenerationParams = {
      idea: 'समय यात्रा के वैज्ञानिक रहस्य',
      language: 'Hindi',
      duration: '30s',
      format: '16:9',
      style: 'Documentary',
      voice_gender: 'Male',
      voice_tone: 'Serious'
    };

    const { script } = await llm.generateScript(params);
    expect(script.hook).toContain('समय यात्रा');
    expect(script.scenes.length).toBeGreaterThanOrEqual(4);
  });

  it('should generate authentic Hinglish script and scenes', async () => {
    const params: ScriptGenerationParams = {
      idea: 'AI Startup Kaise Banayein',
      language: 'Hinglish',
      duration: '60s',
      format: '9:16',
      style: 'Educational',
      voice_gender: 'Female',
      voice_tone: 'Energetic'
    };

    const { script } = await llm.generateScript(params);
    expect(script.scenes.length).toBeGreaterThanOrEqual(5);
  });

  it('should regenerate a single scene with preserved context', async () => {
    const originalScene = {
      scene_id: 2,
      duration: 6,
      narration: 'Old narration',
      visual_description: 'Old visual',
      camera: 'Static',
      animation: 'None',
      vfx: 'None',
      music: 'Cinematic',
      sound_effect: 'whoosh',
      transition: 'Cut'
    };

    const regenerated = await llm.regenerateScene(originalScene, {
      topic: 'Quantum Computing',
      style: 'Cinematic',
      language: 'English'
    });

    expect(regenerated.scene_id).toBe(2);
    expect(regenerated.narration).not.toBe('Old narration');
    expect(regenerated.visual_description).toContain('Quantum Computing');
  });
});
