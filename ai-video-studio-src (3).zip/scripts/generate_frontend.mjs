import fs from 'fs';
import path from 'path';

const files = {};

// 1. Hook / Context
files['client/src/hooks/useStudio.tsx'] = `import React, { createContext, useContext, useState, useEffect } from 'react';
import { VideoProject, WorkflowPlan, FactoryScorecard, SelfEvalReport, PublishingChecklist } from '../types/studio';

export type StudioView =
  | 'dashboard'
  | 'factory'
  | 'editor'
  | 'output'
  | 'director_plan'
  | 'scorecard'
  | 'shots'
  | 'asset_bible'
  | 'fact_check'
  | 'trends'
  | 'shorts'
  | 'versions'
  | 'brands'
  | 'calendar_publish'
  | 'analytics_ideas'
  | 'collaboration'
  | 'admin_control'
  | 'providers'
  | 'projects'
  | 'templates'
  | 'voices'
  | 'music'
  | 'renders'
  | 'costs'
  | 'settings';

interface StudioContextType {
  currentView: StudioView;
  setCurrentView: (view: StudioView) => void;
  projects: VideoProject[];
  currentProject: VideoProject | null;
  setCurrentProject: (proj: VideoProject | null) => void;
  isLoading: boolean;
  emergencyStopped: boolean;
  activeModal: string | null;
  openModal: (name: string) => void;
  closeModal: () => void;
  fetchProjects: () => Promise<void>;
  createAutonomousProject: (params: any) => Promise<VideoProject>;
  triggerEmergencyStop: (projectId?: string) => Promise<void>;
  resetEmergencyStop: () => Promise<void>;
  repairProject: (projectId: string) => Promise<void>;
}

const StudioContext = createContext<StudioContextType | undefined>(undefined);

export const StudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<StudioView>('dashboard');
  const [projects, setProjects] = useState<VideoProject[]>([]);
  const [currentProject, setCurrentProject] = useState<VideoProject | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [emergencyStopped, setEmergencyStopped] = useState<boolean>(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const fetchProjects = async () => {
    try {
      const res = await fetch('/api/projects');
      if (res.ok) {
        const data = await res.json();
        setProjects(data.projects || []);
        if (data.projects?.length > 0 && !currentProject) {
          setCurrentProject(data.projects[0]);
        }
      }
    } catch (e) {
      console.warn('Failed to fetch projects', e);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const openModal = (name: string) => setActiveModal(name);
  const closeModal = () => setActiveModal(null);

  const createAutonomousProject = async (params: any): Promise<VideoProject> => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/factory/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      const data = await res.json();
      if (data.project) {
        setCurrentProject(data.project);
        fetchProjects();
        return data.project;
      }
      throw new Error(data.message || 'Production failed');
    } finally {
      setIsLoading(false);
    }
  };

  const triggerEmergencyStop = async (projectId?: string) => {
    await fetch('/api/factory/emergency-stop', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId })
    });
    setEmergencyStopped(true);
    fetchProjects();
  };

  const resetEmergencyStop = async () => {
    await fetch('/api/factory/reset-emergency-stop', { method: 'POST' });
    setEmergencyStopped(false);
  };

  const repairProject = async (projectId: string) => {
    await fetch(\`/api/repair/\${projectId}/auto-all\`, { method: 'POST' });
    fetchProjects();
    if (currentProject?.id === projectId) {
      const updated = await fetch(\`/api/projects/\${projectId}\`).then(r => r.json());
      if (updated.project) setCurrentProject(updated.project);
    }
  };

  return (
    <StudioContext.Provider
      value={{
        currentView,
        setCurrentView,
        projects,
        currentProject,
        setCurrentProject,
        isLoading,
        emergencyStopped,
        activeModal,
        openModal,
        closeModal,
        fetchProjects,
        createAutonomousProject,
        triggerEmergencyStop,
        resetEmergencyStop,
        repairProject
      }}
    >
      {children}
    </StudioContext.Provider>
  );
};

export const useStudio = () => {
  const context = useContext(StudioContext);
  if (!context) throw new Error('useStudio must be used within StudioProvider');
  return context;
};
`;

// 2. Sidebar Navigation
files['client/src/components/layout/Sidebar.tsx'] = `import React from 'react';
import { useStudio, StudioView } from '../../hooks/useStudio';
import {
  Clapperboard, Sparkles, LayoutDashboard, Film, Layers, CheckCircle,
  FileCheck, TrendingUp, Scissors, History, Palette, Cpu, Calendar,
  BarChart3, Users, ShieldAlert, Shield, Settings, AlertOctagon, Music, Mic, Zap
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { currentView, setCurrentView, emergencyStopped, triggerEmergencyStop, resetEmergencyStop, openModal } = useStudio();

  const navGroups: Array<{
    title: string;
    items: Array<{ id: StudioView; label: string; icon: any }>;
  }> = [
    {
      title: 'AI VIDEO FACTORY',
      items: [
        { id: 'dashboard', label: 'Studio Dashboard', icon: LayoutDashboard },
        { id: 'factory', label: 'Live Director Monitor', icon: Zap },
        { id: 'director_plan', label: 'Workflow Planner', icon: Sparkles },
        { id: 'editor', label: 'Multi-Track Studio', icon: Film },
        { id: 'output', label: 'Final Master Output', icon: Clapperboard },
        { id: 'scorecard', label: 'Factory Scorecard (10D)', icon: CheckCircle },
      ]
    },
    {
      title: 'INTELLIGENCE & QC',
      items: [
        { id: 'shots', label: 'Cinematic Shot Planner', icon: Layers },
        { id: 'asset_bible', label: 'Asset Bible & Continuity', icon: Palette },
        { id: 'fact_check', label: 'Fact-Check Inspector', icon: FileCheck },
        { id: 'trends', label: 'Trend & Viral Intelligence', icon: TrendingUp },
        { id: 'shorts', label: 'Auto-Shorts & Reels', icon: Scissors },
        { id: 'analytics_ideas', label: 'Ideas & Originality Engine', icon: Sparkles },
      ]
    },
    {
      title: 'DISTRIBUTION & TEAMS',
      items: [
        { id: 'calendar_publish', label: 'Calendar & Publishing', icon: Calendar },
        { id: 'collaboration', label: 'Collaboration & Approvals', icon: Users },
        { id: 'costs', label: 'Cost Telemetry & Tokens', icon: BarChart3 },
      ]
    },
    {
      title: 'ADMIN & INFRASTRUCTURE',
      items: [
        { id: 'admin_control', label: 'Admin Control Center', icon: Shield },
        { id: 'providers', label: '12-Category Providers', icon: Cpu },
        { id: 'versions', label: 'Version Time Travel', icon: History },
        { id: 'settings', label: 'Studio Settings', icon: Settings },
      ]
    }
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-full select-none z-20">
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/30">
            🎬
          </div>
          <div>
            <h1 className="font-bold text-sm tracking-wide text-slate-100 flex items-center gap-1.5">
              AI STUDIO <span className="text-[10px] bg-amber-500/20 text-amber-400 font-mono px-1.5 py-0.5 rounded border border-amber-500/30">PHASE 6</span>
            </h1>
            <p className="text-[10px] text-slate-400">Autonomous Video Factory</p>
          </div>
        </div>
      </div>

      {/* Quick Action Button */}
      <div className="px-3 pt-3">
        <button
          onClick={() => openModal('factory')}
          className="w-full py-2 px-3 rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-600/30 transition active:scale-[0.98]"
        >
          <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
          <span>New AI Director Project</span>
        </button>
      </div>

      {/* Nav List */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4 custom-scrollbar text-xs">
        {navGroups.map((group, idx) => (
          <div key={idx} className="space-y-1">
            <h3 className="px-3 text-[10px] font-bold text-slate-400 tracking-wider uppercase">
              {group.title}
            </h3>
            {group.items.map(item => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentView(item.id)}
                  className={\`w-full flex items-center gap-2.5 px-3 py-2 rounded-md font-medium text-left transition \${
                    isActive
                      ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }\`}
                >
                  <Icon className={\`w-4 h-4 \${isActive ? 'text-indigo-400' : 'text-slate-500'}\`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Global Emergency Stop Bar */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/60">
        {emergencyStopped ? (
          <div className="space-y-2">
            <div className="p-2 rounded bg-rose-950/80 border border-rose-500/50 text-[11px] text-rose-300 flex items-center gap-2 font-semibold">
              <ShieldAlert className="w-4 h-4 text-rose-400 animate-bounce" />
              <span>EMERGENCY STOP ACTIVE</span>
            </div>
            <button
              onClick={resetEmergencyStop}
              className="w-full py-1.5 px-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition"
            >
              Resume Factory Pipeline
            </button>
          </div>
        ) : (
          <button
            onClick={() => triggerEmergencyStop()}
            className="w-full py-2 px-2 rounded-lg bg-rose-900/30 hover:bg-rose-900/60 border border-rose-600/40 text-rose-300 hover:text-rose-100 font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-[0.98]"
          >
            <AlertOctagon className="w-4 h-4 text-rose-400" />
            <span>GLOBAL STOP PRODUCTION</span>
          </button>
        )}
      </div>
    </aside>
  );
};
`;

for (const [filePath, content] of Object.entries(files)) {
  const fullPath = path.resolve(filePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, content, 'utf-8');
  console.log('Successfully wrote frontend core: ' + filePath);
}
