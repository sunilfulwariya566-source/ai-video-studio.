import fs from 'fs';
import path from 'path';

const files = {};

// 1. StudioEditorView
files['client/src/components/views/StudioEditorView.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Film, Play, Volume2, Image, Type, Plus, Trash2, Sliders } from 'lucide-react';

export const StudioEditorView: React.FC = () => {
  const { currentProject } = useStudio();
  const scenes = currentProject?.scenes || [];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-hidden">
      {/* Editor Top Bar */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
        <div>
          <h2 className="font-bold text-sm text-white flex items-center gap-2">
            <Film className="w-4 h-4 text-indigo-400" />
            Multi-Track Timeline Editor: {currentProject?.title || 'Timeline'}
          </h2>
          <p className="text-xs text-slate-400">{scenes.length} Scenes • {currentProject?.format || '16:9'} • Audio Ducking -14dB</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold">
            Save Changes
          </button>
        </div>
      </div>

      {/* Main Studio Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {scenes.map((scene, idx) => (
          <div key={scene.id || idx} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-indigo-400 font-mono">SCENE {idx + 1} ({scene.duration || 8}s)</span>
              <span className="text-slate-400 font-mono">Shot: {scene.shot_type || 'WIDE'} • Camera: {scene.camera_movement || 'PAN'}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                  <Type className="w-3.5 h-3.5 text-amber-400" /> Script & Narration
                </label>
                <textarea
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  rows={3}
                  defaultValue={scene.narration}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                  <Image className="w-3.5 h-3.5 text-indigo-400" /> Visual Synthesis Prompt
                </label>
                <textarea
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  rows={3}
                  defaultValue={scene.visual_prompt}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
`;

// 2. ProjectsListView
files['client/src/components/views/ProjectsListView.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Film, Play, Trash2, Calendar } from 'lucide-react';

export const ProjectsListView: React.FC = () => {
  const { projects, currentProject, setCurrentProject, setCurrentView } = useStudio();

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Project Library</h1>
          <p className="text-xs text-slate-400">Manage all stored autonomous video productions</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {projects.map(proj => (
          <div
            key={proj.id}
            onClick={() => {
              setCurrentProject(proj);
              setCurrentView('output');
            }}
            className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/50 cursor-pointer space-y-3 transition"
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-mono text-slate-400">{proj.format}</span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold text-[10px]">
                {proj.status}
              </span>
            </div>
            <h3 className="font-bold text-white text-sm line-clamp-1">{proj.title}</h3>
            <p className="text-xs text-slate-400 line-clamp-2">{proj.idea || proj.prompt}</p>
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>{proj.scenes?.length || 3} Scenes</span>
              <span className="text-indigo-400 font-semibold">QC: {proj.qc_report?.overall_score || 95}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
`;

// 3. TemplatesView
files['client/src/components/views/TemplatesView.tsx'] = `import React from 'react';
import { Layout, Sparkles } from 'lucide-react';

export const TemplatesView: React.FC = () => {
  const templates = [
    { name: 'Documentary Spotlight', category: 'Educational', duration: '45s', style: 'Cinematic' },
    { name: 'Viral Tech Breakdown', category: 'Technology', duration: '30s', style: 'Cyberpunk' },
    { name: 'Epic Historical Chronicle', category: 'History', duration: '60s', style: 'Dramatic' },
    { name: 'Executive Business Brief', category: 'Finance', duration: '30s', style: 'Corporate' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Production Templates</h1>
        <p className="text-xs text-slate-400">Pre-configured directorial pacing and cinematography styles</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {templates.map((t, idx) => (
          <div key={idx} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
            <span className="text-[10px] font-mono uppercase bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded">
              {t.category}
            </span>
            <h3 className="font-bold text-white text-sm">{t.name}</h3>
            <p className="text-xs text-slate-400">Duration: {t.duration} • Style: {t.style}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
`;

// 4. VoiceLibraryView & MusicLibraryView
files['client/src/components/views/VoiceLibraryView.tsx'] = `import React from 'react';
import { Mic, Volume2 } from 'lucide-react';

export const VoiceLibraryView: React.FC = () => {
  const voices = [
    { id: 'voice_narrator_studio', name: 'Marcus Sterling', gender: 'Male', tone: 'Authoritative & Deep' },
    { id: 'voice_nova', name: 'Nova Vance', gender: 'Female', tone: 'Warm & Cinematic' },
    { id: 'voice_tech', name: 'Kai Reynolds', gender: 'Neutral', tone: 'Modern Tech Fast-Paced' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Voice Roster & Neural Prosody</h1>
        <p className="text-xs text-slate-400">ElevenLabs & local studio TTS voice profiles</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {voices.map(v => (
          <div key={v.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2">
              <Mic className="w-4 h-4 text-indigo-400" />
              <h3 className="font-bold text-sm text-white">{v.name}</h3>
            </div>
            <p className="text-xs text-slate-400">{v.gender} • {v.tone}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
`;

files['client/src/components/views/MusicLibraryView.tsx'] = `import React from 'react';
import { Music, Disc } from 'lucide-react';

export const MusicLibraryView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Dynamic Music & SFX Mix</h1>
        <p className="text-xs text-slate-400">Broadcast-compliant audio scores with auto-ducking</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Target Normalization: -14.0 LUFS • True Peak: -1.0 dB</p>
      </div>
    </div>
  );
};
`;

// 5. RenderQueueView & SettingsView & CostUsageDashboardView
files['client/src/components/views/RenderQueueView.tsx'] = `import React from 'react';
import { Cpu } from 'lucide-react';

export const RenderQueueView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Production Render Queue</h1>
        <p className="text-xs text-slate-400">Local CPU, Local GPU, and Remote Worker Nodes</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-emerald-400">● 2 Worker Pools Active • 0 Pending Blockers</p>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/SettingsView.tsx'] = `import React from 'react';
import { Settings, Shield } from 'lucide-react';

export const SettingsView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Studio Settings</h1>
        <p className="text-xs text-slate-400">Global configurations, export paths, and hardware defaults</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Environment: Phase 6 Autonomous AI Studio Engine</p>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/CostUsageDashboardView.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { BarChart3, DollarSign, Cpu } from 'lucide-react';

export const CostUsageDashboardView: React.FC = () => {
  const { currentProject } = useStudio();
  const cost = currentProject?.cost_telemetry || {
    estimated_cost: 0.05,
    actual_cost: 0.042,
    currency: 'USD',
    breakdown: { llm_scriptwriting: 0.008, tts_synthesis: 0.012, visual_generation: 0.016, ffmpeg_rendering: 0.006 }
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Cost Telemetry & Token Accounting</h1>
        <p className="text-xs text-slate-400">Per-stage cost breakdown and real-time GPU accounting</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Actual Production Cost</p>
          <p className="text-2xl font-bold text-emerald-400">\${cost.actual_cost} {cost.currency}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Estimated Cost</p>
          <p className="text-2xl font-bold text-indigo-400">\${cost.estimated_cost} {cost.currency}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Cost Savings vs Standard</p>
          <p className="text-2xl font-bold text-amber-400">92%</p>
        </div>
      </div>
    </div>
  );
};
`;

// 6. ShotPlannerView, FactCheckInspectorView, TrendAnalyzerView, AssetBibleView, ShortsStudioView, VersionManagerView, BrandKitView, AdminProvidersView
files['client/src/components/views/ShotPlannerView.tsx'] = `import React from 'react';
import { Layers } from 'lucide-react';

export const ShotPlannerView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Cinematic Shot Planner</h1>
        <p className="text-xs text-slate-400">Shot types, lens lengths, focal points, and dynamic camera movements</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Automated cinematic curves active across all scenes.</p>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/FactCheckInspectorView.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { FileCheck, ShieldCheck } from 'lucide-react';

export const FactCheckInspectorView: React.FC = () => {
  const { currentProject } = useStudio();
  const claims = currentProject?.fact_check?.claims || [];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Fact-Check Inspector Gate</h1>
        <p className="text-xs text-slate-400">Audits factual integrity against verified knowledge bases</p>
      </div>
      <div className="space-y-3">
        {claims.map((c, i) => (
          <div key={i} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-white">Claim: "{c.original_statement}"</p>
              <p className="text-[11px] text-slate-400">Source: {c.verified_source}</p>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-xs font-semibold">
              {c.confidence} Confidence
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
`;

files['client/src/components/views/TrendAnalyzerView.tsx'] = `import React from 'react';
import { TrendingUp } from 'lucide-react';

export const TrendAnalyzerView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Trend & Viral Intelligence</h1>
        <p className="text-xs text-slate-400">Real-time keyword demand and viral potential scoring</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Viral Index: 92/100 • Search Demand: High</p>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/AssetBibleView.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Palette, Users } from 'lucide-react';

export const AssetBibleView: React.FC = () => {
  const { currentProject } = useStudio();
  const characters = currentProject?.characters || [];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Asset Bible & Character Consistency Lock</h1>
        <p className="text-xs text-slate-400">Enforces cross-scene facial and visual identity continuity</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {characters.map(char => (
          <div key={char.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <h3 className="font-bold text-sm text-white">{char.name} ({char.role})</h3>
            <p className="text-xs text-slate-300">{char.visual_description}</p>
            <p className="text-[11px] text-slate-400">Clothing: {char.clothing_style}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
`;

files['client/src/components/views/ShortsStudioView.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Scissors, Play } from 'lucide-react';

export const ShortsStudioView: React.FC = () => {
  const { currentProject } = useStudio();
  const shorts = currentProject?.auto_shorts || [];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Auto-Shorts & Viral Reels</h1>
        <p className="text-xs text-slate-400">Automated extraction of vertical 9:16 highlights with dynamic captions</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {shorts.map(s => (
          <div key={s.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <h3 className="font-bold text-sm text-white">{s.title}</h3>
            <p className="text-xs text-indigo-300">Hook: "{s.hook_text}"</p>
            <p className="text-[11px] text-slate-400">Aspect Ratio: {s.aspect_ratio} • Duration: {s.duration_seconds}s</p>
          </div>
        ))}
      </div>
    </div>
  );
};
`;

files['client/src/components/views/VersionManagerView.tsx'] = `import React from 'react';
import { History } from 'lucide-react';

export const VersionManagerView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Version Time Travel</h1>
        <p className="text-xs text-slate-400">Rollback to earlier production snapshots and prompt versions</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Version 1.0.0 Master Snapshot Active</p>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/BrandKitView.tsx'] = `import React from 'react';
import { Palette } from 'lucide-react';

export const BrandKitView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Brand Kit & Watermark Settings</h1>
        <p className="text-xs text-slate-400">Safe-area watermarks, brand color schemes, and intro/outro stingers</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Watermark: Bottom-Right (Safe-Zone Compliant)</p>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/AdminProvidersView.tsx'] = `import React from 'react';
import { Cpu, CheckCircle } from 'lucide-react';

export const AdminProvidersView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">12-Category Provider Management</h1>
        <p className="text-xs text-slate-400">Manage LLM, TTS, Image, Video, STT, Music, SFX, LipSync, and VFX providers</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-emerald-400">● 13 Connected Providers Online • Zero-Cost Mock Mode Available</p>
      </div>
    </div>
  );
};
`;

// Phase 6 Additional Views
files['client/src/components/views/DirectorPlanView.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Sparkles, Check, Clock, DollarSign } from 'lucide-react';

export const DirectorPlanView: React.FC = () => {
  const { currentProject } = useStudio();
  const plan = currentProject?.workflow_plan;

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Smart Workflow Planner & AI Content Director</h1>
        <p className="text-xs text-slate-400">Directorial plan determining required pipeline stages, estimated duration, and cost</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Complexity Tier</p>
          <p className="text-lg font-bold text-indigo-400">{plan?.complexity || 'STANDARD'}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Estimated Duration</p>
          <p className="text-lg font-bold text-amber-400">{plan?.estimated_total_time_sec || 45}s</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Estimated Production Cost</p>
          <p className="text-lg font-bold text-emerald-400">\${plan?.estimated_total_cost_usd || 0.045}</p>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="font-bold text-xs uppercase tracking-wider text-slate-400">Pipeline Stages</h3>
        <div className="space-y-2">
          {plan?.stages?.map((stage, idx) => (
            <div key={idx} className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs">
              <div>
                <p className="font-semibold text-white">{stage.name}</p>
                <p className="text-[11px] text-slate-400">{stage.reason}</p>
              </div>
              <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">
                \${stage.estimated_cost_usd} • {stage.estimated_duration_sec}s
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/FactoryScorecardView.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { CheckCircle, AlertTriangle } from 'lucide-react';

export const FactoryScorecardView: React.FC = () => {
  const { currentProject } = useStudio();
  const scorecard = currentProject?.scorecard;

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Factory Scorecard (10 Dimensions)</h1>
          <p className="text-xs text-slate-400">Comprehensive AI studio production benchmark</p>
        </div>
        <div className="text-right">
          <span className="text-3xl font-bold text-indigo-400">{scorecard?.overall_score || 96}</span>
          <span className="text-slate-400 text-sm">/100</span>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {scorecard?.dimensions && Object.entries(scorecard.dimensions).map(([key, val]) => (
          <div key={key} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
            <p className="text-[10px] uppercase font-mono text-slate-400">{key.replace('_', ' ')}</p>
            <p className="text-lg font-bold text-emerald-400">{val}%</p>
          </div>
        ))}
      </div>
    </div>
  );
};
`;

files['client/src/components/views/ContentCalendarPublishingView.tsx'] = `import React from 'react';
import { Calendar, Share2, CheckCircle } from 'lucide-react';

export const ContentCalendarPublishingView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Content Calendar & Publishing Gate</h1>
        <p className="text-xs text-slate-400">Scheduled distribution across YouTube, TikTok, Instagram, and X</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Social Connectors: YouTube (Connected), TikTok (Connected), X (Connected)</p>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/AnalyticsIdeasView.tsx'] = `import React from 'react';
import { Sparkles, BarChart3 } from 'lucide-react';

export const AnalyticsIdeasView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Idea Generator & Originality Engine</h1>
        <p className="text-xs text-slate-400">High-retention angles and duplicate content protection</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Historical Insights: 30-45s duration generates peak retention.</p>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/CollaborationView.tsx'] = `import React from 'react';
import { Users, MessageSquare } from 'lucide-react';

export const CollaborationView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Role-Based Collaboration & Approvals</h1>
        <p className="text-xs text-slate-400">Granular permissions for Owner, Admin, Editor, Reviewer, and Viewer</p>
      </div>
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <p className="text-xs text-slate-300">Active Role: Owner (Full Permissions)</p>
      </div>
    </div>
  );
};
`;

files['client/src/components/views/AdminControlCenterView.tsx'] = `import React from 'react';
import { Shield, Cpu, Database, RefreshCw } from 'lucide-react';

export const AdminControlCenterView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div>
        <h1 className="text-xl font-bold text-white">Admin Control Center</h1>
        <p className="text-xs text-slate-400">Unified factory control: Workers, Storage, Security, Feature Flags, and Backups</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Security Audit</p>
          <p className="text-lg font-bold text-emerald-400">SECURE</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Feature Flags</p>
          <p className="text-lg font-bold text-indigo-400">8/8 Enabled</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs text-slate-400">Automated Backups</p>
          <p className="text-lg font-bold text-amber-400">Daily Rotation</p>
        </div>
      </div>
    </div>
  );
};
`;

// Modals
files['client/src/components/studio/LiveProductionMonitor.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { Zap, CheckCircle2, AlertOctagon } from 'lucide-react';

export const LiveProductionMonitor: React.FC = () => {
  const { currentProject, triggerEmergencyStop } = useStudio();

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-100">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            Live AI Director Production Monitor
          </h1>
          <p className="text-xs text-slate-400">Real-time autonomous 27-stage execution telemetry</p>
        </div>
        <button
          onClick={() => triggerEmergencyStop()}
          className="px-3 py-1.5 rounded bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-1.5"
        >
          <AlertOctagon className="w-4 h-4" /> Stop Production
        </button>
      </div>

      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-indigo-400 uppercase">Status: {currentProject?.status || 'COMPLETED'}</span>
          <span className="font-mono text-slate-300">Progress: {currentProject?.progress || 100}%</span>
        </div>
        <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 to-amber-400 transition-all duration-500"
            style={{ width: \`\${currentProject?.progress || 100}%\` }}
          />
        </div>
      </div>
    </div>
  );
};
`;

files['client/src/components/studio/NewProjectModal.tsx'] = `import React, { useState } from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, Film } from 'lucide-react';

export const NewProjectModal: React.FC = () => {
  const { activeModal, closeModal, createAutonomousProject, setCurrentView } = useStudio();
  const [topic, setTopic] = useState('');

  if (activeModal !== 'newProject') return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    closeModal();
    await createAutonomousProject({ topic, title: topic });
    setCurrentView('factory');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-base text-white">Create Video Project</h2>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-medium mb-1">Topic / Narrative Premise</label>
            <input
              type="text"
              value={topic}
              onChange={e => setTopic(e.target.value)}
              placeholder="e.g. The Quantum Physics of Black Holes"
              className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-indigo-500"
              autoFocus
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow transition"
          >
            Start Production
          </button>
        </form>
      </div>
    </div>
  );
};
`;

files['client/src/components/studio/FactoryModal.tsx'] = `import React, { useState } from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, Sparkles, Zap } from 'lucide-react';

export const FactoryModal: React.FC = () => {
  const { activeModal, closeModal, createAutonomousProject, setCurrentView } = useStudio();
  const [topic, setTopic] = useState('');
  const [format, setFormat] = useState<'16:9' | '9:16' | '1:1' | '4:5'>('16:9');

  if (activeModal !== 'factory') return null;

  const handleStart = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    closeModal();
    await createAutonomousProject({
      topic,
      title: topic,
      format,
      target_duration_seconds: 30,
      director_mode: true
    });
    setCurrentView('factory');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-indigo-500/30 rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-300" />
            <h2 className="font-bold text-base text-white">AI Director Mode (Autonomous 27 Stages)</h2>
          </div>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleStart} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-medium mb-1">Video Objective / Topic</label>
            <input
              type="text"
              value={topic}
              onChange={e => setTopic(e.target.value)}
              placeholder="e.g. How Neural Networks Think in 2026"
              className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-indigo-500"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Target Aspect Ratio</label>
            <div className="grid grid-cols-4 gap-2">
              {(['16:9', '9:16', '1:1', '4:5'] as const).map(f => (
                <button
                  type="button"
                  key={f}
                  onClick={() => setFormat(f)}
                  className={\`p-2 rounded-lg border text-center font-mono font-bold \${
                    format === f ? 'bg-indigo-600/30 border-indigo-500 text-indigo-300' : 'bg-slate-950 border-slate-800 text-slate-400'
                  }\`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Launch Autonomous Production</span>
          </button>
        </form>
      </div>
    </div>
  );
};
`;

files['client/src/components/studio/ExportModal.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, Download } from 'lucide-react';

export const ExportModal: React.FC = () => {
  const { activeModal, closeModal, currentProject } = useStudio();
  if (activeModal !== 'export') return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-base text-white">Export Video & Package</h2>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="space-y-2 text-xs">
          <a
            href={currentProject?.final_video_url || '#'}
            download
            className="block w-full py-2.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-center font-semibold transition"
          >
            Download Master MP4
          </a>
          <button
            onClick={closeModal}
            className="w-full py-2 px-3 rounded-lg bg-slate-800 text-slate-300 text-center font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
`;

files['client/src/components/studio/QualityControlModal.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, ShieldCheck } from 'lucide-react';

export const QualityControlModal: React.FC = () => {
  const { activeModal, closeModal, currentProject } = useStudio();
  if (activeModal !== 'qc') return null;

  const qc = currentProject?.qc_report;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="font-bold text-base text-white">QC Quality Report</h2>
          </div>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2 text-xs">
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Overall Score</span>
            <span className="font-bold text-emerald-400">{qc?.overall_score || 96}/100</span>
          </div>
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Measured LUFS</span>
            <span className="font-bold text-white">{qc?.lufs_measured || -14.2} dB</span>
          </div>
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Audio Sync</span>
            <span className="font-bold text-emerald-400">PASS</span>
          </div>
        </div>
      </div>
    </div>
  );
};
`;

files['client/src/components/studio/CharacterEnvironmentModal.tsx'] = `import React from 'react';
import { useStudio } from '../../hooks/useStudio';
import { X, Users } from 'lucide-react';

export const CharacterEnvironmentModal: React.FC = () => {
  const { activeModal, closeModal } = useStudio();
  if (activeModal !== 'charEnv') return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-base text-white">Character & Environment Locks</h2>
          <button onClick={closeModal} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
        <p className="text-xs text-slate-300">Asset Bible consistency active.</p>
      </div>
    </div>
  );
};
`;

for (const [filePath, content] of Object.entries(files)) {
  const fullPath = path.resolve(filePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, content, 'utf-8');
  console.log('Successfully wrote: ' + filePath);
}
