import fs from 'fs';
import path from 'path';

const runnerPath = path.resolve('server/tests/runner.ts');
let runner = fs.readFileSync(runnerPath, 'utf-8');

runner = runner.replace(
  `  const dummyProject: any = {
    id: 'test_eval_proj',
    title: 'Self Eval Test',
    topic: 'Quantum Computing',
    scenes: [`,
  `  const dummyProject: any = {
    id: 'test_eval_proj',
    title: 'Self Eval Test',
    topic: 'Quantum Computing',
    format: '16:9',
    final_video_url: '/storage/renders/test_eval_master.mp4',
    thumbnails: [{ id: 't1', title: 'Thumb 1', headline_overlay: 'TEST', predicted_ctr_score: 10 }],
    scenes: [`
);

fs.writeFileSync(runnerPath, runner, 'utf-8');
console.log('Updated runner.ts');
