import fs from 'fs';
import path from 'path';

const content = `import fs from 'fs';
import path from 'path';
import { VideoProject, AssetRecord, ScheduledJob, BatchProductionJob } from '../types/index.js';

class ProjectStore {
  private projects: Map<string, VideoProject> = new Map();
  private assets: Map<string, AssetRecord> = new Map();
  private scheduledJobs: Map<string, ScheduledJob> = new Map();
  private batchJobs: Map<string, BatchProductionJob> = new Map();
  private storeFile: string;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'storage');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.storeFile = path.join(dataDir, 'projects_db.json');
    this.loadFromDisk();
  }

  private loadFromDisk() {
    try {
      if (fs.existsSync(this.storeFile)) {
        const raw = fs.readFileSync(this.storeFile, 'utf-8');
        const data = JSON.parse(raw);
        if (data.projects) {
          for (const p of data.projects) {
            this.projects.set(p.id, p);
          }
        }
        if (data.assets) {
          for (const a of data.assets) {
            this.assets.set(a.id, a);
          }
        }
        if (data.scheduledJobs) {
          for (const j of data.scheduledJobs) {
            this.scheduledJobs.set(j.id, j);
          }
        }
        if (data.batchJobs) {
          for (const b of data.batchJobs) {
            this.batchJobs.set(b.id, b);
          }
        }
      }
    } catch (e) {
      console.warn('[ProjectStore] Could not load persisted data:', e);
    }
  }

  private persistToDisk() {
    try {
      const payload = {
        projects: Array.from(this.projects.values()),
        assets: Array.from(this.assets.values()),
        scheduledJobs: Array.from(this.scheduledJobs.values()),
        batchJobs: Array.from(this.batchJobs.values())
      };
      fs.writeFileSync(this.storeFile, JSON.stringify(payload, null, 2), 'utf-8');
    } catch (e) {
      console.error('[ProjectStore] Failed to persist data:', e);
    }
  }

  public getProject(id: string): VideoProject | undefined {
    return this.projects.get(id);
  }

  public getAllProjects(): VideoProject[] {
    return Array.from(this.projects.values()).sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }

  public saveProject(project: VideoProject): VideoProject {
    project.updated_at = new Date().toISOString();
    this.projects.set(project.id, project);
    this.persistToDisk();
    return project;
  }

  public deleteProject(id: string): boolean {
    const deleted = this.projects.delete(id);
    if (deleted) {
      this.persistToDisk();
    }
    return deleted;
  }

  public saveAsset(asset: AssetRecord): AssetRecord {
    this.assets.set(asset.id, asset);
    this.persistToDisk();
    return asset;
  }

  public getAssetsByProject(projectId: string): AssetRecord[] {
    return Array.from(this.assets.values()).filter(a => a.projectId === projectId);
  }

  public getAllAssets(): AssetRecord[] {
    return Array.from(this.assets.values());
  }

  public saveScheduledJob(job: ScheduledJob): ScheduledJob {
    this.scheduledJobs.set(job.id, job);
    this.persistToDisk();
    return job;
  }

  public getScheduledJobs(): ScheduledJob[] {
    return Array.from(this.scheduledJobs.values());
  }

  public saveBatchJob(batch: BatchProductionJob): BatchProductionJob {
    this.batchJobs.set(batch.id, batch);
    this.persistToDisk();
    return batch;
  }

  public getBatchJobs(): BatchProductionJob[] {
    return Array.from(this.batchJobs.values());
  }

  public getBatchJob(id: string): BatchProductionJob | undefined {
    return this.batchJobs.get(id);
  }
}

export const projectStore = new ProjectStore();
`;

fs.mkdirSync(path.resolve('server/src/database'), { recursive: true });
fs.writeFileSync(path.resolve('server/src/database/projectStore.ts'), content, 'utf-8');
console.log('Wrote projectStore.ts');
