import fs from 'fs';
import path from 'path';

const files = {};

// 1. Content Director Service
files['server/src/services/contentDirectorService.ts'] = `import { DirectorDecision, WorkflowPlan } from '../types/index.js';
import { workflowPlannerService } from './workflowPlannerService.js';

export interface DirectorAnalyzeOptions {
  projectId: string;
  topic: string;
  prompt?: string;
  targetAudience?: string;
  format?: '16:9' | '9:16' | '1:1' | '4:5';
  targetDurationSeconds?: number;
  qualityTier?: 'FAST_DRAFT' | 'STUDIO_HD' | 'ULTRA_CINEMATIC';
}

export class ContentDirectorService {
  public analyzeAndDirect(options: DirectorAnalyzeOptions): {
    decision: DirectorDecision;
    workflowPlan: WorkflowPlan;
  } {
    const topicLower = (options.topic + ' ' + (options.prompt || '')).toLowerCase();
    const duration = options.targetDurationSeconds || 30;
    const format = options.format || '16:9';
    const qualityTier = options.qualityTier || 'STUDIO_HD';

    let complexity: 'SIMPLE' | 'STANDARD' | 'CINEMATIC_COMPLEX' = 'STANDARD';
    if (duration > 60 || qualityTier === 'ULTRA_CINEMATIC') {
      complexity = 'CINEMATIC_COMPLEX';
    } else if (duration <= 15 && qualityTier === 'FAST_DRAFT') {
      complexity = 'SIMPLE';
    }

    let visualStyle = 'cinematic_photorealistic';
    let voiceStyle = 'authoritative_narrator';
    let template = 'documentary_spotlight';
    let pacing = 'dynamic_balanced';

    if (topicLower.includes('tech') || topicLower.includes('ai') || topicLower.includes('future')) {
      visualStyle = 'cyberpunk_neon_tech';
      voiceStyle = 'modern_tech_enthusiast';
      template = 'tech_breakdown';
      pacing = 'high_energy_fast';
    }

    const requiresBRoll = duration >= 25;
    const requiresVfx = qualityTier !== 'FAST_DRAFT';
    const requiresLipsync = topicLower.includes('interview') || topicLower.includes('character');
    const requiresShorts = format === '16:9' || duration >= 30;

    const aspectRatios: Array<'16:9' | '9:16' | '1:1' | '4:5'> = [format];
    if (format === '16:9') aspectRatios.push('9:16');

    const decision: DirectorDecision = {
      objective_summary: \`Directing an impactful \${complexity.toLowerCase()} video about "\${options.topic}" optimized for \${options.targetAudience || 'broad digital audience'}.\`,
      creative_angle: 'Engaging visual hook transitioning into clear structured narrative with strong call-to-action.',
      pacing_curve: pacing,
      quality_tier: qualityTier,
      tone_instructions: \`Maintain \${voiceStyle.replace(/_/g, ' ')} audio delivery complemented by high-fidelity \${visualStyle.replace(/_/g, ' ')} visuals.\`,
      aspect_ratios_to_generate: aspectRatios
    };

    const workflowPlan = workflowPlannerService.generatePlan({
      projectId: options.projectId,
      topic: options.topic,
      targetAudience: options.targetAudience || 'General Audience',
      complexity,
      templateRecommended: template,
      visualStyleRecommended: visualStyle,
      voiceStyleRecommended: voiceStyle,
      requiresBRoll,
      requiresVfx,
      requiresLipsync,
      requiresShorts
    });

    return { decision, workflowPlan };
  }
}

export const contentDirectorService = new ContentDirectorService();
`;

// 2. Workflow Planner Service
files['server/src/services/workflowPlannerService.ts'] = `import { WorkflowPlan, WorkflowStagePlan } from '../types/index.js';

export interface PlanGenerationOptions {
  projectId: string;
  topic: string;
  targetAudience: string;
  complexity: 'SIMPLE' | 'STANDARD' | 'CINEMATIC_COMPLEX';
  templateRecommended: string;
  visualStyleRecommended: string;
  voiceStyleRecommended: string;
  requiresBRoll: boolean;
  requiresVfx: boolean;
  requiresLipsync: boolean;
  requiresShorts: boolean;
}

export class WorkflowPlannerService {
  private plans: Map<string, WorkflowPlan> = new Map();

  public generatePlan(options: PlanGenerationOptions): WorkflowPlan {
    const isCinematic = options.complexity === 'CINEMATIC_COMPLEX';
    const isSimple = options.complexity === 'SIMPLE';

    const stageDefinitions = [
      { stage: 'RESEARCH', name: 'Topic Research & Fact-Finding', required: true, durationSec: 4, costUsd: 0.02, reason: 'Gather facts, statistics, and domain context' },
      { stage: 'SCRIPT_WRITING', name: 'Narrative & Scriptwriting', required: true, durationSec: 5, costUsd: 0.03, reason: 'Generate high-retention scene breakdown' },
      { stage: 'FACT_CHECK', name: 'Automated Fact-Checking Gate', required: !isSimple, durationSec: 3, costUsd: 0.01, reason: 'Verify claims against verified knowledge bases' },
      { stage: 'ASSET_BIBLE', name: 'Asset Bible & Character Locks', required: isCinematic, durationSec: 3, costUsd: 0.02, reason: 'Ensure cross-scene visual and facial continuity' },
      { stage: 'VOICE_GENERATION', name: 'Voiceover Synthesis & Prosody', required: true, durationSec: 6, costUsd: 0.04, reason: 'Generate expressive narration per scene' },
      { stage: 'SUBTITLE_SYNC', name: 'Word-Level Subtitle Syncing', required: true, durationSec: 2, costUsd: 0.005, reason: 'Extract phoneme/word timings for captions' },
      { stage: 'VISUAL_GENERATION', name: 'High-Fidelity Visual Generation', required: true, durationSec: 10, costUsd: 0.08, reason: 'Synthesize visual frames matching prompts' },
      { stage: 'B_ROLL_INTEGRATION', name: 'Supplemental B-Roll Generation', required: options.requiresBRoll, durationSec: 5, costUsd: 0.03, reason: 'Generate contextual overlay footage' },
      { stage: 'LIP_SYNC', name: 'Neural Lip-Sync Processing', required: options.requiresLipsync, durationSec: 8, costUsd: 0.05, reason: 'Synchronize character mouth movements to voice' },
      { stage: 'VFX_ANIMATION', name: 'VFX & Motion Graphics', required: options.requiresVfx, durationSec: 4, costUsd: 0.02, reason: 'Apply Ken Burns, particle and camera movements' },
      { stage: 'MUSIC_SFX', name: 'Dynamic Music & SFX Mix', required: true, durationSec: 3, costUsd: 0.015, reason: 'Compose background track with auto-ducking' },
      { stage: 'VIDEO_ASSEMBLY', name: 'Timeline Assembly & Multi-Track Render', required: true, durationSec: 12, costUsd: 0.05, reason: 'Encode high-definition master timeline' },
      { stage: 'MULTI_FORMAT_EXPORT', name: 'Multi-Aspect Ratio Transcoding', required: true, durationSec: 8, costUsd: 0.03, reason: 'Export 16:9, 9:16 vertical, and square feeds' },
      { stage: 'THUMBNAIL_GENERATION', name: 'AI Thumbnail & Title Optimization', required: true, durationSec: 3, costUsd: 0.01, reason: 'Synthesize high-CTR headline thumbnails' },
      { stage: 'AUTO_SHORTS', name: 'Auto-Shorts & Reel Clipping', required: options.requiresShorts, durationSec: 5, costUsd: 0.02, reason: 'Extract viral highlights with vertical captions' },
      { stage: 'QUALITY_CONTROL', name: 'Automated QC & Self-Evaluation Gate', required: true, durationSec: 4, costUsd: 0.01, reason: 'Verify audio clipping, black frames, and continuity' },
      { stage: 'PUBLISHING_CHECKLIST', name: 'Pre-Flight Publishing Verification', required: true, durationSec: 2, costUsd: 0.005, reason: 'Validate readiness for social publishing channels' }
    ];

    const stages: WorkflowStagePlan[] = stageDefinitions.map(def => ({
      stage: def.stage,
      name: def.name,
      required: def.required,
      estimated_duration_sec: def.durationSec,
      estimated_cost_usd: def.costUsd,
      reason: def.reason,
      status: 'PENDING'
    }));

    const totalCost = stages.filter(s => s.required).reduce((sum, s) => sum + s.estimated_cost_usd, 0);
    const totalTime = stages.filter(s => s.required).reduce((sum, s) => sum + s.estimated_duration_sec, 0);

    const plan: WorkflowPlan = {
      plan_id: \`plan_\${Date.now()}_\${Math.random().toString(36).substring(2, 7)}\`,
      project_id: options.projectId,
      topic: options.topic,
      target_audience: options.targetAudience,
      complexity: options.complexity,
      template_recommended: options.templateRecommended,
      visual_style_recommended: options.visualStyleRecommended,
      voice_style_recommended: options.voiceStyleRecommended,
      requires_broll: options.requiresBRoll,
      requires_vfx: options.requiresVfx,
      requires_lipsync: options.requiresLipsync,
      requires_shorts: options.requiresShorts,
      stages,
      estimated_total_cost_usd: parseFloat(totalCost.toFixed(3)),
      estimated_total_time_sec: totalTime,
      approved_by_user: false,
      created_at: new Date().toISOString()
    };

    this.plans.set(options.projectId, plan);
    return plan;
  }

  public getPlan(projectId: string): WorkflowPlan | undefined {
    return this.plans.get(projectId);
  }

  public editPlan(projectId: string, updatedStages: Partial<WorkflowStagePlan>[]): WorkflowPlan {
    let plan = this.plans.get(projectId);
    if (!plan) {
      plan = this.generatePlan({
        projectId,
        topic: 'Custom Project',
        targetAudience: 'General',
        complexity: 'STANDARD',
        templateRecommended: 'default',
        visualStyleRecommended: 'cinematic',
        voiceStyleRecommended: 'narrator',
        requiresBRoll: true,
        requiresVfx: true,
        requiresLipsync: false,
        requiresShorts: true
      });
    }

    for (const update of updatedStages) {
      const match = plan.stages.find(s => s.stage === update.stage);
      if (match) {
        if (typeof update.required === 'boolean') match.required = update.required;
        if (update.status) match.status = update.status;
      }
    }

    const activeStages = plan.stages.filter(s => s.required && s.status !== 'SKIPPED');
    plan.estimated_total_cost_usd = parseFloat(
      activeStages.reduce((sum, s) => sum + s.estimated_cost_usd, 0).toFixed(3)
    );
    plan.estimated_total_time_sec = activeStages.reduce((sum, s) => sum + s.estimated_duration_sec, 0);

    this.plans.set(projectId, plan);
    return plan;
  }

  public approvePlan(projectId: string): WorkflowPlan {
    let plan = this.plans.get(projectId);
    if (!plan) {
      plan = this.generatePlan({
        projectId,
        topic: 'Custom Project',
        targetAudience: 'General',
        complexity: 'STANDARD',
        templateRecommended: 'default',
        visualStyleRecommended: 'cinematic',
        voiceStyleRecommended: 'narrator',
        requiresBRoll: true,
        requiresVfx: true,
        requiresLipsync: false,
        requiresShorts: true
      });
    }
    plan.approved_by_user = true;
    for (const s of plan.stages) {
      if (s.required && s.status === 'PENDING') {
        s.status = 'APPROVED';
      }
    }
    this.plans.set(projectId, plan);
    return plan;
  }
}

export const workflowPlannerService = new WorkflowPlannerService();
`;

// 3. Content Memory Service
files['server/src/services/contentMemoryService.ts'] = `import { ProjectMemoryRecord, CharacterEntity, VideoProject } from '../types/index.js';
import fs from 'fs';
import path from 'path';

export class ContentMemoryService {
  private memories: Map<string, ProjectMemoryRecord> = new Map();
  private memoryFile: string;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'storage');
    this.memoryFile = path.join(dataDir, 'content_memory.json');
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.memoryFile)) {
        const raw = fs.readFileSync(this.memoryFile, 'utf-8');
        const list: ProjectMemoryRecord[] = JSON.parse(raw);
        for (const item of list) {
          this.memories.set(item.id, item);
        }
      }
    } catch (e) {
      console.warn('[ContentMemory] Failed to load memory file:', e);
    }
  }

  private persist() {
    try {
      const list = Array.from(this.memories.values());
      fs.writeFileSync(this.memoryFile, JSON.stringify(list, null, 2), 'utf-8');
    } catch (e) {
      console.error('[ContentMemory] Failed to persist memory:', e);
    }
  }

  public recordProjectCompletion(project: VideoProject): ProjectMemoryRecord {
    const successfulPrompts: Array<{ category: string; prompt: string; rating: number }> = [];
    if (project.scenes) {
      for (const scene of project.scenes) {
        if (scene.visual_prompt) {
          successfulPrompts.push({ category: 'visual', prompt: scene.visual_prompt, rating: 0.9 });
        }
      }
    }

    const record: ProjectMemoryRecord = {
      id: \`mem_\${project.id}\`,
      project_id: project.id,
      title: project.title,
      topic: project.topic,
      visual_style: project.style || 'cinematic',
      voice_id: project.voice_id || 'default_voice',
      characters: project.characters || [],
      successful_prompts: successfulPrompts,
      quality_score: project.qc_report?.overall_score || 90,
      created_at: new Date().toISOString()
    };

    this.memories.set(record.id, record);
    this.persist();
    return record;
  }

  public getAllMemories(): ProjectMemoryRecord[] {
    return Array.from(this.memories.values()).sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }

  public findMemoryByTopicOrStyle(query: string): ProjectMemoryRecord | undefined {
    const q = query.toLowerCase();
    for (const mem of this.memories.values()) {
      if (
        mem.topic.toLowerCase().includes(q) ||
        mem.title.toLowerCase().includes(q) ||
        mem.visual_style.toLowerCase().includes(q)
      ) {
        return mem;
      }
    }
    return undefined;
  }
}

export const contentMemoryService = new ContentMemoryService();
`;

// 4. Prompt Optimization & Prompt Versioning
files['server/src/services/promptOptimizationService.ts'] = `import { OptimizedPrompt, ProviderCategory } from '../types/index.js';
import { promptVersioningService } from './promptVersioningService.js';

export class PromptOptimizationService {
  private history: Map<string, OptimizedPrompt> = new Map();

  public optimizePrompt(req: any): OptimizedPrompt {
    const provider = req.providerTarget || 'standard_ai';
    const model = req.modelTarget || 'default_model';
    const modifiers = req.styleModifiers || [];
    let optimized = req.rawUserIntent;
    let negativePrompt = '';

    if (req.category === 'image' || req.category === 'visuals') {
      const visualAdditions = ['photorealistic', '8k resolution', 'masterpiece', 'hyper-detailed', 'volumetric cinematic lighting', ...modifiers];
      optimized = \`\${req.rawUserIntent}, \${visualAdditions.join(', ')}\`;
      negativePrompt = 'blurry, distorted, low quality, deformed anatomy, bad hands, artifacts, watermark';
    } else if (req.category === 'llm' || req.category === 'script') {
      optimized = \`You are an award-winning documentary scriptwriter. Create an engaging, retention-optimized narrative for the topic: "\${req.rawUserIntent}". Keep sentences punchy, conversational, and rhythmically varied. Include vivid visual descriptions for every shot.\`;
    } else if (req.category === 'tts') {
      optimized = \`[Tone: Warm, Authoritative, Dynamic] \${req.rawUserIntent}\`;
    }

    const record: OptimizedPrompt = {
      id: \`opt_\${Date.now()}_\${Math.random().toString(36).substring(2, 7)}\`,
      category: req.category,
      raw_user_intent: req.rawUserIntent,
      optimized_prompt: optimized,
      negative_prompt: negativePrompt,
      provider_target: provider,
      model_target: model,
      style_modifiers: modifiers,
      parameters: req.parameters || {},
      version: 1,
      created_at: new Date().toISOString()
    };

    this.history.set(record.id, record);

    promptVersioningService.registerVersion({
      promptId: record.id,
      category: record.category,
      provider: record.provider_target,
      model: record.model_target,
      promptText: record.optimized_prompt,
      negativePrompt: record.negative_prompt,
      parameters: record.parameters,
      qualityScore: 92,
      successRate: 0.98
    });

    return record;
  }

  public getOptimizedPrompt(id: string): OptimizedPrompt | undefined {
    return this.history.get(id);
  }

  public getAllOptimizedPrompts(): OptimizedPrompt[] {
    return Array.from(this.history.values());
  }
}

export const promptOptimizationService = new PromptOptimizationService();
`;

files['server/src/services/promptVersioningService.ts'] = `import { PromptVersion, ProviderCategory } from '../types/index.js';

export class PromptVersioningService {
  private versions: Map<string, PromptVersion[]> = new Map();

  public registerVersion(options: any): PromptVersion {
    const existing = this.versions.get(options.promptId) || [];
    const nextVersionNum = existing.length + 1;

    const versionRecord: PromptVersion = {
      version_id: \`ver_\${options.promptId}_v\${nextVersionNum}\`,
      prompt_id: options.promptId,
      category: options.category,
      version_number: nextVersionNum,
      provider: options.provider,
      model: options.model,
      prompt_text: options.promptText,
      negative_prompt: options.negativePrompt,
      parameters: options.parameters,
      quality_score: options.qualityScore || 90,
      success_rate: options.successRate || 1.0,
      created_at: new Date().toISOString()
    };

    existing.push(versionRecord);
    this.versions.set(options.promptId, existing);
    return versionRecord;
  }

  public getVersionsForPrompt(promptId: string): PromptVersion[] {
    return this.versions.get(promptId) || [];
  }

  public getAllVersions(): PromptVersion[] {
    const all: PromptVersion[] = [];
    for (const list of this.versions.values()) {
      all.push(...list);
    }
    return all.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  public compareVersions(v1Id: string, v2Id: string) {
    const all = this.getAllVersions();
    const v1 = all.find(v => v.version_id === v1Id);
    const v2 = all.find(v => v.version_id === v2Id);

    const diff = {
      promptDiff: { v1: v1?.prompt_text, v2: v2?.prompt_text },
      qualityScoreDelta: (v2?.quality_score || 0) - (v1?.quality_score || 0),
      successRateDelta: (v2?.success_rate || 0) - (v1?.success_rate || 0),
      modelChange: v1?.model !== v2?.model ? { from: v1?.model, to: v2?.model } : null
    };

    return { v1, v2, diff };
  }
}

export const promptVersioningService = new PromptVersioningService();
`;

// 5. Quality Learning Service
files['server/src/services/qualityLearningService.ts'] = `import { QualityMetricRecord, VideoProject } from '../types/index.js';
import fs from 'fs';
import path from 'path';

export class QualityLearningService {
  private records: Map<string, QualityMetricRecord> = new Map();
  private filePath: string;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'storage');
    this.filePath = path.join(dataDir, 'quality_learning.json');
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        const list: QualityMetricRecord[] = JSON.parse(raw);
        for (const item of list) {
          this.records.set(item.id, item);
        }
      }
    } catch (e) {
      console.warn('[QualityLearning] Could not load learning data:', e);
    }
  }

  private persist() {
    try {
      const list = Array.from(this.records.values());
      fs.writeFileSync(this.filePath, JSON.stringify(list, null, 2), 'utf-8');
    } catch (e) {
      console.error('[QualityLearning] Could not persist learning data:', e);
    }
  }

  public recordProjectMetrics(project: VideoProject, userDecision: 'APPROVED' | 'REJECTED' | 'REGENERATED' = 'APPROVED'): QualityMetricRecord {
    const qcScore = project.qc_report?.overall_score || 92;
    const totalCost = project.cost_telemetry?.actual_cost || 0.05;

    let explanation = \`Standard automated quality metrics captured. Project achieved \${qcScore}% quality score.\`;
    if (qcScore >= 90) {
      explanation = \`High aesthetic and technical quality achieved. Pacing and visual prompt alignment recommended for future \${project.style || 'cinematic'} topics.\`;
    }

    const record: QualityMetricRecord = {
      id: \`ql_\${Date.now()}_\${Math.random().toString(36).substring(2, 7)}\`,
      project_id: project.id,
      qc_score: qcScore,
      user_decision: userDecision,
      regeneration_count: 0,
      failed_stages: [],
      providers_used: {
        llm: 'mock-llm',
        tts: 'mock-tts',
        image: 'mock-image',
        render: 'ffmpeg-local'
      },
      production_time_ms: 12400,
      total_cost_usd: totalCost,
      learnings_explanation: explanation,
      timestamp: new Date().toISOString()
    };

    this.records.set(record.id, record);
    this.persist();
    return record;
  }

  public getAllRecords(): QualityMetricRecord[] {
    return Array.from(this.records.values()).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  public getLearningsSummary() {
    const records = Array.from(this.records.values());
    if (records.length === 0) {
      return {
        averageQcScore: 92,
        approvalRate: 0.95,
        totalProjectsAnalyzed: 0,
        recommendedStyles: ['cinematic_photorealistic', 'cyberpunk_neon_tech'],
        recommendations: [
          'Based on historical data: 16:9 cinematic presets with 30-45s duration produce highest retention.',
          'Dynamic word-level subtitles improve viewer watch time by ~24%.'
        ]
      };
    }

    const avgQc = records.reduce((acc, r) => acc + r.qc_score, 0) / records.length;
    const approvedCount = records.filter(r => r.user_decision === 'APPROVED').length;
    const approvalRate = approvedCount / records.length;

    return {
      averageQcScore: parseFloat(avgQc.toFixed(1)),
      approvalRate: parseFloat(approvalRate.toFixed(2)),
      totalProjectsAnalyzed: records.length,
      recommendedStyles: ['cinematic_photorealistic', 'clean_corporate_minimalist'],
      recommendations: [
        \`Historical analysis of \${records.length} projects indicates \${approvalRate * 100}% approval rate with average QC of \${avgQc.toFixed(1)}%.\`,
        'Using auto-ducking on background music preserves voice clarity across all tested playback environments.'
      ]
    };
  }
}

export const qualityLearningService = new QualityLearningService();
`;

// 6. Pre-Human AI Self-Evaluation Service
files['server/src/services/selfEvaluationService.ts'] = `import { SelfEvalReport, SelfEvalIssue, VideoProject } from '../types/index.js';

export class SelfEvaluationService {
  public evaluateProject(project: VideoProject): SelfEvalReport {
    const issues: SelfEvalIssue[] = [];

    if (!project.scenes || project.scenes.length < 2) {
      issues.push({
        id: \`eval_script_\${Date.now()}_1\`,
        component: 'SCRIPT',
        severity: 'WARNING',
        problem: 'Project script has fewer than 2 scenes, which may limit dynamic visual pacing.',
        suggested_fix: 'Add an introductory hook or closing call-to-action scene.',
        auto_fix_available: true
      });
    }

    const scenesWithoutImages = project.scenes?.filter(s => !s.image_url && !s.video_url) || [];
    if (scenesWithoutImages.length > 0) {
      issues.push({
        id: \`eval_vis_\${Date.now()}_2\`,
        component: 'VISUALS',
        severity: 'CRITICAL',
        scene_id: scenesWithoutImages[0].id,
        problem: \`Scene \${scenesWithoutImages[0].id} is missing rendered visual media.\`,
        suggested_fix: 'Trigger targeted visual re-synthesis for unrendered scenes.',
        auto_fix_available: true
      });
    }

    if (!project.voice_id) {
      issues.push({
        id: \`eval_voice_\${Date.now()}_3\`,
        component: 'VOICE',
        severity: 'WARNING',
        problem: 'No specific voice profile locked in project settings.',
        suggested_fix: 'Assign standard studio narrator voice profile.',
        auto_fix_available: true
      });
    }

    if (!project.music_style) {
      issues.push({
        id: \`eval_music_\${Date.now()}_4\`,
        component: 'MUSIC',
        severity: 'MINOR',
        problem: 'Background music profile is unspecified.',
        suggested_fix: 'Apply dynamic ambient background audio track with -18dB ducking.',
        auto_fix_available: true
      });
    }

    const missingSubs = project.scenes?.some(s => !s.subtitles || s.subtitles.length === 0);
    if (missingSubs) {
      issues.push({
        id: \`eval_captions_\${Date.now()}_5\`,
        component: 'CAPTIONS',
        severity: 'WARNING',
        problem: 'One or more scenes lack synchronized subtitle caption words.',
        suggested_fix: 'Run automated phoneme timestamp extractor.',
        auto_fix_available: true
      });
    }

    if (project.characters && project.characters.length > 0 && !project.asset_bible) {
      issues.push({
        id: \`eval_cont_\${Date.now()}_6\`,
        component: 'CONTINUITY',
        severity: 'MINOR',
        problem: 'Character entities defined without an active locked Asset Bible.',
        suggested_fix: 'Lock seed parameters and prompt modifiers to preserve character face consistency.',
        auto_fix_available: true
      });
    }

    if (!project.thumbnails || project.thumbnails.length === 0) {
      issues.push({
        id: \`eval_thumb_\${Date.now()}_8\`,
        component: 'THUMBNAIL',
        severity: 'MINOR',
        problem: 'No high-CTR thumbnail candidate currently selected.',
        suggested_fix: 'Generate AI thumbnail variants with high-contrast headline overlays.',
        auto_fix_available: true
      });
    }

    const hasCritical = issues.some(i => i.severity === 'CRITICAL');
    const hasWarning = issues.some(i => i.severity === 'WARNING');

    let overallHealth: 'PASS' | 'NEEDS_REPAIR' | 'CRITICAL_BLOCK' = 'PASS';
    let baseScore = 95;

    if (hasCritical) {
      overallHealth = 'CRITICAL_BLOCK';
      baseScore = 65;
    } else if (hasWarning) {
      overallHealth = 'NEEDS_REPAIR';
      baseScore = 82;
    } else if (issues.length > 0) {
      baseScore = 90;
    }

    return {
      project_id: project.id,
      overall_health: overallHealth,
      score: baseScore,
      issues,
      auto_repaired_count: 0,
      evaluated_at: new Date().toISOString()
    };
  }
}

export const selfEvaluationService = new SelfEvaluationService();
`;

// 7. Collaboration Service
files['server/src/services/collaborationService.ts'] = `import { StudioUser, ProjectComment, ApprovalRecord, HumanFeedback } from '../types/index.js';
import { projectStore } from '../database/projectStore.js';
import { qualityLearningService } from './qualityLearningService.js';

export class CollaborationService {
  private users: Map<string, StudioUser> = new Map();
  private comments: Map<string, ProjectComment[]> = new Map();
  private approvals: Map<string, ApprovalRecord[]> = new Map();
  private feedbackHistory: Map<string, HumanFeedback[]> = new Map();

  constructor() {
    this.seedDefaultUsers();
  }

  private seedDefaultUsers() {
    const defaultUsers: StudioUser[] = [
      {
        id: 'usr_owner_1',
        name: 'Alex Director (Owner)',
        email: 'owner@aistudio.internal',
        role: 'OWNER',
        permissions: {
          can_create_project: true,
          can_edit_project: true,
          can_generate_assets: true,
          can_approve_content: true,
          can_render: true,
          can_export: true,
          can_manage_providers: true,
          can_manage_billing: true
        }
      },
      {
        id: 'usr_admin_1',
        name: 'Sarah Producer (Admin)',
        email: 'admin@aistudio.internal',
        role: 'ADMIN',
        permissions: {
          can_create_project: true,
          can_edit_project: true,
          can_generate_assets: true,
          can_approve_content: true,
          can_render: true,
          can_export: true,
          can_manage_providers: true,
          can_manage_billing: false
        }
      },
      {
        id: 'usr_editor_1',
        name: 'Marcus Video Editor',
        email: 'editor@aistudio.internal',
        role: 'EDITOR',
        permissions: {
          can_create_project: true,
          can_edit_project: true,
          can_generate_assets: true,
          can_approve_content: false,
          can_render: true,
          can_export: true,
          can_manage_providers: false,
          can_manage_billing: false
        }
      },
      {
        id: 'usr_reviewer_1',
        name: 'Elena Quality Reviewer',
        email: 'reviewer@aistudio.internal',
        role: 'REVIEWER',
        permissions: {
          can_create_project: false,
          can_edit_project: false,
          can_generate_assets: false,
          can_approve_content: true,
          can_render: false,
          can_export: true,
          can_manage_providers: false,
          can_manage_billing: false
        }
      },
      {
        id: 'usr_viewer_1',
        name: 'Jordan Client (Viewer)',
        email: 'viewer@aistudio.internal',
        role: 'VIEWER',
        permissions: {
          can_create_project: false,
          can_edit_project: false,
          can_generate_assets: false,
          can_approve_content: false,
          can_render: false,
          can_export: false,
          can_manage_providers: false,
          can_manage_billing: false
        }
      }
    ];

    for (const u of defaultUsers) {
      this.users.set(u.id, u);
    }
  }

  public getUsers(): StudioUser[] {
    return Array.from(this.users.values());
  }

  public getUser(id: string): StudioUser | undefined {
    return this.users.get(id);
  }

  public checkPermission(userId: string, permission: keyof StudioUser['permissions']): boolean {
    const user = this.users.get(userId);
    if (!user) return false;
    return !!user.permissions[permission];
  }

  public addComment(comment: any): ProjectComment {
    const list = this.comments.get(comment.project_id) || [];
    const newComment: ProjectComment = {
      ...comment,
      id: \`cmt_\${Date.now()}_\${Math.random().toString(36).substring(2, 6)}\`,
      status: 'OPEN',
      replies: [],
      created_at: new Date().toISOString()
    };

    list.push(newComment);
    this.comments.set(comment.project_id, list);

    const project = projectStore.getProject(comment.project_id);
    if (project) {
      project.comments = list;
      projectStore.saveProject(project);
    }

    return newComment;
  }

  public replyToComment(projectId: string, commentId: string, authorName: string, text: string) {
    const list = this.comments.get(projectId) || [];
    const target = list.find(c => c.id === commentId);
    if (!target) return undefined;

    if (!target.replies) target.replies = [];
    target.replies.push({
      id: \`rep_\${Date.now()}\`,
      author_name: authorName,
      comment_text: text,
      created_at: new Date().toISOString()
    });

    const project = projectStore.getProject(projectId);
    if (project) {
      project.comments = list;
      projectStore.saveProject(project);
    }

    return target;
  }

  public updateCommentStatus(projectId: string, commentId: string, status: 'OPEN' | 'RESOLVED') {
    const list = this.comments.get(projectId) || [];
    const target = list.find(c => c.id === commentId);
    if (!target) return undefined;

    target.status = status;
    const project = projectStore.getProject(projectId);
    if (project) {
      project.comments = list;
      projectStore.saveProject(project);
    }

    return target;
  }

  public getComments(projectId: string): ProjectComment[] {
    return this.comments.get(projectId) || [];
  }

  public grantApproval(options: any): ApprovalRecord {
    const list = this.approvals.get(options.projectId) || [];
    const record: ApprovalRecord = {
      id: \`appr_\${Date.now()}_\${Math.random().toString(36).substring(2, 6)}\`,
      project_id: options.projectId,
      version_number: options.versionNumber,
      approved_by_user_id: options.userId,
      approved_by_name: options.userName,
      approval_scope: options.scope,
      timestamp: new Date().toISOString(),
      comments: options.comments,
      is_valid: true
    };

    list.push(record);
    this.approvals.set(options.projectId, list);

    const project = projectStore.getProject(options.projectId);
    if (project) {
      project.approval_history = list;
      projectStore.saveProject(project);
    }

    return record;
  }

  public invalidateApprovalsOnEdit(projectId: string): void {
    const list = this.approvals.get(projectId);
    if (list) {
      for (const a of list) {
        a.is_valid = false;
      }
    }
  }

  public getApprovals(projectId: string): ApprovalRecord[] {
    return this.approvals.get(projectId) || [];
  }

  public recordFeedback(feedback: any): HumanFeedback {
    const list = this.feedbackHistory.get(feedback.project_id) || [];
    const record: HumanFeedback = {
      ...feedback,
      id: \`fb_\${Date.now()}_\${Math.random().toString(36).substring(2, 6)}\`,
      created_at: new Date().toISOString()
    };

    list.push(record);
    this.feedbackHistory.set(feedback.project_id, list);

    const project = projectStore.getProject(feedback.project_id);
    if (project) {
      qualityLearningService.recordProjectMetrics(
        project,
        feedback.feedback_type === 'APPROVE' ? 'APPROVED' : feedback.feedback_type === 'REGENERATE' ? 'REGENERATED' : 'REJECTED'
      );
    }

    return record;
  }
}

export const collaborationService = new CollaborationService();
`;

for (const [filePath, content] of Object.entries(files)) {
  const fullPath = path.resolve(filePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, content, 'utf-8');
  console.log('Wrote: ' + filePath);
}
