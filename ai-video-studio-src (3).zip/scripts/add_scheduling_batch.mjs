import fs from 'fs';
import path from 'path';

const content = `import { ScheduledJob, BatchProductionJob } from '../types/index.js';
import { projectStore } from '../database/projectStore.js';

export class SchedulingBatchService {
  public scheduleJob(options: {
    topic: string;
    title?: string;
    scheduledStartTime?: string;
    recurringPattern?: 'DAILY' | 'WEEKLY_MWF' | 'WEEKLY_TT' | 'MONTHLY';
    priority?: 'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW';
  }): ScheduledJob {
    const job: ScheduledJob = {
      id: 'sched_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: options.title || ('Scheduled: ' + options.topic),
      topic: options.topic,
      scheduled_start_time: options.scheduledStartTime || new Date().toISOString(),
      recurring_pattern: options.recurringPattern,
      priority: options.priority || 'NORMAL',
      status: 'SCHEDULED',
      created_at: new Date().toISOString()
    };

    projectStore.saveScheduledJob(job);
    return job;
  }

  public async createAndRunBatch(options: {
    name: string;
    topics: string[];
    sharedStyle?: string;
    sharedFormat?: '16:9' | '9:16' | '1:1' | '4:5';
  }): Promise<BatchProductionJob> {
    const batchId = 'batch_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const batchJob: BatchProductionJob = {
      id: batchId,
      name: options.name,
      topics: options.topics,
      project_ids: [],
      shared_style: options.sharedStyle || 'cinematic_photorealistic',
      shared_format: options.sharedFormat || '16:9',
      status: 'PROCESSING',
      completed_count: 0,
      failed_count: 0,
      created_at: new Date().toISOString()
    };

    projectStore.saveBatchJob(batchJob);

    (async () => {
      try {
        const { videoProductionOrchestrator } = await import('../orchestrator/videoProductionOrchestrator.js');
        for (const topic of options.topics) {
          try {
            const project = await videoProductionOrchestrator.createAndProduceProject({
              topic,
              title: topic,
              style: options.sharedStyle || 'cinematic_photorealistic',
              format: options.sharedFormat || '16:9',
              duration_target: '30s',
              target_duration_seconds: 30
            });
            batchJob.project_ids.push(project.id);
            batchJob.completed_count++;
            projectStore.saveBatchJob(batchJob);
          } catch (err) {
            console.error('[BatchService] Failed to produce topic:', topic, err);
            batchJob.failed_count++;
            projectStore.saveBatchJob(batchJob);
          }
        }
        batchJob.status = batchJob.failed_count === 0 ? 'COMPLETED' : 'PARTIAL_FAILED';
        projectStore.saveBatchJob(batchJob);
      } catch (e) {
        console.error('[BatchService] Executor error:', e);
      }
    })();

    return batchJob;
  }

  public getScheduledJobs(): ScheduledJob[] {
    return projectStore.getScheduledJobs();
  }

  public getBatchJobs(): BatchProductionJob[] {
    return projectStore.getBatchJobs();
  }

  public getBatchJob(id: string): BatchProductionJob | undefined {
    return projectStore.getBatchJob(id);
  }
}

export const schedulingBatchService = new SchedulingBatchService();
`;

fs.writeFileSync(path.resolve('server/src/services/schedulingBatchService.ts'), content, 'utf-8');
console.log('Wrote schedulingBatchService.ts');
