import fs from 'fs';
import path from 'path';

const content = `import { Router, Request, Response } from 'express';
import { projectStore } from '../database/projectStore.js';
import { videoProductionOrchestrator } from '../orchestrator/videoProductionOrchestrator.js';
import { workflowPlannerService } from '../services/workflowPlannerService.js';
import { contentDirectorService } from '../services/contentDirectorService.js';
import { contentMemoryService } from '../services/contentMemoryService.js';
import { promptOptimizationService } from '../services/promptOptimizationService.js';
import { promptVersioningService } from '../services/promptVersioningService.js';
import { qualityLearningService } from '../services/qualityLearningService.js';
import { selfEvaluationService } from '../services/selfEvaluationService.js';
import { repairAgentService } from '../services/repairAgentService.js';
import { collaborationService } from '../services/collaborationService.js';
import { schedulingBatchService } from '../services/schedulingBatchService.js';
import { contentCalendarService } from '../services/contentCalendarService.js';
import { publishingService } from '../services/publishingService.js';
import { analyticsPerformanceService } from '../services/analyticsPerformanceService.js';
import { originalityService } from '../services/originalityService.js';
import { mediaRightsWatermarkService } from '../services/mediaRightsWatermarkService.js';
import { backupRecoveryService } from '../services/backupRecoveryService.js';
import { storageLifecycleService } from '../services/storageLifecycleService.js';
import { systemResourceManager } from '../services/systemResourceManager.js';
import { renderWorkerManager } from '../services/renderWorkerManager.js';
import { securityAuditService } from '../services/securityAuditService.js';
import { auditLogService } from '../services/auditLogService.js';
import { featureFlagService } from '../services/featureFlagService.js';
import { experimentService } from '../services/experimentService.js';
import { localizationService } from '../services/localizationService.js';
import { projectPackageService } from '../services/projectPackageService.js';
import { webhookNotificationService } from '../services/webhookNotificationService.js';
import { factoryScorecardService } from '../services/factoryScorecardService.js';

const router = Router();

// Health Check
router.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'HEALTHY',
    version: '6.0.0',
    phase: 'PHASE_6_ADVANCED_AI_VIDEO_FACTORY',
    uptime_seconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString()
  });
});

// Seed default mock project if database is empty
if (projectStore.getAllProjects().length === 0) {
  videoProductionOrchestrator.createAndProduceProject({
    id: 'proj_demo_1',
    topic: 'The Architecture of Autonomous AI Agents',
    title: 'The Architecture of Autonomous AI Agents',
    prompt: 'Explore how multi-agent recursive systems orchestrate media workflows in 2026',
    format: '16:9',
    duration_target: '30s',
    target_duration_seconds: 30,
    style: 'cinematic_photorealistic'
  }).catch(e => console.warn('[SeedProject] Seed error:', e));
}

// 1. Project Management
router.get('/projects', (_req: Request, res: Response) => {
  res.json({ projects: projectStore.getAllProjects() });
});

router.get('/projects/:id', (req: Request, res: Response) => {
  const project = projectStore.getProject(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  res.json({ project });
});

router.post('/projects', (req: Request, res: Response) => {
  const project = projectStore.saveProject(req.body);
  auditLogService.logAction({
    action: 'PROJECT_CREATED',
    user_id: 'user_default',
    user_name: 'Studio Creator',
    project_id: project.id,
    details: \`Created project: \${project.title}\`
  });
  res.json({ project });
});

router.put('/projects/:id', (req: Request, res: Response) => {
  const existing = projectStore.getProject(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Project not found' });
  const updated = projectStore.saveProject({ ...existing, ...req.body, id: req.params.id });
  collaborationService.invalidateApprovalsOnEdit(req.params.id);
  auditLogService.logAction({
    action: 'PROJECT_EDITED',
    user_id: 'user_default',
    user_name: 'Studio Creator',
    project_id: updated.id,
    details: \`Updated project: \${updated.title}\`
  });
  res.json({ project: updated });
});

router.delete('/projects/:id', (req: Request, res: Response) => {
  const deleted = projectStore.deleteProject(req.params.id);
  res.json({ success: deleted });
});

// 2. AI Video Factory Master Creation (Autonomous 27 Stages)
router.post('/factory/create', async (req: Request, res: Response) => {
  try {
    const project = await videoProductionOrchestrator.createAndProduceProject(req.body);
    res.json({ success: true, project });
  } catch (err: any) {
    res.status(500).json({ error: 'Production failed', message: err.message });
  }
});

// 3. Global Emergency Stop
router.post('/factory/emergency-stop', (req: Request, res: Response) => {
  const result = videoProductionOrchestrator.triggerEmergencyStop(req.body?.projectId);
  res.json(result);
});

router.post('/factory/reset-emergency-stop', (_req: Request, res: Response) => {
  videoProductionOrchestrator.resetEmergencyStop();
  res.json({ success: true, message: 'Emergency stop status cleared.' });
});

// 4. AI Content Director & Workflow Planner
router.post('/director/analyze', (req: Request, res: Response) => {
  const result = contentDirectorService.analyzeAndDirect(req.body);
  res.json(result);
});

router.get('/workflow/plan/:projectId', (req: Request, res: Response) => {
  const plan = workflowPlannerService.getPlan(req.params.projectId);
  res.json({ plan });
});

router.post('/workflow/plan/:projectId/edit', (req: Request, res: Response) => {
  const plan = workflowPlannerService.editPlan(req.params.projectId, req.body.stages || []);
  res.json({ plan });
});

router.post('/workflow/plan/:projectId/approve', (req: Request, res: Response) => {
  const plan = workflowPlannerService.approvePlan(req.params.projectId);
  res.json({ plan });
});

// 5. Content Memory
router.get('/memory', (_req: Request, res: Response) => {
  res.json({ memories: contentMemoryService.getAllMemories() });
});

router.get('/memory/search', (req: Request, res: Response) => {
  const query = (req.query.q as string) || '';
  const memory = contentMemoryService.findMemoryByTopicOrStyle(query);
  res.json({ memory });
});

// 6. Prompt Engineering & Versioning
router.post('/prompts/optimize', (req: Request, res: Response) => {
  const result = promptOptimizationService.optimizePrompt(req.body);
  res.json({ result });
});

router.get('/prompts/versions', (_req: Request, res: Response) => {
  res.json({ versions: promptVersioningService.getAllVersions() });
});

router.get('/prompts/compare', (req: Request, res: Response) => {
  const { v1, v2 } = req.query as { v1: string; v2: string };
  res.json(promptVersioningService.compareVersions(v1, v2));
});

// 7. Quality Learning & Historical Optimization
router.get('/quality-learning', (_req: Request, res: Response) => {
  res.json({
    summary: qualityLearningService.getLearningsSummary(),
    records: qualityLearningService.getAllRecords()
  });
});

// 8. Pre-Human Self-Evaluation & Targeted Repair
router.get('/self-eval/:projectId', (req: Request, res: Response) => {
  const project = projectStore.getProject(req.params.projectId);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  const report = selfEvaluationService.evaluateProject(project);
  res.json({ report });
});

router.post('/repair/:projectId/issue', (req: Request, res: Response) => {
  const project = projectStore.getProject(req.params.projectId);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  const result = repairAgentService.repairIssue(project, req.body.issueId);
  res.json(result);
});

router.post('/repair/:projectId/auto-all', (req: Request, res: Response) => {
  const project = projectStore.getProject(req.params.projectId);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  const result = repairAgentService.autoRepairAll(project);
  res.json(result);
});

// 9. Collaboration, Comments, RBAC & Approvals
router.get('/collaboration/users', (_req: Request, res: Response) => {
  res.json({ users: collaborationService.getUsers() });
});

router.get('/collaboration/comments/:projectId', (req: Request, res: Response) => {
  res.json({ comments: collaborationService.getComments(req.params.projectId) });
});

router.post('/collaboration/comments', (req: Request, res: Response) => {
  const comment = collaborationService.addComment(req.body);
  res.json({ comment });
});

router.post('/collaboration/comments/:projectId/:commentId/reply', (req: Request, res: Response) => {
  const updated = collaborationService.replyToComment(
    req.params.projectId,
    req.params.commentId,
    req.body.authorName,
    req.body.commentText
  );
  res.json({ comment: updated });
});

router.post('/collaboration/comments/:projectId/:commentId/status', (req: Request, res: Response) => {
  const updated = collaborationService.updateCommentStatus(
    req.params.projectId,
    req.params.commentId,
    req.body.status
  );
  res.json({ comment: updated });
});

router.get('/collaboration/approvals/:projectId', (req: Request, res: Response) => {
  res.json({ approvals: collaborationService.getApprovals(req.params.projectId) });
});

router.post('/collaboration/approvals', (req: Request, res: Response) => {
  const record = collaborationService.grantApproval(req.body);
  auditLogService.logAction({
    action: 'APPROVAL_GRANTED',
    user_id: req.body.userId,
    user_name: req.body.userName,
    project_id: req.body.projectId,
    details: \`Granted approval for scope: \${req.body.scope}\`
  });
  res.json({ approval: record });
});

router.post('/collaboration/feedback', (req: Request, res: Response) => {
  const feedback = collaborationService.recordFeedback(req.body);
  res.json({ feedback });
});

// 10. Scheduling & Batch Production
router.post('/scheduling/job', (req: Request, res: Response) => {
  const job = schedulingBatchService.scheduleJob(req.body);
  res.json({ job });
});

router.get('/scheduling/jobs', (_req: Request, res: Response) => {
  res.json({ jobs: schedulingBatchService.getScheduledJobs() });
});

router.post('/scheduling/batch', async (req: Request, res: Response) => {
  const batch = await schedulingBatchService.createAndRunBatch(req.body);
  res.json({ batch });
});

router.get('/scheduling/batch', (_req: Request, res: Response) => {
  res.json({ batches: schedulingBatchService.getBatchJobs() });
});

// 11. Content Calendar
router.get('/calendar/events', (req: Request, res: Response) => {
  const events = contentCalendarService.getEvents(req.query as any);
  res.json({ events });
});

router.post('/calendar/events', (req: Request, res: Response) => {
  const event = contentCalendarService.addEvent(req.body);
  res.json({ event });
});

// 12. Publishing Connectors & Checklist
router.get('/publishing/connectors', (_req: Request, res: Response) => {
  res.json({ connectors: publishingService.getConnectors() });
});

router.get('/publishing/checklist/:projectId', (req: Request, res: Response) => {
  const project = projectStore.getProject(req.params.projectId);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  const checklist = publishingService.validatePublishingChecklist(project);
  res.json({ checklist });
});

router.post('/publishing/publish', async (req: Request, res: Response) => {
  try {
    const record = await publishingService.publishToPlatform(req.body);
    res.json({ success: true, publishRecord: record });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/publishing/history', (req: Request, res: Response) => {
  const history = publishingService.getPublishHistory(req.query.projectId as string);
  res.json({ history });
});

// 13. Analytics, Performance Analyzer & Idea Generator
router.get('/analytics/:projectId', (req: Request, res: Response) => {
  const metric = analyticsPerformanceService.getAnalytics(req.params.projectId);
  res.json({ analytics: metric });
});

router.get('/analytics/insights/patterns', (_req: Request, res: Response) => {
  res.json({ patterns: analyticsPerformanceService.analyzeHistoricalPatterns() });
});

router.post('/analytics/ideas/generate', (req: Request, res: Response) => {
  const ideas = analyticsPerformanceService.generateContentIdeas(req.body);
  res.json({ ideas });
});

// 14. Originality & Duplicate Detection
router.post('/originality/check', (req: Request, res: Response) => {
  const result = originalityService.checkDuplicateContent(req.body.topic, req.body.scriptText);
  res.json({ result });
});

router.post('/originality/suggestions', (req: Request, res: Response) => {
  const suggestions = originalityService.getOriginalitySuggestions(req.body.topic);
  res.json({ suggestions });
});

// 15. Media Rights & Watermarking
router.get('/rights-watermark/config', (_req: Request, res: Response) => {
  res.json({ watermark: mediaRightsWatermarkService.getWatermarkConfig() });
});

router.put('/rights-watermark/config', (req: Request, res: Response) => {
  const updated = mediaRightsWatermarkService.updateWatermarkConfig(req.body);
  res.json({ watermark: updated });
});

router.get('/rights-watermark/audit/:projectId', (req: Request, res: Response) => {
  const audit = mediaRightsWatermarkService.getRightsAuditForProject(req.params.projectId);
  res.json({ audit });
});

// 16. Backups & Disaster Recovery
router.get('/backups', (_req: Request, res: Response) => {
  res.json({ backups: backupRecoveryService.getBackups() });
});

router.post('/backups', (req: Request, res: Response) => {
  const record = backupRecoveryService.createBackup(req.body?.type || 'MANUAL');
  res.json({ backup: record });
});

// 17. Storage Lifecycle
router.get('/storage/report', (_req: Request, res: Response) => {
  res.json({
    policy: storageLifecycleService.getPolicy(),
    usage: storageLifecycleService.getUsageReport()
  });
});

router.post('/storage/cleanup', (_req: Request, res: Response) => {
  const cleanup = storageLifecycleService.runLifecycleCleanup();
  res.json({ cleanup });
});

// 18. System Resources & Render Workers
router.get('/system/resources', (_req: Request, res: Response) => {
  res.json({ resources: systemResourceManager.getReport() });
});

router.get('/workers', (_req: Request, res: Response) => {
  res.json({ workers: renderWorkerManager.getNodes() });
});

// 19. Security Audit & Audit Log
router.get('/security/audit', (_req: Request, res: Response) => {
  res.json({ security: securityAuditService.runAudit() });
});

router.get('/audit/logs', (_req: Request, res: Response) => {
  res.json({ logs: auditLogService.getLogs() });
});

// 20. Feature Flags & Experiments
router.get('/feature-flags', (_req: Request, res: Response) => {
  res.json({ flags: featureFlagService.getFlags() });
});

router.post('/feature-flags', (req: Request, res: Response) => {
  const updated = featureFlagService.setFlag(req.body.key, req.body.value);
  res.json({ flags: updated });
});

router.get('/experiments/:projectId', (req: Request, res: Response) => {
  res.json({ experiments: experimentService.getTestsForProject(req.params.projectId) });
});

router.post('/experiments', (req: Request, res: Response) => {
  const test = experimentService.createTest(req.body.projectId, req.body.testName, req.body.variants);
  res.json({ test });
});

// 21. Multi-Language Localization
router.post('/localization/:projectId', (req: Request, res: Response) => {
  const project = projectStore.getProject(req.params.projectId);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  const pkg = localizationService.translateAndLocalize(project, req.body.targetLanguages || ['es', 'fr', 'de']);
  projectStore.saveProject(project);
  res.json({ package: pkg });
});

// 22. Project Import / Export Package
router.get('/packages/export/:projectId', (req: Request, res: Response) => {
  try {
    const pkg = projectPackageService.exportPackage(req.params.projectId);
    res.json(pkg);
  } catch (err: any) {
    res.status(404).json({ error: err.message });
  }
});

router.post('/packages/import', (req: Request, res: Response) => {
  try {
    const imported = projectPackageService.importPackage(req.body);
    res.json({ project: imported });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// 23. Webhooks & Notifications
router.get('/webhooks', (_req: Request, res: Response) => {
  res.json({ webhooks: webhookNotificationService.getWebhooks() });
});

router.post('/webhooks', (req: Request, res: Response) => {
  const sub = webhookNotificationService.registerWebhook(req.body.targetUrl, req.body.events || ['*']);
  res.json({ webhook: sub });
});

router.get('/notifications', (_req: Request, res: Response) => {
  res.json({ notifications: webhookNotificationService.getNotifications() });
});

router.post('/notifications/:id/read', (req: Request, res: Response) => {
  webhookNotificationService.markAsRead(req.params.id);
  res.json({ success: true });
});

// 24. Factory Scorecard
router.get('/factory/scorecard/:projectId', (req: Request, res: Response) => {
  const project = projectStore.getProject(req.params.projectId);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  const scorecard = factoryScorecardService.generateScorecard(project);
  res.json({ scorecard });
});

export default router;
`;

const targetPath = path.resolve('server/src/routes/api.ts');
fs.writeFileSync(targetPath, content, 'utf-8');
console.log('Successfully wrote router: ' + targetPath);
